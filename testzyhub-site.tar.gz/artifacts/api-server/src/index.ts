import { createServer } from "node:http";
import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";
import bcrypt from "bcryptjs";
import { Server as SocketIOServer } from "socket.io";
import { setupBattleSocket } from "./routes/battle";
import { seedPracticeQuestions } from "./seed/seedQuestions";

const ADMIN_EMAIL = "ankushtyagi0000@gmail.com";
const ADMIN_PASSWORD = "anchal123";
const ADMIN_NAME = "Ankush";

async function runMigrations() {
  try {
    await pool.query(`ALTER TABLE db_questions ADD COLUMN IF NOT EXISTS set_number INTEGER DEFAULT 1;`);
    await pool.query(`ALTER TABLE quiz_submissions ADD COLUMN IF NOT EXISTS set_number INTEGER DEFAULT 1;`);
    await pool.query(`ALTER TABLE db_questions ADD COLUMN IF NOT EXISTS subject TEXT DEFAULT '';`);

    // Referral columns on users
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE;`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by TEXT;`);

    // Reviews table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment TEXT NOT NULL,
        approved BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Help queries table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS help_queries (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        name TEXT NOT NULL,
        email TEXT,
        subject TEXT NOT NULL,
        message TEXT NOT NULL,
        status TEXT DEFAULT 'open',
        admin_reply TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    // Doubt Forum tables
    await pool.query(`
      CREATE TABLE IF NOT EXISTS doubt_posts (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        title TEXT NOT NULL,
        question_text TEXT NOT NULL,
        category TEXT DEFAULT 'general',
        image_base64 TEXT,
        is_resolved BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    // Mega quiz settings
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mega_quiz_settings (
        id SERIAL PRIMARY KEY,
        quiz_date DATE,
        start_time TEXT DEFAULT '20:00',
        end_time TEXT DEFAULT '20:30',
        entry_fee INTEGER DEFAULT 10,
        title TEXT DEFAULT 'Weekly Mega Quiz',
        is_active BOOLEAN DEFAULT true,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS doubt_replies (
        id SERIAL PRIMARY KEY,
        post_id INTEGER REFERENCES doubt_posts(id) ON DELETE CASCADE,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        reply_text TEXT NOT NULL,
        image_base64 TEXT,
        is_admin_reply BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Streak columns
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS streak_count INTEGER DEFAULT 0;`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS last_activity_date DATE;`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS longest_streak INTEGER DEFAULT 0;`);

    // Bookmarks
    await pool.query(`
      CREATE TABLE IF NOT EXISTS bookmarks (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        question_text TEXT NOT NULL,
        options JSONB,
        correct_answer TEXT,
        explanation TEXT,
        subject TEXT,
        category TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, question_text)
      );
    `);

    // Achievements
    await pool.query(`
      CREATE TABLE IF NOT EXISTS achievements (
        id SERIAL PRIMARY KEY,
        slug TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT NOT NULL,
        xp_reward INTEGER DEFAULT 0
      );
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS user_achievements (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        achievement_id INTEGER REFERENCES achievements(id) ON DELETE CASCADE,
        unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, achievement_id)
      );
    `);

    // Current Affairs
    await pool.query(`
      CREATE TABLE IF NOT EXISTS current_affairs (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT DEFAULT 'general',
        date DATE DEFAULT CURRENT_DATE,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Reported Questions
    await pool.query(`
      CREATE TABLE IF NOT EXISTS reported_questions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        question_id INTEGER,
        question_text TEXT,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Source URL column for current affairs (auto-fetch)
    await pool.query(`ALTER TABLE current_affairs ADD COLUMN IF NOT EXISTS source_url TEXT DEFAULT '';`);

    // Community Notes (student-uploaded PDFs/images)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS community_notes (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        subject TEXT NOT NULL,
        description TEXT DEFAULT '',
        file_url TEXT NOT NULL,
        file_type TEXT NOT NULL,
        file_size INTEGER DEFAULT 0,
        uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Exam Calendar table (admin-managed + auto-updated dates)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS exam_calendar (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'ssc',
        exam_date DATE,
        end_date DATE,
        type TEXT DEFAULT '',
        description TEXT DEFAULT '',
        seats TEXT DEFAULT '',
        source_url TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Seed exam calendar if empty
    const ecCount = await pool.query("SELECT COUNT(*) FROM exam_calendar");
    if (parseInt(ecCount.rows[0].count) === 0) {
      const exams = [
        { name: "SSC CGL 2025", category: "ssc", exam_date: "2025-06-15", end_date: "2025-07-15", type: "Tier-I", description: "Staff Selection Commission Combined Graduate Level", seats: "17,000+", source_url: "https://ssc.nic.in" },
        { name: "SSC CHSL 2025", category: "ssc", exam_date: "2025-07-10", end_date: "2025-07-30", type: "Tier-I", description: "Combined Higher Secondary Level", seats: "5,000+", source_url: "https://ssc.nic.in" },
        { name: "SSC MTS 2025", category: "ssc", exam_date: "2025-08-01", end_date: "2025-08-30", type: "Exam", description: "Multi-Tasking Staff", seats: "11,000+", source_url: "https://ssc.nic.in" },
        { name: "RRB NTPC 2025", category: "railway", exam_date: "2025-06-01", end_date: "2025-07-01", type: "CBT-1", description: "Railway Non-Technical Popular Category", seats: "11,558", source_url: "https://rrbcdg.gov.in" },
        { name: "RRB Group D 2025", category: "railway", exam_date: "2025-09-01", end_date: "2025-10-01", type: "CBT", description: "Level 1 Railway Recruitment", seats: "32,000+", source_url: "https://rrbcdg.gov.in" },
        { name: "UP Police Constable 2025", category: "police", exam_date: "2025-05-20", end_date: "2025-06-10", type: "Written", description: "Uttar Pradesh Police Constable Bharti", seats: "60,000+", source_url: "https://uppbpb.gov.in" },
        { name: "Delhi Police Constable 2025", category: "police", exam_date: "2025-07-15", end_date: "2025-08-10", type: "CBT", description: "Delhi Police Constable Recruitment", seats: "7,000+", source_url: "https://www.delhipolice.gov.in" },
        { name: "IBPS PO 2025", category: "banking", exam_date: "2025-10-01", end_date: "2025-10-20", type: "Pre", description: "Institute of Banking Personnel Selection — PO/MT", seats: "4,000+", source_url: "https://ibps.in" },
        { name: "IBPS Clerk 2025", category: "banking", exam_date: "2025-11-01", end_date: "2025-11-20", type: "Pre", description: "IBPS Clerk Recruitment", seats: "6,000+", source_url: "https://ibps.in" },
        { name: "SBI PO 2025", category: "banking", exam_date: "2025-06-20", end_date: "2025-07-05", type: "Pre", description: "State Bank of India Probationary Officer", seats: "2,000+", source_url: "https://sbi.co.in/careers" },
        { name: "SBI Clerk 2025", category: "banking", exam_date: "2025-08-10", end_date: "2025-08-28", type: "Pre", description: "SBI Junior Associates", seats: "14,000+", source_url: "https://sbi.co.in/careers" },
      ];
      for (const e of exams) {
        await pool.query(
          "INSERT INTO exam_calendar (name, category, exam_date, end_date, type, description, seats, source_url) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING",
          [e.name, e.category, e.exam_date, e.end_date, e.type, e.description, e.seats, e.source_url]
        );
      }
    }

    // Seed default achievements
    const achRows = [
      { slug: "first_quiz", title: "First Step!", description: "पहली Quiz complete की", icon: "🎯", xp: 10 },
      { slug: "quiz_5", title: "Getting Started", description: "5 Quizzes complete कीं", icon: "📚", xp: 20 },
      { slug: "quiz_25", title: "Quiz Enthusiast", description: "25 Quizzes complete कीं", icon: "🔥", xp: 50 },
      { slug: "quiz_100", title: "Quiz Master", description: "100 Quizzes complete कीं", icon: "👑", xp: 100 },
      { slug: "streak_3", title: "3-Day Streak", description: "3 दिन लगातार active रहे", icon: "🌟", xp: 15 },
      { slug: "streak_7", title: "7-Day Warrior", description: "7 दिन लगातार active रहे", icon: "⚡", xp: 35 },
      { slug: "streak_30", title: "30-Day Legend", description: "30 दिन लगातार active रहे", icon: "🏆", xp: 150 },
      { slug: "xp_100", title: "XP Hunter", description: "100 XP कमाए", icon: "💫", xp: 5 },
      { slug: "xp_500", title: "XP Warrior", description: "500 XP कमाए", icon: "⭐", xp: 25 },
      { slug: "xp_1000", title: "XP Legend", description: "1000 XP कमाए", icon: "🌠", xp: 75 },
      { slug: "coins_50", title: "Coin Collector", description: "50 Coins कमाए", icon: "🪙", xp: 10 },
    ];
    for (const ach of achRows) {
      await pool.query(
        `INSERT INTO achievements (slug, title, description, icon, xp_reward) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (slug) DO NOTHING`,
        [ach.slug, ach.title, ach.description, ach.icon, ach.xp]
      );
    }

    // Seed sample current affairs if empty
    const caCount = await pool.query("SELECT COUNT(*) FROM current_affairs");
    if (parseInt(caCount.rows[0].count) === 0) {
      const sampleCA = [
        { title: "ISRO ने लॉन्च किया नया सैटेलाइट", content: "भारतीय अंतरिक्ष अनुसंधान संगठन (ISRO) ने GSAT-20 सैटेलाइट सफलतापूर्वक लॉन्च किया। यह सैटेलाइट ब्रॉडबैंड इंटरनेट सेवाएं प्रदान करेगा।", category: "science" },
        { title: "RBI ने Repo Rate में बदलाव किया", content: "भारतीय रिजर्व बैंक (RBI) ने मौद्रिक नीति समीक्षा में repo rate को 6.5% पर स्थिर रखा। यह निर्णय महंगाई को नियंत्रित करने के लिए लिया गया।", category: "economy" },
        { title: "भारत का GDP Growth Rate", content: "वित्त वर्ष 2024-25 में भारत की GDP growth rate 7.2% रही। यह विश्व की प्रमुख अर्थव्यवस्थाओं में सबसे तेज़ growth है।", category: "economy" },
        { title: "PM किसान सम्मान निधि की नई किस्त जारी", content: "प्रधानमंत्री किसान सम्मान निधि योजना के तहत ₹2000 की नई किस्त 9 करोड़ से अधिक किसानों के खातों में जारी की गई।", category: "government" },
        { title: "Olympic 2024 में भारत का प्रदर्शन", content: "पेरिस Olympic 2024 में भारत ने 6 पदक जीते — 1 Silver और 5 Bronze। नीरज चोपड़ा ने Javelin Throw में Silver Medal जीता।", category: "sports" },
        { title: "SSC CGL 2025 Notification जारी", content: "Staff Selection Commission ने CGL 2025 का notification जारी किया। इस बार 17,000 से अधिक पदों पर भर्ती होगी। आवेदन की अंतिम तिथि 15 May 2025 है।", category: "exam" },
        { title: "Railway NTPC 2025 Vacancy", content: "रेलवे भर्ती बोर्ड (RRB) ने NTPC 2025 के लिए 11,558 पदों पर notification जारी किया। Graduate और 12th pass दोनों आवेदन कर सकते हैं।", category: "exam" },
        { title: "Digital India Initiative का विस्तार", content: "सरकार ने Digital India Initiative के तहत 1 लाख गाँवों में ब्रॉडबैंड कनेक्टिविटी पहुँचाने का लक्ष्य रखा है।", category: "technology" },
      ];
      for (const ca of sampleCA) {
        await pool.query(
          "INSERT INTO current_affairs (title, content, category) VALUES ($1, $2, $3)",
          [ca.title, ca.content, ca.category]
        );
      }
    }

  } catch (err) {
    logger.error({ err }, "Migration error");
  }
}

async function seedAdmin() {
  try {
    const existing = await pool.query("SELECT id FROM users WHERE is_admin = true LIMIT 1");
    const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    if (existing.rows.length > 0) {
      await pool.query(
        "UPDATE users SET email=$1, password_hash=$2, name=$3 WHERE is_admin=true",
        [ADMIN_EMAIL, hash, ADMIN_NAME]
      );
      logger.info("Admin credentials updated");
    } else {
      await pool.query(
        "INSERT INTO users (name, email, password_hash, is_admin) VALUES ($1,$2,$3,true)",
        [ADMIN_NAME, ADMIN_EMAIL, hash]
      );
      logger.info("Admin user created");
    }
  } catch (err) {
    logger.error({ err }, "Failed to seed admin");
  }
}

const rawPort = process.env["PORT"];
if (!rawPort) throw new Error("PORT environment variable is required but was not provided.");
const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) throw new Error(`Invalid PORT value: "${rawPort}"`);

const httpServer = createServer(app);

const io = new SocketIOServer(httpServer, {
  cors: { origin: true, credentials: true },
  path: "/api/socket.io",
});

setupBattleSocket(io);

async function autoFetchCurrentAffairs() {
  try {
    const xml2js = await import("xml2js");
    const feeds = [
      "https://news.google.com/rss/search?q=SSC+exam+vacancy+2025&hl=hi&gl=IN&ceid=IN:hi",
      "https://news.google.com/rss/search?q=Railway+NTPC+vacancy+2025&hl=hi&gl=IN&ceid=IN:hi",
      "https://news.google.com/rss/search?q=India+government+exam+2025&hl=hi&gl=IN&ceid=IN:hi",
      "https://news.google.com/rss/search?q=current+affairs+India+today&hl=hi&gl=IN&ceid=IN:hi",
    ];
    let inserted = 0;
    for (const url of feeds) {
      try {
        const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(8000) });
        if (!r.ok) continue;
        const text = await r.text();
        const parsed = await xml2js.parseStringPromise(text, { explicitArray: false });
        const items = parsed?.rss?.channel?.item;
        if (!items) continue;
        const list = Array.isArray(items) ? items.slice(0, 5) : [items];
        for (const item of list) {
          const title = (item.title || "").replace(/<[^>]+>/g, "").trim();
          const content = (item.description || item.title || "").replace(/<[^>]+>/g, "").trim();
          const sourceUrl = item.link || "";
          const pubDate = item.pubDate ? new Date(item.pubDate).toISOString().split("T")[0] : new Date().toISOString().split("T")[0];
          if (!title || title.length < 5) continue;
          let category = "general";
          const low = title.toLowerCase() + " " + content.toLowerCase();
          if (low.includes("ssc") || low.includes("railway") || low.includes("police") || low.includes("bank") || low.includes("exam") || low.includes("vacancy") || low.includes("recruitment")) category = "exam";
          else if (low.includes("economy") || low.includes("gdp") || low.includes("inflation") || low.includes("budget")) category = "economy";
          else if (low.includes("sport") || low.includes("cricket") || low.includes("olympic")) category = "sports";
          else if (low.includes("science") || low.includes("technology") || low.includes("isro") || low.includes("space")) category = "science";
          else if (low.includes("government") || low.includes("modi") || low.includes("minister") || low.includes("parliament")) category = "government";
          try {
            const res = await pool.query(
              `INSERT INTO current_affairs (title, content, category, date, source_url) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING RETURNING id`,
              [title.slice(0, 200), content.slice(0, 1000), category, pubDate, sourceUrl]
            );
            if (res.rowCount && res.rowCount > 0) inserted++;
          } catch {}
        }
      } catch {}
    }
    if (inserted > 0) logger.info({ inserted }, "Auto-fetched current affairs");
  } catch (err) {
    logger.error({ err }, "Auto-fetch current affairs failed");
  }
}

function scheduleAutoFetch() {
  const now = new Date();
  const next = new Date();
  next.setHours(6, 0, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);
  const delay = next.getTime() - now.getTime();
  setTimeout(() => {
    autoFetchCurrentAffairs();
    setInterval(autoFetchCurrentAffairs, 24 * 60 * 60 * 1000);
  }, delay);
  logger.info({ nextFetchIn: Math.round(delay / 60000) + " min" }, "Current affairs auto-fetch scheduled");
}

httpServer.listen(port, async () => {
  logger.info({ port }, "Server listening");
  await runMigrations();
  await seedAdmin();
  await seedPracticeQuestions();
  autoFetchCurrentAffairs();
  scheduleAutoFetch();
});
