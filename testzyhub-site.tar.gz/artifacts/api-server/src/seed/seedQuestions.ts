import { pool } from "@workspace/db";
import { sscQuestions } from "./ssc-questions";
import { railwayQuestions } from "./railway-questions";
import { policeQuestions } from "./police-questions";
import { bankingQuestions } from "./banking-questions";

type SeedQ = { subject: string; question: string; a: string; b: string; c: string; d: string; correct: number; exp?: string };

const categoryMap: Array<{ category: string; questions: SeedQ[] }> = [
  { category: "ssc", questions: sscQuestions },
  { category: "railway", questions: railwayQuestions },
  { category: "police", questions: policeQuestions },
  { category: "banking", questions: bankingQuestions },
];

export async function seedPracticeQuestions() {
  try {
    const countRes = await pool.query(
      `SELECT COUNT(*) FROM db_questions WHERE quiz_type = 'practice' AND subject != ''`
    );
    const existing = parseInt(countRes.rows[0]?.count ?? "0", 10);
    if (existing >= 400) {
      return; // Already seeded
    }

    let inserted = 0;
    for (const { category, questions } of categoryMap) {
      for (const q of questions) {
        await pool.query(
          `INSERT INTO db_questions (category, quiz_type, set_number, subject, question, option_a, option_b, option_c, option_d, correct_option, explanation)
           VALUES ($1, 'practice', 1, $2, $3, $4, $5, $6, $7, $8, $9)
           ON CONFLICT DO NOTHING`,
          [category, q.subject, q.question, q.a, q.b, q.c, q.d, q.correct, q.exp ?? ""]
        );
        inserted++;
      }
    }

    console.log(`[Seed] Inserted ${inserted} practice questions.`);
  } catch (err) {
    console.error("[Seed] Error seeding questions:", err);
  }
}
