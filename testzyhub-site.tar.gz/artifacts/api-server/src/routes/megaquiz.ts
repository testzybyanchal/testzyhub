import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

function getWeekStart(): string {
  const now = new Date();
  const day = now.getDay();
  const monday = new Date(now);
  monday.setDate(now.getDate() - ((day + 6) % 7));
  return monday.toISOString().slice(0, 10);
}

// Get current mega quiz info
router.get("/megaquiz/info", async (req, res) => {
  const weekOf = getWeekStart();
  try {
    const regCount = await pool.query(
      "SELECT COUNT(*) FROM mega_quiz_registrations WHERE week_of=$1 AND entry_paid=true",
      [weekOf]
    );
    const totalPrize = parseInt(regCount.rows[0].count) * 10;
    const prizePool = [
      { rank: 1, prize: Math.floor(totalPrize * 0.5) },
      { rank: 2, prize: Math.floor(totalPrize * 0.3) },
      { rank: 3, prize: Math.floor(totalPrize * 0.15) },
    ];

    let userReg = null;
    if (req.session.userId) {
      const reg = await pool.query(
        "SELECT * FROM mega_quiz_registrations WHERE user_id=$1 AND week_of=$2",
        [req.session.userId, weekOf]
      );
      userReg = reg.rows[0] || null;
    }

    // Quiz happens every Sunday 8 PM
    const quizDate = new Date(weekOf);
    quizDate.setDate(quizDate.getDate() + 6);
    quizDate.setHours(20, 0, 0, 0);

    res.json({
      weekOf,
      quizDate: quizDate.toISOString(),
      totalParticipants: parseInt(regCount.rows[0].count),
      entryFee: 10,
      prizePool,
      totalPrize,
      userRegistered: userReg?.entry_paid || false,
      userReg,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// Create Razorpay order for ₹10 entry
router.post("/megaquiz/create-order", async (req, res) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Login required" });
    return;
  }
  const weekOf = getWeekStart();

  try {
    const existing = await pool.query(
      "SELECT * FROM mega_quiz_registrations WHERE user_id=$1 AND week_of=$2 AND entry_paid=true",
      [req.session.userId, weekOf]
    );
    if (existing.rows.length > 0) {
      res.status(400).json({ error: "आप पहले से registered हैं इस week के लिए" });
      return;
    }

    const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID;
    const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;

    if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
      res.status(503).json({ error: "Payment gateway abhi setup nahi hai. Admin se contact karein." });
      return;
    }

    const Razorpay = (globalThis as any).require("razorpay");
    const razorpay = new Razorpay({ key_id: RAZORPAY_KEY_ID, key_secret: RAZORPAY_KEY_SECRET });

    const order = await razorpay.orders.create({
      amount: 1000, // ₹10 in paise
      currency: "INR",
      receipt: `mega_${req.session.userId}_${weekOf}`,
    });

    await pool.query(
      "INSERT INTO mega_quiz_registrations (user_id, week_of, razorpay_order_id, entry_paid) VALUES ($1,$2,$3,false) ON CONFLICT(user_id,week_of) DO UPDATE SET razorpay_order_id=$3",
      [req.session.userId, weekOf, order.id]
    );

    res.json({ orderId: order.id, amount: 1000, currency: "INR", keyId: RAZORPAY_KEY_ID });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Order create karne mein error" });
  }
});

// Verify payment and confirm registration
router.post("/megaquiz/verify-payment", async (req, res) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Login required" });
    return;
  }
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  const weekOf = getWeekStart();

  try {
    const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;
    if (!RAZORPAY_KEY_SECRET) {
      res.status(503).json({ error: "Payment gateway not configured" });
      return;
    }

    const crypto = await import("node:crypto");
    const expectedSig = crypto
      .createHmac("sha256", RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");

    if (expectedSig !== razorpay_signature) {
      res.status(400).json({ error: "Payment verification failed" });
      return;
    }

    await pool.query(
      "UPDATE mega_quiz_registrations SET entry_paid=true, razorpay_payment_id=$1 WHERE user_id=$2 AND week_of=$3",
      [razorpay_payment_id, req.session.userId, weekOf]
    );

    res.json({ success: true, message: "Registration confirmed! Quiz Sunday 8 PM को होगी।" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Payment verify karne mein error" });
  }
});

// ── Mega Quiz Settings ──────────────────────────────────────────────────────

// GET settings (public)
router.get("/mega-quiz/settings", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM mega_quiz_settings ORDER BY id DESC LIMIT 1"
    );
    if (result.rows.length === 0) {
      res.json({
        quiz_date: null,
        start_time: "20:00",
        end_time: "20:30",
        entry_fee: 10,
        title: "Weekly Mega Quiz",
        is_active: true,
        prizes: [],
      });
      return;
    }
    const settings = result.rows[0];
    const prizes = await pool.query("SELECT * FROM prizes ORDER BY rank_position ASC");
    res.json({ ...settings, prizes: prizes.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// PUT settings (admin only)
router.put("/mega-quiz/settings", async (req, res) => {
  if (!req.session.isAdmin) {
    res.status(403).json({ error: "Admin only" });
    return;
  }
  const { quiz_date, start_time, end_time, entry_fee, title, is_active } = req.body;
  try {
    const existing = await pool.query("SELECT id FROM mega_quiz_settings LIMIT 1");
    if (existing.rows.length === 0) {
      await pool.query(
        "INSERT INTO mega_quiz_settings (quiz_date, start_time, end_time, entry_fee, title, is_active) VALUES ($1,$2,$3,$4,$5,$6)",
        [quiz_date || null, start_time || "20:00", end_time || "20:30", entry_fee || 10, title || "Weekly Mega Quiz", is_active !== false]
      );
    } else {
      await pool.query(
        "UPDATE mega_quiz_settings SET quiz_date=$1, start_time=$2, end_time=$3, entry_fee=$4, title=$5, is_active=$6, updated_at=NOW() WHERE id=$7",
        [quiz_date || null, start_time || "20:00", end_time || "20:30", entry_fee || 10, title || "Weekly Mega Quiz", is_active !== false, existing.rows[0].id]
      );
    }
    const result = await pool.query("SELECT * FROM mega_quiz_settings ORDER BY id DESC LIMIT 1");
    res.json({ success: true, settings: result.rows[0] });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// Get leaderboard for current mega quiz
router.get("/megaquiz/leaderboard", async (req, res) => {
  const weekOf = getWeekStart();
  try {
    const result = await pool.query(
      `SELECT mqr.rank_position, mqr.score, u.name, u.level
       FROM mega_quiz_registrations mqr
       JOIN users u ON mqr.user_id=u.id
       WHERE mqr.week_of=$1 AND mqr.entry_paid=true
       ORDER BY mqr.score DESC, mqr.created_at ASC
       LIMIT 20`,
      [weekOf]
    );
    res.json({ leaderboard: result.rows, weekOf });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
