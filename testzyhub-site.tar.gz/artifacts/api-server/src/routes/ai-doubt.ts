import { Router } from "express";
import { GoogleGenAI } from "@google/genai";

const router = Router();

const ai = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY || "dummy",
  baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
});

router.post("/api/ai-doubt/solve", async (req, res) => {
  try {
    const { question, subject } = req.body;
    if (!question?.trim()) return res.status(400).json({ error: "Question required" });

    const prompt = `You are an expert Indian government exam tutor (SSC, Railway, Police, Banking). 
A student has asked the following doubt in ${subject || "General"} subject:

"${question}"

Please answer in HINDI and ENGLISH mixed (Hinglish style that Indian students understand).
Format your answer as:
1. Direct Answer (1-2 lines)
2. Explanation (step by step if needed)
3. Trick/Shortcut to remember (if applicable)
4. Similar example (if helpful)

Keep the answer concise, exam-focused, and easy to understand for government exam aspirants.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: { maxOutputTokens: 8192 },
    });

    const answer = response.text || "Sorry, answer generate nahi ho saka. Please try again.";
    res.json({ answer, question });
  } catch (err: any) {
    console.error("AI Doubt error:", err.message);
    res.status(500).json({ error: "AI service unavailable" });
  }
});

export default router;
