import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/achievements", async (req, res) => {
  try {
    const all = await pool.query("SELECT * FROM achievements ORDER BY id");
    let unlockedIds: number[] = [];
    if (req.session.userId) {
      const ur = await pool.query(
        "SELECT achievement_id, unlocked_at FROM user_achievements WHERE user_id=$1",
        [req.session.userId]
      );
      unlockedIds = ur.rows.map((r) => r.achievement_id);
    }
    res.json({ achievements: all.rows, unlocked: unlockedIds });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/achievements/check", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const userId = req.session.userId;
  try {
    const userResult = await pool.query(
      "SELECT xp, streak_count, coins FROM users WHERE id=$1",
      [userId]
    );
    if (!userResult.rows.length) return res.json({ newUnlocked: [] });
    const user = userResult.rows[0];

    const quizCount = await pool.query(
      "SELECT COUNT(*) as cnt FROM quiz_submissions WHERE user_id=$1",
      [userId]
    );
    const count = parseInt(quizCount.rows[0].cnt);

    const allAchs = await pool.query("SELECT * FROM achievements");
    const unlockedResult = await pool.query(
      "SELECT achievement_id FROM user_achievements WHERE user_id=$1",
      [userId]
    );
    const unlockedSet = new Set(unlockedResult.rows.map((r) => r.achievement_id));

    const newUnlocked = [];
    for (const ach of allAchs.rows) {
      if (unlockedSet.has(ach.id)) continue;
      let shouldUnlock = false;
      switch (ach.slug) {
        case "first_quiz": shouldUnlock = count >= 1; break;
        case "quiz_5": shouldUnlock = count >= 5; break;
        case "quiz_25": shouldUnlock = count >= 25; break;
        case "quiz_100": shouldUnlock = count >= 100; break;
        case "streak_3": shouldUnlock = (user.streak_count || 0) >= 3; break;
        case "streak_7": shouldUnlock = (user.streak_count || 0) >= 7; break;
        case "streak_30": shouldUnlock = (user.streak_count || 0) >= 30; break;
        case "xp_100": shouldUnlock = (user.xp || 0) >= 100; break;
        case "xp_500": shouldUnlock = (user.xp || 0) >= 500; break;
        case "xp_1000": shouldUnlock = (user.xp || 0) >= 1000; break;
        case "coins_50": shouldUnlock = (user.coins || 0) >= 50; break;
      }
      if (shouldUnlock) {
        await pool.query(
          "INSERT INTO user_achievements (user_id, achievement_id) VALUES ($1,$2) ON CONFLICT DO NOTHING",
          [userId, ach.id]
        );
        if (ach.xp_reward > 0) {
          await pool.query("UPDATE users SET xp = xp + $1 WHERE id=$2", [ach.xp_reward, userId]);
        }
        newUnlocked.push(ach);
      }
    }
    res.json({ newUnlocked });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
