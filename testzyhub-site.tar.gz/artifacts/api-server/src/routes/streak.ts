import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.post("/streak/update", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const userId = req.session.userId;
  try {
    const result = await pool.query(
      "SELECT streak_count, last_activity_date, longest_streak FROM users WHERE id=$1",
      [userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "User not found" });
    const user = result.rows[0];
    const today = new Date().toISOString().split("T")[0];
    const lastDate = user.last_activity_date
      ? new Date(user.last_activity_date).toISOString().split("T")[0]
      : null;
    let newStreak = user.streak_count || 0;
    if (lastDate === today) {
      return res.json({ streak: newStreak, longest: user.longest_streak || 0 });
    } else if (lastDate) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yStr = yesterday.toISOString().split("T")[0];
      newStreak = lastDate === yStr ? newStreak + 1 : 1;
    } else {
      newStreak = 1;
    }
    const longest = Math.max(newStreak, user.longest_streak || 0);
    await pool.query(
      "UPDATE users SET streak_count=$1, last_activity_date=$2, longest_streak=$3 WHERE id=$4",
      [newStreak, today, longest, userId]
    );
    res.json({ streak: newStreak, longest });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/streak", async (req, res) => {
  if (!req.session.userId) return res.json({ streak: 0, longest: 0 });
  try {
    const result = await pool.query(
      "SELECT streak_count, longest_streak FROM users WHERE id=$1",
      [req.session.userId]
    );
    if (result.rows.length === 0) return res.json({ streak: 0, longest: 0 });
    const u = result.rows[0];
    res.json({ streak: u.streak_count || 0, longest: u.longest_streak || 0 });
  } catch {
    res.json({ streak: 0, longest: 0 });
  }
});

export default router;
