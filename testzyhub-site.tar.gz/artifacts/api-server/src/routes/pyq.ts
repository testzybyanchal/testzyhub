import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/api/pyq", async (req, res) => {
  try {
    const { exam, year, subject, limit = "20", offset = "0" } = req.query as Record<string, string>;
    let where = "WHERE 1=1";
    const params: any[] = [];
    let idx = 1;
    if (exam) { where += ` AND exam = $${idx++}`; params.push(exam); }
    if (year) { where += ` AND year = $${idx++}`; params.push(parseInt(year)); }
    if (subject) { where += ` AND subject = $${idx++}`; params.push(subject); }

    const countRes = await pool.query(`SELECT COUNT(*) FROM pyq_papers ${where}`, params);
    const total = parseInt(countRes.rows[0].count);

    params.push(parseInt(limit));
    params.push(parseInt(offset));
    const result = await pool.query(
      `SELECT * FROM pyq_papers ${where} ORDER BY year DESC, id ASC LIMIT $${idx++} OFFSET $${idx++}`,
      params
    );
    res.json({ papers: result.rows, total });
  } catch (err) {
    res.status(500).json({ error: "DB error" });
  }
});

router.get("/api/pyq/filters", async (req, res) => {
  try {
    const exams = await pool.query("SELECT DISTINCT exam FROM pyq_papers ORDER BY exam");
    const years = await pool.query("SELECT DISTINCT year FROM pyq_papers ORDER BY year DESC");
    const subjects = await pool.query("SELECT DISTINCT subject FROM pyq_papers ORDER BY subject");
    res.json({
      exams: exams.rows.map(r => r.exam),
      years: years.rows.map(r => r.year),
      subjects: subjects.rows.map(r => r.subject),
    });
  } catch {
    res.json({ exams: ["SSC CGL", "SSC CHSL", "Railway NTPC", "Railway Group D", "UP Police", "IBPS PO", "SBI Clerk"], years: [2024, 2023, 2022, 2021, 2020, 2019], subjects: ["Math", "GK", "Reasoning", "English", "Science", "Hindi"] });
  }
});

router.post("/api/admin/pyq", async (req, res) => {
  const user = (req as any).user;
  if (!user?.is_admin) return res.status(403).json({ error: "Admin only" });
  try {
    const { exam, year, subject, question, option_a, option_b, option_c, option_d, correct_answer, explanation, difficulty } = req.body;
    const result = await pool.query(
      `INSERT INTO pyq_papers (exam, year, subject, question, option_a, option_b, option_c, option_d, correct_answer, explanation, difficulty)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [exam, year, subject, question, option_a, option_b, option_c, option_d, correct_answer, explanation || null, difficulty || "medium"]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: "DB error" });
  }
});

router.delete("/api/admin/pyq/:id", async (req, res) => {
  const user = (req as any).user;
  if (!user?.is_admin) return res.status(403).json({ error: "Admin only" });
  await pool.query("DELETE FROM pyq_papers WHERE id=$1", [req.params.id]);
  res.json({ ok: true });
});

export default router;
