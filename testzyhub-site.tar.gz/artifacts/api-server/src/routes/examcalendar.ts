import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/exam-calendar/live", async (req, res) => {
  try {
    const rows = await pool.query(
      "SELECT * FROM exam_calendar ORDER BY exam_date ASC"
    );
    res.json({ exams: rows.rows });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/exam-calendar", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id=$1", [req.session.userId]);
  if (!adminCheck.rows[0]?.is_admin) return res.status(403).json({ error: "Not admin" });
  const { name, category, exam_date, end_date, type, description, seats, source_url } = req.body;
  try {
    await pool.query(
      "INSERT INTO exam_calendar (name, category, exam_date, end_date, type, description, seats, source_url) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING",
      [name, category, exam_date, end_date || null, type || "", description || "", seats || "", source_url || ""]
    );
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: "Server error" });
  }
});

router.delete("/exam-calendar/:id", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id=$1", [req.session.userId]);
  if (!adminCheck.rows[0]?.is_admin) return res.status(403).json({ error: "Not admin" });
  try {
    await pool.query("DELETE FROM exam_calendar WHERE id=$1", [req.params.id]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
