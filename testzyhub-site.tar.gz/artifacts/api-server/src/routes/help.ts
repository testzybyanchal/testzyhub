import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

// Submit a help query
router.post("/help/query", async (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!name?.trim() || !message?.trim() || !subject?.trim()) {
    res.status(400).json({ error: "सभी fields भरें" });
    return;
  }
  try {
    await pool.query(
      "INSERT INTO help_queries (user_id, name, email, subject, message, status) VALUES ($1,$2,$3,$4,$5,'open')",
      [req.session.userId || null, name.trim(), email?.trim() || null, subject.trim(), message.trim()]
    );
    res.json({ success: true, message: "✅ आपकी query submit हो गई! 24–48 घंटों में जवाब मिलेगा।" });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// Admin: get all queries
router.get("/admin/help-queries", async (req, res) => {
  if (!req.session.isAdmin) { res.status(403).json({ error: "Forbidden" }); return; }
  try {
    const result = await pool.query(
      `SELECT id, name, email, subject, message, status, admin_reply, created_at
       FROM help_queries
       ORDER BY status='open' DESC, created_at DESC`
    );
    res.json({ queries: result.rows });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// Admin: reply to a query
router.patch("/admin/help-queries/:id", async (req, res) => {
  if (!req.session.isAdmin) { res.status(403).json({ error: "Forbidden" }); return; }
  const { reply, status } = req.body;
  try {
    await pool.query(
      "UPDATE help_queries SET admin_reply=$1, status=$2 WHERE id=$3",
      [reply?.trim() || null, status || "resolved", req.params.id]
    );
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
