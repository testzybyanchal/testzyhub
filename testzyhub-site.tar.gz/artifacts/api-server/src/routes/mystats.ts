import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/my-stats", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const userId = req.session.userId;
  try {
    const [totalR, recentR, subjectR, userR, bookmarkR] = await Promise.all([
      pool.query("SELECT COUNT(*) as total FROM quiz_submissions WHERE user_id=$1", [userId]),
      pool.query(
        "SELECT score, total_questions, category, subject, created_at FROM quiz_submissions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 10",
        [userId]
      ),
      pool.query(
        `SELECT subject, COUNT(*) as attempts,
         ROUND(AVG(CASE WHEN total_questions > 0 THEN score::float / total_questions * 100 ELSE 0 END)) as accuracy
         FROM quiz_submissions WHERE user_id=$1 AND subject IS NOT NULL AND subject != ''
         GROUP BY subject ORDER BY accuracy ASC LIMIT 10`,
        [userId]
      ),
      pool.query(
        "SELECT xp, coins, level, streak_count, longest_streak FROM users WHERE id=$1",
        [userId]
      ),
      pool.query("SELECT COUNT(*) as total FROM bookmarks WHERE user_id=$1", [userId]),
    ]);
    res.json({
      total_quizzes: parseInt(totalR.rows[0].total),
      recent: recentR.rows,
      by_subject: subjectR.rows,
      user: userR.rows[0] || {},
      bookmarks_count: parseInt(bookmarkR.rows[0].total),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/questions/report", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const { question_text, reason } = req.body;
  try {
    await pool.query(
      "INSERT INTO reported_questions (user_id, question_text, reason) VALUES ($1,$2,$3)",
      [req.session.userId, question_text, reason || "Incorrect question"]
    );
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
