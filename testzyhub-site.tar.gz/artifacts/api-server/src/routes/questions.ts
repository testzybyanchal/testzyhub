import { Router } from "express";
import multer from "multer";
import { pool } from "@workspace/db";

// pdf-parse is CJS-only; use require at runtime
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const pdfParse: (buf: Buffer) => Promise<{ text: string }> = (globalThis as any).require("pdf-parse");

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// DB-based admin check — more reliable than session.isAdmin in production
async function isAdmin(req: import("express").Request): Promise<boolean> {
  if (!req.session.userId) return false;
  try {
    // First try session flag (fast path)
    if (req.session.isAdmin === true) return true;
    // Fallback: verify from DB (handles stale sessions)
    const r = await pool.query("SELECT is_admin FROM users WHERE id=$1", [req.session.userId]);
    return r.rows[0]?.is_admin === true;
  } catch {
    return false;
  }
}

// ──── PARSE QUESTION TEXT — UNIVERSAL FORMAT ─────────────────────────────────
type ParsedQuestion = {
  question: string; option_a: string; option_b: string;
  option_c: string; option_d: string; correct_option: number; explanation: string;
};

function answerIndex(ans: string): number {
  const a = ans.trim().toUpperCase();
  if (a === "A" || a === "1" || a === "अ") return 0;
  if (a === "B" || a === "2" || a === "ब") return 1;
  if (a === "C" || a === "3" || a === "स" || a === "ग") return 2;
  if (a === "D" || a === "4" || a === "द") return 3;
  return 0;
}

// Option prefixes we recognise (A/B/C/D, a/b/c/d, 1/2/3/4, अ/ब/स/द, i/ii/iii/iv)
const OPT_PREFIXES = [
  /^\s*\(?\s*([Aa])\s*[\).\-:]\s*/,
  /^\s*\(?\s*([Bb])\s*[\).\-:]\s*/,
  /^\s*\(?\s*([Cc])\s*[\).\-:]\s*/,
  /^\s*\(?\s*([Dd])\s*[\).\-:]\s*/,
];
const OPT_ANY = /^\s*[\(\[]?\s*([AaBbCcDd1-4]|[iI]{1,3}[vV]?|अ|ब|स|ग|द)\s*[\)\].\-:]\s*(.+)/;
const Q_PREFIX = /^(?:Q\.?\s*\d+[\.\):\-]?\s*|\d+[\.\)\-]\s*|[^\w\d]*\d+[\.]\s*)/i;
const ANS_LINE = /^(?:ans(?:wer)?|उत्तर|सही\s*उत्तर|correct(?:\s*ans(?:wer)?)?|sol(?:ution)?|key)\s*[:\-]?\s*([ABCDabcd1-4]|[अब सगद])/i;
const EXP_LINE = /^(?:exp(?:lanation)?|expl|व्याख्या|solution|sol|explanation)\s*[:\-]?\s*(.*)/i;

function normalizeText(raw: string): string {
  return raw
    .replace(/\r\n/g, "\n").replace(/\r/g, "\n")
    // Remove form feeds, null bytes
    .replace(/[\f\x00]/g, "\n")
    // Collapse more than 2 consecutive newlines
    .replace(/\n{3,}/g, "\n\n")
    // Inject newlines before question markers that appear mid-line
    .replace(/(?<!\n)((?:Q\.?\s*)?\d+[\.\)]\s+[A-Za-z\u0900-\u097F])/g, "\n$1")
    // Inject newlines before option markers mid-line
    .replace(/(?<!\n)(\s+[ABCD]\s*[).\-]\s+)/g, "\n$1");
}

function isOptionLine(line: string): boolean {
  return OPT_ANY.test(line.trim());
}
function isQuestionLine(line: string): boolean {
  return Q_PREFIX.test(line.trim());
}
function isAnswerLine(line: string): boolean {
  return ANS_LINE.test(line.trim());
}
function isExpLine(line: string): boolean {
  return EXP_LINE.test(line.trim());
}

function parseQuestionsFromText(text: string): ParsedQuestion[] {
  const results: ParsedQuestion[] = [];
  const lines = normalizeText(text).split("\n");

  let i = 0;
  while (i < lines.length) {
    const line = lines[i].trim();

    // ── Find question start ───────────────────────────────────────────────────
    if (!isQuestionLine(line)) { i++; continue; }

    // Remove Q1. / 1. / 1) prefix
    let questionText = line.replace(Q_PREFIX, "").trim();
    if (!questionText) { i++; continue; }

    i++;

    // Collect multi-line question text (until first option line or blank)
    while (i < lines.length) {
      const next = lines[i].trim();
      if (!next) break;
      if (isOptionLine(next)) break;
      if (isQuestionLine(next)) break;
      if (isAnswerLine(next)) break;
      questionText += " " + next;
      i++;
    }
    questionText = questionText.trim();

    // Check if question itself contains all options inline (compact format)
    // e.g. "What is X? A) Y B) Z C) P D) Q Ans: B"
    const inlineOpts = questionText.match(
      /^(.+?)\s+[(\[]?[Aa][)\].:\-]\s*(.+?)\s+[(\[]?[Bb][)\].:\-]\s*(.+?)\s+[(\[]?[Cc][)\].:\-]\s*(.+?)\s+[(\[]?[Dd][)\].:\-]\s*(.+?)(?:\s+(?:Ans|Answer|उत्तर)[:\-]?\s*([ABCDabcd1-4])(.*))?$/
    );
    if (inlineOpts) {
      const expPart = (inlineOpts[7] || "").replace(EXP_LINE, "$1").trim();
      results.push({
        question: inlineOpts[1].trim(),
        option_a: inlineOpts[2].trim(),
        option_b: inlineOpts[3].trim(),
        option_c: inlineOpts[4].trim(),
        option_d: inlineOpts[5].trim(),
        correct_option: inlineOpts[6] ? answerIndex(inlineOpts[6]) : 0,
        explanation: expPart,
      });
      continue;
    }

    // ── Collect options ───────────────────────────────────────────────────────
    const opts: string[] = [];
    while (i < lines.length && opts.length < 4) {
      const optLine = lines[i].trim();
      if (!optLine) { i++; continue; }
      if (isAnswerLine(optLine) || isExpLine(optLine)) break;
      if (isQuestionLine(optLine) && !isOptionLine(optLine)) break;

      const om = optLine.match(OPT_ANY);
      if (om) {
        let optText = om[2].trim();
        i++;
        // Collect multi-line option text
        while (i < lines.length) {
          const next = lines[i].trim();
          if (!next) break;
          if (isOptionLine(next) || isAnswerLine(next) || isExpLine(next)) break;
          if (isQuestionLine(next)) break;
          optText += " " + next;
          i++;
        }
        opts.push(optText.trim());
      } else {
        break;
      }
    }

    if (opts.length < 4) continue; // Not enough options — skip

    // ── Find answer & explanation ─────────────────────────────────────────────
    let correct = 0;
    let explanation = "";

    // Look ahead up to 6 lines for answer
    for (let k = 0; k < 6 && i + k < lines.length; k++) {
      const l = lines[i + k].trim();
      if (!l) continue;
      if (isQuestionLine(l) && !isAnswerLine(l)) break;

      const am = l.match(ANS_LINE);
      if (am) { correct = answerIndex(am[1]); i += k + 1; break; }

      const em = l.match(EXP_LINE);
      if (em && em[1]) { explanation = em[1].trim(); }
    }

    // If no explicit answer found, skip to next question marker
    while (i < lines.length) {
      const l = lines[i].trim();
      if (!l || isQuestionLine(l)) break;
      if (isAnswerLine(l)) { i++; break; }
      if (isExpLine(l)) { 
        const em = l.match(EXP_LINE);
        if (em?.[1]) explanation = em[1].trim();
        i++; continue;
      }
      i++;
    }

    results.push({
      question: questionText,
      option_a: opts[0] || "",
      option_b: opts[1] || "",
      option_c: opts[2] || "",
      option_d: opts[3] || "",
      correct_option: correct,
      explanation,
    });
  }

  return results;
}

// ──── STATS (question count — public) ─────────────────────────────────────────
router.get("/stats", async (_req, res) => {
  try {
    const result = await pool.query("SELECT COUNT(*) AS total FROM db_questions");
    const total = parseInt(result.rows[0]?.total ?? "0", 10);
    res.json({ total });
  } catch {
    res.json({ total: 0 });
  }
});

// ──── GET QUESTIONS ───────────────────────────────────────────────────────────
router.get("/questions", async (req, res) => {
  const { category, type, set, subject } = req.query;
  try {
    let query = "SELECT * FROM db_questions";
    const params: (string | number)[] = [];
    const conditions: string[] = [];
    if (category) { conditions.push(`category = $${params.length + 1}`); params.push(category as string); }
    if (type) { conditions.push(`quiz_type = $${params.length + 1}`); params.push(type as string); }
    if (set) { conditions.push(`set_number = $${params.length + 1}`); params.push(parseInt(set as string, 10)); }
    if (subject) { conditions.push(`subject = $${params.length + 1}`); params.push(subject as string); }
    if (conditions.length) query += " WHERE " + conditions.join(" AND ");
    query += " ORDER BY RANDOM() LIMIT 50";
    const result = await pool.query(query, params);
    res.json({
      questions: result.rows.map((r) => ({
        id: r.id,
        category: r.category,
        quiz_type: r.quiz_type,
        set_number: r.set_number || 1,
        subject: r.subject || "",
        question: r.question,
        options: [r.option_a, r.option_b, r.option_c, r.option_d],
        correct: r.correct_option,
        explanation: r.explanation,
      })),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ──── GET SUBJECTS FOR A CATEGORY ─────────────────────────────────────────────
router.get("/subjects", async (req, res) => {
  const { category } = req.query;
  try {
    const conditions: string[] = [`quiz_type = 'practice'`, `subject != ''`];
    const params: string[] = [];
    if (category) { conditions.push(`category = $${params.length + 1}`); params.push(category as string); }
    const result = await pool.query(
      `SELECT DISTINCT subject, COUNT(*) as count FROM db_questions WHERE ${conditions.join(" AND ")} GROUP BY subject ORDER BY subject`,
      params
    );
    res.json({ subjects: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ──── PREVIEW PDF / TXT (parse only, no DB insert) ───────────────────────────
router.post("/admin/preview-questions", upload.single("file"), async (req, res) => {
  if (!(await isAdmin(req))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  if (!req.file) {
    res.status(400).json({ error: "File upload nahi mili" });
    return;
  }
  try {
    let text = "";
    const mime = req.file.mimetype;
    if (mime === "application/pdf" || req.file.originalname?.endsWith(".pdf")) {
      const parsed = await pdfParse(req.file.buffer);
      text = parsed.text;
    } else {
      text = req.file.buffer.toString("utf-8");
    }
    if (!text.trim()) {
      res.status(400).json({ error: "File mein content nahi mila" });
      return;
    }
    const parsed = parseQuestionsFromText(text);
    res.json({
      total: parsed.length,
      questions: parsed.slice(0, 5), // first 5 as preview
      rawSnippet: text.slice(0, 500), // first 500 chars for debugging
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "File parse karne mein error: " + (err as Error).message });
  }
});

// ──── UPLOAD PDF / TXT ────────────────────────────────────────────────────────
router.post("/admin/upload-questions", upload.single("file"), async (req, res) => {
  if (!(await isAdmin(req))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  if (!req.file) {
    res.status(400).json({ error: "File upload nahi mili" });
    return;
  }
  const { category, quiz_type, set_number, subject } = req.body;
  if (!category || !quiz_type) {
    res.status(400).json({ error: "Category aur quiz type select karein" });
    return;
  }
  const setNum = parseInt(set_number || "1", 10) || 1;
  const subjectVal = (subject || "").trim();

  try {
    let text = "";
    const mime = req.file.mimetype;

    if (mime === "application/pdf" || req.file.originalname?.endsWith(".pdf")) {
      const parsed = await pdfParse(req.file.buffer);
      text = parsed.text;
    } else {
      text = req.file.buffer.toString("utf-8");
    }

    if (!text.trim()) {
      res.status(400).json({ error: "File mein content nahi mila" });
      return;
    }

    const parsed = parseQuestionsFromText(text);
    if (parsed.length === 0) {
      res.status(400).json({
        error: "Koi question parse nahi hua. Format check karein.",
        hint: "Format: Q1. Question?\nA) Option\nB) Option\nC) Option\nD) Option\nAns: B"
      });
      return;
    }

    let inserted = 0;
    for (const q of parsed) {
      await pool.query(
        `INSERT INTO db_questions (category, quiz_type, set_number, subject, question, option_a, option_b, option_c, option_d, correct_option, explanation, uploaded_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [category, quiz_type, setNum, subjectVal, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_option, q.explanation, req.session.userId]
      );
      inserted++;
    }

    res.json({ success: true, inserted, total: parsed.length });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "File process karne mein error: " + (err as Error).message });
  }
});

// ──── DELETE QUESTION ─────────────────────────────────────────────────────────
router.delete("/admin/questions/:id", async (req, res) => {
  if (!(await isAdmin(req))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  try {
    await pool.query("DELETE FROM db_questions WHERE id = $1", [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ──── BULK DELETE QUESTIONS (admin) ───────────────────────────────────────────
router.post("/admin/questions/bulk-delete", async (req, res) => {
  if (!(await isAdmin(req))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const { ids } = req.body as { ids: number[] };
  if (!Array.isArray(ids) || ids.length === 0) {
    res.status(400).json({ error: "IDs required" });
    return;
  }
  try {
    await pool.query(
      `DELETE FROM db_questions WHERE id = ANY($1::int[])`,
      [ids]
    );
    res.json({ success: true, deleted: ids.length });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Delete error" });
  }
});

// ──── GET MOCK SETS for a category (student) ─────────────────────────────────
router.get("/quiz/mock-sets", async (req, res) => {
  const { category, type } = req.query;
  const quizType = (type as string) || "mock";
  try {
    // Get distinct set_numbers for this category+type
    const setsResult = await pool.query(
      `SELECT DISTINCT set_number, COUNT(*) as question_count
       FROM db_questions
       WHERE category = $1 AND quiz_type = $2
       GROUP BY set_number ORDER BY set_number`,
      [category, quizType]
    );
    const sets = setsResult.rows;

    // Check which sets current user has completed
    let completedSets: number[] = [];
    if (req.session?.userId) {
      const today = new Date();
      const completedResult = await pool.query(
        `SELECT DISTINCT set_number FROM quiz_submissions
         WHERE user_id = $1 AND quiz_type = $2 AND category = $3`,
        [req.session.userId, quizType, category]
      );
      completedSets = completedResult.rows.map((r: any) => r.set_number || 1);
    }

    res.json({ sets, completedSets });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ──── GET ALL UPLOADED QUESTIONS (admin) ──────────────────────────────────────
router.get("/admin/questions", async (req, res) => {
  if (!(await isAdmin(req))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const { category, type } = req.query;
  try {
    let query = "SELECT *, id FROM db_questions";
    const params: string[] = [];
    const conditions: string[] = [];
    if (category && category !== "all") { conditions.push(`category = $${params.length + 1}`); params.push(category as string); }
    if (type && type !== "all") { conditions.push(`quiz_type = $${params.length + 1}`); params.push(type as string); }
    if (conditions.length) query += " WHERE " + conditions.join(" AND ");
    query += " ORDER BY created_at DESC LIMIT 100";
    const result = await pool.query(query, params);
    res.json({ questions: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ──── GET ALL USERS (admin) ───────────────────────────────────────────────────
router.get("/admin/users", async (req, res) => {
  if (!(await isAdmin(req))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  try {
    const result = await pool.query(
      `SELECT id, phone, name, xp, coins, level, created_at, is_admin
       FROM users ORDER BY created_at DESC LIMIT 500`
    );
    res.json({ users: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
