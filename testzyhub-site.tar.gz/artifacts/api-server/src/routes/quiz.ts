import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

function getLevel(xp: number): string {
  if (xp >= 1000) return "Master";
  if (xp >= 500) return "Pro";
  if (xp >= 200) return "Intermediate";
  return "Beginner";
}

router.post("/quiz/submit", async (req, res) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Login required" });
    return;
  }
  const { quizType, category, correctCount, wrongCount, totalQuestions, setNumber } = req.body;
  if (typeof correctCount !== "number" || typeof wrongCount !== "number") {
    res.status(400).json({ error: "Invalid data" });
    return;
  }
  const pointsEarned = correctCount * 1 - wrongCount * 0.5;
  const finalPoints = Math.max(0, pointsEarned);
  const setNum = parseInt(setNumber || "1", 10) || 1;

  // XP: +10 per correct answer, +50 completion bonus
  const xpEarned = correctCount * 10 + 50;
  // Coins: +5 for completing any quiz
  const coinsEarned = 5 + (correctCount >= totalQuestions * 0.8 ? 5 : 0);

  try {
    await pool.query(
      "INSERT INTO quiz_submissions (user_id, quiz_type, category, set_number, correct_count, wrong_count, total_questions, points_earned) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
      [req.session.userId, quizType, category || null, setNum, correctCount, wrongCount, totalQuestions, finalPoints]
    );

    const userResult = await pool.query("SELECT * FROM users WHERE id=$1", [req.session.userId]);
    const user = userResult.rows[0];
    const newXP = (user.xp || 0) + xpEarned;
    const newLevel = getLevel(newXP);
    const oldLevel = user.level || getLevel(user.xp || 0);
    const leveledUp = newLevel !== oldLevel;

    await pool.query(
      "UPDATE users SET total_points=total_points+$1, xp=$2, level=$3, coins=coins+$4 WHERE id=$5",
      [finalPoints, newXP, newLevel, coinsEarned, req.session.userId]
    );

    const updated = await pool.query("SELECT total_points, xp, level, coins FROM users WHERE id=$1", [req.session.userId]);
    res.json({
      pointsEarned: finalPoints,
      totalPoints: parseFloat(updated.rows[0].total_points),
      xpEarned,
      coinsEarned,
      newXP: updated.rows[0].xp,
      newLevel: updated.rows[0].level,
      newCoins: updated.rows[0].coins,
      leveledUp,
      oldLevel,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// ──── CHECK ATTEMPT (once per day per quiz type+category) ─────────────────────
router.get("/quiz/check-attempt", async (req, res) => {
  if (!req.session.userId) {
    res.json({ attempted: false });
    return;
  }
  const { type, category } = req.query;
  if (!type) { res.json({ attempted: false }); return; }
  try {
    let query = "SELECT id FROM quiz_submissions WHERE user_id=$1 AND quiz_type=$2 AND submitted_at::date = CURRENT_DATE";
    const params: (string | number)[] = [req.session.userId, type as string];
    if (category) {
      query += " AND category=$3";
      params.push(category as string);
    } else {
      query += " AND category IS NULL";
    }
    const result = await pool.query(query, params);
    res.json({ attempted: result.rows.length > 0 });
  } catch {
    res.json({ attempted: false });
  }
});

router.get("/quiz/history", async (req, res) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Login required" });
    return;
  }
  try {
    const result = await pool.query(
      "SELECT * FROM quiz_submissions WHERE user_id=$1 ORDER BY submitted_at DESC LIMIT 20",
      [req.session.userId]
    );
    res.json({ history: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
