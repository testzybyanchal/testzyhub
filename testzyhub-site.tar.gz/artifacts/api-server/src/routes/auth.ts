import { Router } from "express";
import bcrypt from "bcryptjs";
import { pool } from "@workspace/db";

const router = Router();

declare module "express-session" {
  interface SessionData {
    userId: number;
    name: string;
    email: string;
    isAdmin: boolean;
  }
}

function getLevel(xp: number): string {
  if (xp >= 1000) return "Master";
  if (xp >= 500) return "Pro";
  if (xp >= 200) return "Intermediate";
  return "Beginner";
}

function formatUser(user: Record<string, unknown>) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    mobile: user.mobile || null,
    isAdmin: user.is_admin,
    totalPoints: parseFloat(String(user.total_points || 0)),
    xp: parseInt(String(user.xp || 0)),
    level: user.level || getLevel(parseInt(String(user.xp || 0))),
    coins: parseInt(String(user.coins || 0)),
    streakCount: parseInt(String(user.streak_count || 0)),
  };
}

router.post("/auth/signup", async (req, res) => {
  const { name, email, password, mobile } = req.body;
  if (!name || !email || !password) {
    res.status(400).json({ error: "सभी fields भरें" });
    return;
  }
  if (password.length < 6) {
    res.status(400).json({ error: "Password कम से कम 6 अक्षर का होना चाहिए" });
    return;
  }
  try {
    const exists = await pool.query("SELECT id FROM users WHERE email=$1", [email.toLowerCase()]);
    if (exists.rows.length > 0) {
      res.status(400).json({ error: "यह email पहले से registered है" });
      return;
    }
    const hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      "INSERT INTO users (name, email, password_hash, mobile, xp, level, coins, streak_count, last_login) VALUES ($1, $2, $3, $4, 0, 'Beginner', 50, 1, CURRENT_DATE) RETURNING *",
      [name.trim(), email.toLowerCase().trim(), hash, mobile?.trim() || null]
    );
    const user = result.rows[0];
    req.session.userId = user.id;
    req.session.name = user.name;
    req.session.email = user.email;
    req.session.isAdmin = user.is_admin;
    res.json({ user: formatUser(user), welcomeBonus: { xp: 0, coins: 50 } });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/auth/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: "Email और Password डालें" });
    return;
  }
  try {
    const result = await pool.query(
      "SELECT * FROM users WHERE email=$1",
      [email.toLowerCase().trim()]
    );
    if (result.rows.length === 0) {
      res.status(401).json({ error: "Email या Password गलत है" });
      return;
    }
    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      res.status(401).json({ error: "Email या Password गलत है" });
      return;
    }

    // Daily login bonus: +20 XP, +5 coins if not logged in today
    let dailyBonus = null;
    const today = new Date().toISOString().slice(0, 10);
    const lastLogin = user.last_login ? new Date(user.last_login).toISOString().slice(0, 10) : null;
    if (lastLogin !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      const newStreak = lastLogin === yesterday ? (user.streak_count || 0) + 1 : 1;
      const bonusXP = 20 + (newStreak > 1 ? Math.min(newStreak * 5, 50) : 0);
      const bonusCoins = 5 + (newStreak > 6 ? 10 : 0);
      const newXP = (user.xp || 0) + bonusXP;
      const newLevel = getLevel(newXP);
      await pool.query(
        "UPDATE users SET last_login=CURRENT_DATE, streak_count=$1, xp=$2, level=$3, coins=coins+$4 WHERE id=$5",
        [newStreak, newXP, newLevel, bonusCoins, user.id]
      );
      user.xp = newXP;
      user.level = newLevel;
      user.streak_count = newStreak;
      user.coins = (user.coins || 0) + bonusCoins;
      dailyBonus = { xp: bonusXP, coins: bonusCoins, streak: newStreak };
    }

    req.session.userId = user.id;
    req.session.name = user.name;
    req.session.email = user.email;
    req.session.isAdmin = user.is_admin;
    res.json({ user: formatUser(user), dailyBonus });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

router.get("/auth/me", async (req, res) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Not logged in" });
    return;
  }
  try {
    const result = await pool.query("SELECT * FROM users WHERE id=$1", [req.session.userId]);
    if (result.rows.length === 0) {
      res.status(401).json({ error: "User not found" });
      return;
    }
    res.json({ user: formatUser(result.rows[0]) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
