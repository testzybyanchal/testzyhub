import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/leaderboard", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, name, total_points FROM users WHERE is_admin=false ORDER BY total_points DESC LIMIT 10"
    );
    const leaderboard = result.rows.map((row, idx) => ({
      rank: idx + 1,
      id: row.id,
      name: row.name,
      totalPoints: parseFloat(row.total_points),
    }));
    res.json({ leaderboard });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
