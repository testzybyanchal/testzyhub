import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/bookmarks", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  try {
    const result = await pool.query(
      "SELECT * FROM bookmarks WHERE user_id=$1 ORDER BY created_at DESC",
      [req.session.userId]
    );
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/bookmarks", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const { question_text, options, correct_answer, explanation, subject, category } = req.body;
  try {
    const existing = await pool.query(
      "SELECT id FROM bookmarks WHERE user_id=$1 AND question_text=$2",
      [req.session.userId, question_text]
    );
    if (existing.rows.length > 0) {
      await pool.query("DELETE FROM bookmarks WHERE id=$1", [existing.rows[0].id]);
      return res.json({ success: true, action: "removed" });
    }
    await pool.query(
      `INSERT INTO bookmarks (user_id, question_text, options, correct_answer, explanation, subject, category)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [req.session.userId, question_text, JSON.stringify(options || []), correct_answer, explanation, subject, category]
    );
    res.json({ success: true, action: "added" });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

router.delete("/bookmarks/:id", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  try {
    await pool.query("DELETE FROM bookmarks WHERE id=$1 AND user_id=$2", [
      req.params.id, req.session.userId,
    ]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
