import { Router } from "express";
import { pool } from "@workspace/db";
import multer from "multer";
import { objectStorageClient } from "../lib/objectStorage";
import { randomUUID } from "crypto";

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

router.get("/community-notes", async (req, res) => {
  const { subject } = req.query;
  try {
    let rows;
    if (subject && subject !== "all") {
      const r = await pool.query(
        "SELECT cn.*, u.name as uploader_name FROM community_notes cn LEFT JOIN users u ON u.id=cn.uploaded_by WHERE cn.subject=$1 ORDER BY cn.created_at DESC LIMIT 50",
        [subject]
      );
      rows = r.rows;
    } else {
      const r = await pool.query(
        "SELECT cn.*, u.name as uploader_name FROM community_notes cn LEFT JOIN users u ON u.id=cn.uploaded_by ORDER BY cn.created_at DESC LIMIT 50"
      );
      rows = r.rows;
    }
    res.json({ notes: rows });
  } catch (e) {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/community-notes", upload.single("file"), async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Login required" });
  if (!req.file) return res.status(400).json({ error: "File required" });

  const { title, subject, description } = req.body;
  if (!title || !subject) return res.status(400).json({ error: "Title and subject required" });

  try {
    const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
    if (!bucketId) return res.status(500).json({ error: "Storage not configured" });

    const ext = req.file.originalname.split(".").pop() || "bin";
    const objectKey = `community-notes/${randomUUID()}.${ext}`;
    const bucket = objectStorageClient.bucket(bucketId);
    const file = bucket.file(objectKey);

    await file.save(req.file.buffer, {
      contentType: req.file.mimetype,
      metadata: { cacheControl: "public, max-age=31536000" },
    });

    await file.makePublic();
    const publicUrl = `https://storage.googleapis.com/${bucketId}/${objectKey}`;

    await pool.query(
      "INSERT INTO community_notes (title, subject, description, file_url, file_type, file_size, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7)",
      [title, subject, description || "", publicUrl, req.file.mimetype, req.file.size, req.session.userId]
    );
    res.json({ success: true, url: publicUrl });
  } catch (e) {
    console.error("Upload error:", e);
    res.status(500).json({ error: "Upload failed" });
  }
});

router.delete("/community-notes/:id", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Login required" });
  try {
    const note = await pool.query("SELECT * FROM community_notes WHERE id=$1", [req.params.id]);
    if (!note.rows[0]) return res.status(404).json({ error: "Not found" });
    const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id=$1", [req.session.userId]);
    const isAdmin = adminCheck.rows[0]?.is_admin;
    if (!isAdmin && note.rows[0].uploaded_by !== req.session.userId) {
      return res.status(403).json({ error: "Not authorized" });
    }
    await pool.query("DELETE FROM community_notes WHERE id=$1", [req.params.id]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
