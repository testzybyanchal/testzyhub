import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

router.get("/prizes", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM prizes ORDER BY rank_position ASC");
    res.json({ prizes: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

router.put("/prizes", async (req, res) => {
  if (!req.session.isAdmin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const { prizes } = req.body;
  if (!Array.isArray(prizes)) {
    res.status(400).json({ error: "Invalid data" });
    return;
  }
  try {
    for (const prize of prizes) {
      await pool.query(
        "UPDATE prizes SET title=$1, description=$2, amount=$3, updated_at=NOW() WHERE rank_position=$4",
        [prize.title, prize.description, prize.amount, prize.rank_position]
      );
    }
    const result = await pool.query("SELECT * FROM prizes ORDER BY rank_position ASC");
    res.json({ prizes: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
