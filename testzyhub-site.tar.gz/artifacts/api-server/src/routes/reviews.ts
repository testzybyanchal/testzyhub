import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

// Get all approved reviews
router.get("/reviews", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT r.id, r.rating, r.comment, r.created_at, u.name as user_name, u.level
       FROM reviews r
       JOIN users u ON r.user_id = u.id
       WHERE r.approved = true
       ORDER BY r.created_at DESC
       LIMIT 50`
    );
    const stats = await pool.query(
      `SELECT COUNT(*) as total, ROUND(AVG(rating)::numeric, 1) as avg_rating FROM reviews WHERE approved=true`
    );
    res.json({ reviews: result.rows, stats: stats.rows[0] });
  } catch {
    res.json({ reviews: [], stats: { total: 0, avg_rating: 0 } });
  }
});

// Submit a review (login required)
router.post("/reviews", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }
  const { rating, comment } = req.body;
  if (!rating || rating < 1 || rating > 5) { res.status(400).json({ error: "1–5 rating दें" }); return; }
  if (!comment?.trim() || comment.trim().length < 10) { res.status(400).json({ error: "कम से कम 10 अक्षर लिखें" }); return; }

  try {
    // Check if user already submitted a review
    const existing = await pool.query("SELECT id FROM reviews WHERE user_id=$1", [req.session.userId]);
    if (existing.rows.length > 0) {
      // Update existing
      await pool.query("UPDATE reviews SET rating=$1, comment=$2, approved=false WHERE user_id=$3", [rating, comment.trim(), req.session.userId]);
      res.json({ success: true, message: "✅ Review update हो गई! Approval में 24 घंटे लगेंगे।" });
      return;
    }
    await pool.query(
      "INSERT INTO reviews (user_id, rating, comment, approved) VALUES ($1,$2,$3,false)",
      [req.session.userId, rating, comment.trim()]
    );
    res.json({ success: true, message: "✅ Review submit हुई! Approval में 24 घंटे लगेंगे।" });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// Admin: get all reviews (including unapproved)
router.get("/admin/reviews", async (req, res) => {
  if (!req.session.isAdmin) { res.status(403).json({ error: "Forbidden" }); return; }
  try {
    const result = await pool.query(
      `SELECT r.id, r.rating, r.comment, r.approved, r.created_at, u.name as user_name, u.email
       FROM reviews r
       JOIN users u ON r.user_id = u.id
       ORDER BY r.created_at DESC`
    );
    res.json({ reviews: result.rows });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// Admin: approve/reject review
router.patch("/admin/reviews/:id", async (req, res) => {
  if (!req.session.isAdmin) { res.status(403).json({ error: "Forbidden" }); return; }
  const { approved } = req.body;
  try {
    await pool.query("UPDATE reviews SET approved=$1 WHERE id=$2", [!!approved, req.params.id]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
