import { Router } from "express";
import { pool } from "@workspace/db";
import type { Server as IOServer } from "socket.io";

const router = Router();

// In-memory battle queue and rooms
const waitingQueue: Array<{ userId: number; name: string; socketId: string }> = [];
const rooms = new Map<string, {
  player1: { userId: number; name: string; socketId: string };
  player2: { userId: number; name: string; socketId: string };
  questions: Question[];
  answers: Record<string, { p1?: string; p2?: string; time?: number }>;
  scores: { p1: number; p2: number };
  currentQ: number;
  timer?: ReturnType<typeof setTimeout>;
}>();

type Question = {
  id: number; question: string;
  option_a: string; option_b: string; option_c: string; option_d: string;
  correct_option: number;
};

function getLevel(xp: number): string {
  if (xp >= 1000) return "Master";
  if (xp >= 500) return "Pro";
  if (xp >= 200) return "Intermediate";
  return "Beginner";
}

async function fetchBattleQuestions(): Promise<Question[]> {
  const result = await pool.query(
    "SELECT id, question, option_a, option_b, option_c, option_d, correct_option FROM db_questions ORDER BY RANDOM() LIMIT 10"
  );
  if (result.rows.length >= 5) return result.rows;
  // Static fallback questions
  return [
    { id: 1, question: "भारत की राजधानी कहाँ है?", option_a: "मुंबई", option_b: "नई दिल्ली", option_c: "कोलकाता", option_d: "चेन्नई", correct_option: 1 },
    { id: 2, question: "भारत में कितने राज्य हैं?", option_a: "25", option_b: "28", option_c: "29", option_d: "30", correct_option: 1 },
    { id: 3, question: "भारत का राष्ट्रीय खेल कौन सा है?", option_a: "क्रिकेट", option_b: "हॉकी", option_c: "फुटबॉल", option_d: "कबड्डी", correct_option: 1 },
    { id: 4, question: "भारत का सबसे बड़ा राज्य कौन सा है?", option_a: "उत्तर प्रदेश", option_b: "मध्य प्रदेश", option_c: "राजस्थान", option_d: "महाराष्ट्र", correct_option: 2 },
    { id: 5, question: "भारत की सबसे लंबी नदी कौन सी है?", option_a: "गंगा", option_b: "यमुना", option_c: "ब्रह्मपुत्र", option_d: "गोदावरी", correct_option: 0 },
    { id: 6, question: "1 + 1 = ?", option_a: "1", option_b: "2", option_c: "3", option_d: "4", correct_option: 1 },
    { id: 7, question: "भारत के प्रथम राष्ट्रपति कौन थे?", option_a: "डॉ. राजेंद्र प्रसाद", option_b: "सर्वपल्ली राधाकृष्णन", option_c: "जवाहरलाल नेहरू", option_d: "लाल बहादुर शास्त्री", correct_option: 0 },
    { id: 8, question: "भारत का राष्ट्रीय पक्षी कौन सा है?", option_a: "कबूतर", option_b: "मोर", option_c: "तोता", option_d: "हंस", correct_option: 1 },
    { id: 9, question: "सूर्य से पृथ्वी की दूरी कितनी है?", option_a: "10 करोड़ km", option_b: "15 करोड़ km", option_c: "20 करोड़ km", option_d: "5 करोड़ km", correct_option: 1 },
    { id: 10, question: "भारत का सबसे बड़ा बंदरगाह कौन सा है?", option_a: "मुंबई", option_b: "कोलकाता", option_c: "चेन्नई", option_d: "विशाखापटनम", correct_option: 0 },
  ];
}

export function setupBattleSocket(io: IOServer) {
  io.on("connection", (socket) => {
    const userId = socket.handshake.auth.userId as number;
    const userName = socket.handshake.auth.name as string;

    if (!userId) return;

    // Join battle queue
    socket.on("join-queue", async () => {
      // Remove if already in queue
      const existingIdx = waitingQueue.findIndex((u) => u.userId === userId);
      if (existingIdx !== -1) waitingQueue.splice(existingIdx, 1);

      waitingQueue.push({ userId, name: userName, socketId: socket.id });
      socket.emit("queue-joined", { position: waitingQueue.length });

      if (waitingQueue.length >= 2) {
        const p1 = waitingQueue.shift()!;
        const p2 = waitingQueue.shift()!;
        const roomId = `battle-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

        const questions = await fetchBattleQuestions();

        rooms.set(roomId, {
          player1: p1, player2: p2,
          questions,
          answers: {},
          scores: { p1: 0, p2: 0 },
          currentQ: 0,
        });

        const p1Socket = io.sockets.sockets.get(p1.socketId);
        const p2Socket = io.sockets.sockets.get(p2.socketId);

        if (p1Socket) { p1Socket.join(roomId); p1Socket.data.roomId = roomId; p1Socket.data.role = "p1"; }
        if (p2Socket) { p2Socket.join(roomId); p2Socket.data.roomId = roomId; p2Socket.data.role = "p2"; }

        io.to(roomId).emit("battle-start", {
          roomId,
          opponent: { p1: p2.name, p2: p1.name },
          totalQuestions: questions.length,
        });

        sendQuestion(io, roomId, 0);
      }
    });

    socket.on("leave-queue", () => {
      const idx = waitingQueue.findIndex((u) => u.userId === userId);
      if (idx !== -1) waitingQueue.splice(idx, 1);
      socket.emit("queue-left");
    });

    socket.on("submit-answer", (data: { roomId: string; answer: number; timeLeft: number }) => {
      const room = rooms.get(data.roomId);
      if (!room) return;
      const role = socket.data.role as "p1" | "p2";
      const qIdx = room.currentQ;
      const key = `q${qIdx}`;
      if (!room.answers[key]) room.answers[key] = {};
      if (room.answers[key][role]) return; // Already answered

      room.answers[key][role] = String(data.answer);

      // Notify opponent that this player answered
      socket.to(data.roomId).emit("opponent-answered", { role });

      // Check if both answered
      const both = room.answers[key].p1 !== undefined && room.answers[key].p2 !== undefined;
      if (both) {
        if (room.timer) clearTimeout(room.timer);
        resolveQuestion(io, data.roomId, room, qIdx);
      }
    });

    socket.on("disconnect", () => {
      const idx = waitingQueue.findIndex((u) => u.socketId === socket.id);
      if (idx !== -1) waitingQueue.splice(idx, 1);

      const roomId = socket.data.roomId;
      if (roomId) {
        socket.to(roomId).emit("opponent-disconnected");
        const room = rooms.get(roomId);
        if (room && room.timer) clearTimeout(room.timer);
        rooms.delete(roomId);
      }
    });
  });
}

function sendQuestion(io: IOServer, roomId: string, qIdx: number) {
  const room = rooms.get(roomId);
  if (!room || qIdx >= room.questions.length) {
    endBattle(io, roomId);
    return;
  }
  room.currentQ = qIdx;
  const q = room.questions[qIdx];
  io.to(roomId).emit("question", {
    index: qIdx,
    total: room.questions.length,
    question: q.question,
    options: [q.option_a, q.option_b, q.option_c, q.option_d],
    timeLimit: 30,
  });

  // Auto-advance after 30 seconds
  room.timer = setTimeout(() => {
    resolveQuestion(io, roomId, room, qIdx);
  }, 31000);
}

function resolveQuestion(io: IOServer, roomId: string, room: typeof rooms extends Map<string, infer V> ? V : never, qIdx: number) {
  const q = room.questions[qIdx];
  const key = `q${qIdx}`;
  const p1Ans = room.answers[key]?.p1;
  const p2Ans = room.answers[key]?.p2;

  if (p1Ans !== undefined && parseInt(p1Ans) === q.correct_option) room.scores.p1++;
  if (p2Ans !== undefined && parseInt(p2Ans) === q.correct_option) room.scores.p2++;

  io.to(roomId).emit("question-result", {
    index: qIdx,
    correct: q.correct_option,
    p1Answer: p1Ans !== undefined ? parseInt(p1Ans) : null,
    p2Answer: p2Ans !== undefined ? parseInt(p2Ans) : null,
    scores: room.scores,
  });

  const nextQ = qIdx + 1;
  if (nextQ >= room.questions.length) {
    setTimeout(() => endBattle(io, roomId), 2000);
  } else {
    setTimeout(() => sendQuestion(io, roomId, nextQ), 2000);
  }
}

async function endBattle(io: IOServer, roomId: string) {
  const room = rooms.get(roomId);
  if (!room) return;

  const { scores, player1, player2 } = room;
  let winnerId: number | null = null;
  let winnerRole: "p1" | "p2" | "draw" = "draw";
  if (scores.p1 > scores.p2) { winnerId = player1.userId; winnerRole = "p1"; }
  else if (scores.p2 > scores.p1) { winnerId = player2.userId; winnerRole = "p2"; }

  // Award XP and coins
  const winnerXP = 100, loserXP = 30, drawXP = 50;
  const winnerCoins = 20, loserCoins = 5, drawCoins = 10;

  async function awardUser(uid: number, isWinner: boolean, isDraw: boolean) {
    const xp = isDraw ? drawXP : isWinner ? winnerXP : loserXP;
    const coins = isDraw ? drawCoins : isWinner ? winnerCoins : loserCoins;
    const user = await pool.query("SELECT xp FROM users WHERE id=$1", [uid]);
    const newXP = (user.rows[0]?.xp || 0) + xp;
    const level = getLevel(newXP);
    await pool.query("UPDATE users SET xp=$1, level=$2, coins=coins+$3 WHERE id=$4", [newXP, level, coins, uid]);
    return { xp, coins };
  }

  try {
    const p1Reward = await awardUser(player1.userId, winnerRole === "p1", winnerRole === "draw");
    const p2Reward = await awardUser(player2.userId, winnerRole === "p2", winnerRole === "draw");

    await pool.query(
      "INSERT INTO battles (room_id, player1_id, player2_id, questions, scores, winner_id, status) VALUES ($1,$2,$3,$4,$5,$6,'finished')",
      [roomId, player1.userId, player2.userId, JSON.stringify(room.questions), JSON.stringify(scores), winnerId]
    );

    io.to(roomId).emit("battle-end", {
      scores,
      winner: winnerRole,
      winnerName: winnerRole === "p1" ? player1.name : winnerRole === "p2" ? player2.name : null,
      rewards: { p1: p1Reward, p2: p2Reward },
    });
  } catch (e) {
    io.to(roomId).emit("battle-end", { scores, winner: winnerRole, winnerName: null, rewards: {} });
  }

  rooms.delete(roomId);
}

// REST: get battle history
router.get("/battle/history", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login required" }); return; }
  try {
    const result = await pool.query(
      `SELECT b.*, u1.name as p1_name, u2.name as p2_name, w.name as winner_name
       FROM battles b
       LEFT JOIN users u1 ON b.player1_id=u1.id
       LEFT JOIN users u2 ON b.player2_id=u2.id
       LEFT JOIN users w ON b.winner_id=w.id
       WHERE b.player1_id=$1 OR b.player2_id=$1
       ORDER BY b.created_at DESC LIMIT 10`,
      [req.session.userId]
    );
    res.json({ battles: result.rows });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/battle/stats", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login required" }); return; }
  try {
    const result = await pool.query(
      `SELECT
        COUNT(*) as total,
        SUM(CASE WHEN winner_id=$1 THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN winner_id IS NULL THEN 1 ELSE 0 END) as draws
       FROM battles WHERE player1_id=$1 OR player2_id=$1`,
      [req.session.userId]
    );
    const { total, wins, draws } = result.rows[0];
    res.json({ total: parseInt(total), wins: parseInt(wins), draws: parseInt(draws), losses: parseInt(total) - parseInt(wins) - parseInt(draws) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
