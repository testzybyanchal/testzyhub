import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

// ─── GET ALL DOUBTS ──────────────────────────────────────────────────────────
router.get("/doubts", async (req, res) => {
  const { category, search, page = "1" } = req.query as Record<string, string>;
  const limit = 20;
  const offset = (parseInt(page) - 1) * limit;

  try {
    let where = "WHERE 1=1";
    const params: any[] = [];

    if (category && category !== "all") {
      params.push(category);
      where += ` AND dp.category = $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      where += ` AND (dp.title ILIKE $${params.length} OR dp.question_text ILIKE $${params.length})`;
    }

    params.push(limit, offset);

    const result = await pool.query(
      `SELECT dp.*, u.name as user_name, u.is_admin as user_is_admin,
              (SELECT COUNT(*) FROM doubt_replies dr WHERE dr.post_id = dp.id) as reply_count
       FROM doubt_posts dp
       LEFT JOIN users u ON dp.user_id = u.id
       ${where}
       ORDER BY dp.created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    const countRes = await pool.query(
      `SELECT COUNT(*) FROM doubt_posts dp ${where}`,
      params.slice(0, params.length - 2)
    );

    res.json({ doubts: result.rows, total: parseInt(countRes.rows[0].count) });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── GET SINGLE DOUBT WITH REPLIES ───────────────────────────────────────────
router.get("/doubts/:id", async (req, res) => {
  try {
    const postRes = await pool.query(
      `SELECT dp.*, u.name as user_name, u.is_admin as user_is_admin
       FROM doubt_posts dp
       LEFT JOIN users u ON dp.user_id = u.id
       WHERE dp.id = $1`,
      [req.params.id]
    );
    if (postRes.rows.length === 0) { res.status(404).json({ error: "Not found" }); return; }

    const repliesRes = await pool.query(
      `SELECT dr.*, u.name as user_name, u.is_admin as user_is_admin
       FROM doubt_replies dr
       LEFT JOIN users u ON dr.user_id = u.id
       WHERE dr.post_id = $1
       ORDER BY dr.created_at ASC`,
      [req.params.id]
    );

    res.json({ post: postRes.rows[0], replies: repliesRes.rows });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── POST NEW DOUBT ───────────────────────────────────────────────────────────
router.post("/doubts", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }

  const { title, question_text, category, image_base64 } = req.body;
  if (!title?.trim() || !question_text?.trim()) {
    res.status(400).json({ error: "Title और Question दोनों भरें" });
    return;
  }

  // Limit image size to 1.5MB base64
  if (image_base64 && image_base64.length > 2_000_000) {
    res.status(400).json({ error: "Image बहुत बड़ी है (max 1.5MB)" });
    return;
  }

  try {
    const result = await pool.query(
      `INSERT INTO doubt_posts (user_id, title, question_text, category, image_base64)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [req.session.userId, title.trim(), question_text.trim(), category || "general", image_base64 || null]
    );
    res.json({ success: true, post: result.rows[0] });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── REPLY TO DOUBT ────────────────────────────────────────────────────────────
router.post("/doubts/:id/reply", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }

  const { reply_text, image_base64 } = req.body;
  if (!reply_text?.trim()) { res.status(400).json({ error: "Reply text भरें" }); return; }

  if (image_base64 && image_base64.length > 2_000_000) {
    res.status(400).json({ error: "Image बहुत बड़ी है" });
    return;
  }

  try {
    const userRes = await pool.query("SELECT name, is_admin FROM users WHERE id=$1", [req.session.userId]);
    const user = userRes.rows[0];

    const result = await pool.query(
      `INSERT INTO doubt_replies (post_id, user_id, reply_text, image_base64, is_admin_reply)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [req.params.id, req.session.userId, reply_text.trim(), image_base64 || null, user?.is_admin || false]
    );

    res.json({ success: true, reply: { ...result.rows[0], user_name: user?.name, user_is_admin: user?.is_admin } });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── MARK AS RESOLVED ─────────────────────────────────────────────────────────
router.patch("/doubts/:id/resolve", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }
  try {
    const post = await pool.query("SELECT user_id FROM doubt_posts WHERE id=$1", [req.params.id]);
    if (post.rows.length === 0) { res.status(404).json({ error: "Not found" }); return; }

    if (post.rows[0].user_id !== req.session.userId && !req.session.isAdmin) {
      res.status(403).json({ error: "Permission नहीं" });
      return;
    }

    await pool.query("UPDATE doubt_posts SET is_resolved=$1 WHERE id=$2", [req.body.resolved ?? true, req.params.id]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── DELETE POST (admin or owner) ─────────────────────────────────────────────
router.delete("/doubts/:id", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }
  try {
    const post = await pool.query("SELECT user_id FROM doubt_posts WHERE id=$1", [req.params.id]);
    if (post.rows.length === 0) { res.status(404).json({ error: "Not found" }); return; }

    if (post.rows[0].user_id !== req.session.userId && !req.session.isAdmin) {
      res.status(403).json({ error: "Permission नहीं" });
      return;
    }

    await pool.query("DELETE FROM doubt_posts WHERE id=$1", [req.params.id]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── DELETE REPLY (admin or owner) ────────────────────────────────────────────
router.delete("/doubts/:id/replies/:replyId", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }
  try {
    const reply = await pool.query("SELECT user_id FROM doubt_replies WHERE id=$1", [req.params.replyId]);
    if (reply.rows.length === 0) { res.status(404).json({ error: "Not found" }); return; }

    if (reply.rows[0].user_id !== req.session.userId && !req.session.isAdmin) {
      res.status(403).json({ error: "Permission नहीं" });
      return;
    }

    await pool.query("DELETE FROM doubt_replies WHERE id=$1", [req.params.replyId]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
