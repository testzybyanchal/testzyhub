import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

function generateCode(name: string, id: number): string {
  const prefix = name.toUpperCase().replace(/[^A-Z]/g, "").slice(0, 4) || "USER";
  return `${prefix}${id}`;
}

// Get my referral info
router.get("/referral/my-code", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }
  try {
    const userRes = await pool.query("SELECT id, name, referral_code FROM users WHERE id=$1", [req.session.userId]);
    const user = userRes.rows[0];
    if (!user) { res.status(404).json({ error: "User not found" }); return; }

    // Generate code if not exists
    if (!user.referral_code) {
      const code = generateCode(user.name, user.id);
      await pool.query("UPDATE users SET referral_code=$1 WHERE id=$2", [code, user.id]);
      user.referral_code = code;
    }

    // Count how many users referred
    const countRes = await pool.query("SELECT COUNT(*) FROM users WHERE referred_by=$1", [user.referral_code]);
    const referredCount = parseInt(countRes.rows[0].count || "0");

    // Bonus XP earned from referrals
    const bonusXp = referredCount * 50;

    res.json({ code: user.referral_code, referredCount, bonusXp });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// Apply referral code (called after signup if user provides a code)
router.post("/referral/apply", async (req, res) => {
  if (!req.session.userId) { res.status(401).json({ error: "Login करें" }); return; }
  const { code } = req.body;
  if (!code?.trim()) { res.status(400).json({ error: "Code डालें" }); return; }

  try {
    // Check if already has a referral
    const selfRes = await pool.query("SELECT referred_by FROM users WHERE id=$1", [req.session.userId]);
    if (selfRes.rows[0]?.referred_by) {
      res.status(400).json({ error: "आपने पहले से referral code use किया है" });
      return;
    }

    // Find referrer (can't refer yourself)
    const referrerRes = await pool.query(
      "SELECT id, name, xp, coins FROM users WHERE referral_code=$1 AND id != $2",
      [code.trim().toUpperCase(), req.session.userId]
    );
    if (referrerRes.rows.length === 0) {
      res.status(404).json({ error: "यह referral code valid नहीं है" });
      return;
    }
    const referrer = referrerRes.rows[0];

    // Update the new user
    await pool.query("UPDATE users SET referred_by=$1, xp=xp+50, coins=coins+20 WHERE id=$2", [code.trim().toUpperCase(), req.session.userId]);

    // Reward the referrer too
    await pool.query("UPDATE users SET xp=xp+50, coins=coins+20 WHERE id=$1", [referrer.id]);

    res.json({ success: true, message: `✅ Referral applied! आपको +50 XP और +20 Coins मिले। ${referrer.name} को भी reward मिला!` });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
