import { Router } from "express";
import { pool } from "@workspace/db";
import { parseStringPromise } from "xml2js";

const router = Router();

router.get("/current-affairs", async (req, res) => {
  const { category, page = "1" } = req.query;
  const limit = 10;
  const offset = (Number(page) - 1) * limit;
  try {
    let rows, total;
    if (category && category !== "all") {
      const r = await pool.query(
        "SELECT * FROM current_affairs WHERE category=$1 ORDER BY date DESC, id DESC LIMIT $2 OFFSET $3",
        [category, limit, offset]
      );
      const c = await pool.query("SELECT COUNT(*) FROM current_affairs WHERE category=$1", [category]);
      rows = r.rows; total = parseInt(c.rows[0].count);
    } else {
      const r = await pool.query(
        "SELECT * FROM current_affairs ORDER BY date DESC, id DESC LIMIT $1 OFFSET $2",
        [limit, offset]
      );
      const c = await pool.query("SELECT COUNT(*) FROM current_affairs");
      rows = r.rows; total = parseInt(c.rows[0].count);
    }
    res.json({ items: rows, total, page: Number(page) });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/current-affairs/auto-fetch", async (req, res) => {
  try {
    const RSS_FEEDS = [
      "https://news.google.com/rss/search?q=SSC+Railway+Police+Banking+exam+india+current+affairs&hl=hi&gl=IN&ceid=IN:hi",
      "https://news.google.com/rss/search?q=सरकारी+परीक्षा+2025+करंट+अफेयर्स&hl=hi&gl=IN&ceid=IN:hi",
    ];

    const CATEGORY_KEYWORDS: Record<string, string[]> = {
      exam: ["ssc", "railway", "rrb", "police", "ibps", "sbi", "upsc", "परीक्षा", "exam", "recruitment", "bharti"],
      economy: ["economy", "gdp", "budget", "rbi", "अर्थव्यवस्था", "बजट", "आर्थिक"],
      government: ["government", "ministry", "scheme", "yojana", "सरकार", "मंत्रालय", "योजना", "cabinet"],
      science: ["science", "isro", "nasa", "space", "technology", "विज्ञान", "अंतरिक्ष"],
      sports: ["cricket", "olympic", "medal", "sports", "खेल", "cricket", "विश्वकप"],
      awards: ["award", "padma", "bharat", "ratna", "prize", "पुरस्कार", "सम्मान"],
      national: ["india", "government", "parliament", "भारत", "संसद", "राष्ट्रीय"],
      international: ["world", "united nations", "un ", "अंतर्राष्ट्रीय", "विश्व"],
    };

    function detectCategory(text: string): string {
      const lower = text.toLowerCase();
      for (const [cat, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
        if (keywords.some((k) => lower.includes(k))) return cat;
      }
      return "general";
    }

    let inserted = 0;
    for (const feedUrl of RSS_FEEDS) {
      try {
        const response = await fetch(feedUrl, {
          headers: { "User-Agent": "TestzyHub/1.0" },
          signal: AbortSignal.timeout(8000),
        });
        if (!response.ok) continue;
        const xml = await response.text();
        const parsed = await parseStringPromise(xml, { explicitArray: false });
        const items = parsed?.rss?.channel?.item;
        if (!items) continue;
        const itemArr = Array.isArray(items) ? items : [items];

        for (const item of itemArr.slice(0, 15)) {
          const title = (item.title || "").replace(/<[^>]+>/g, "").trim();
          const content = (item.description || item["content:encoded"] || item.title || "").replace(/<[^>]+>/g, "").trim();
          const link = item.link || "";
          const pubDate = item.pubDate ? new Date(item.pubDate).toISOString().split("T")[0] : new Date().toISOString().split("T")[0];
          if (!title || title.length < 10) continue;
          const category = detectCategory(title + " " + content);
          try {
            await pool.query(
              "INSERT INTO current_affairs (title, content, category, date, source_url) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING",
              [title, content || title, category, pubDate, link]
            );
            inserted++;
          } catch { }
        }
      } catch (e) {
        console.error("RSS fetch error:", feedUrl, e);
      }
    }
    res.json({ success: true, inserted });
  } catch (e) {
    res.status(500).json({ error: "Auto-fetch failed" });
  }
});

router.post("/current-affairs", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id=$1", [req.session.userId]);
  if (!adminCheck.rows[0]?.is_admin) return res.status(403).json({ error: "Not admin" });
  const { title, content, category, date } = req.body;
  try {
    await pool.query(
      "INSERT INTO current_affairs (title, content, category, date, created_by) VALUES ($1,$2,$3,$4,$5)",
      [title, content, category || "general", date || new Date().toISOString().split("T")[0], req.session.userId]
    );
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

router.delete("/current-affairs/:id", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not logged in" });
  const adminCheck = await pool.query("SELECT is_admin FROM users WHERE id=$1", [req.session.userId]);
  if (!adminCheck.rows[0]?.is_admin) return res.status(403).json({ error: "Not admin" });
  try {
    await pool.query("DELETE FROM current_affairs WHERE id=$1", [req.params.id]);
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
