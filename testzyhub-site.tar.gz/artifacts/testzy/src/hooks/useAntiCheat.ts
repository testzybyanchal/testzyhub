import { useEffect, useRef, useState } from "react";

export function useAntiCheat({
  isActive,
  onViolation,
}: {
  isActive: boolean;
  onViolation: () => void;
}) {
  const firedRef = useRef(false);
  const [warning, setWarning] = useState(false);
  const countdownRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!isActive) return;

    function handleVisibilityChange() {
      if (document.hidden && !firedRef.current) {
        firedRef.current = true;
        setWarning(true);
        countdownRef.current = setTimeout(() => {
          setWarning(false);
          onViolation();
        }, 3000);
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      if (countdownRef.current) clearTimeout(countdownRef.current);
    };
  }, [isActive, onViolation]);

  return { warning };
}

export async function checkAlreadyAttempted(type: string, category?: string): Promise<boolean> {
  try {
    const url = `/api/quiz/check-attempt?type=${encodeURIComponent(type)}${category ? `&category=${encodeURIComponent(category)}` : ""}`;
    const res = await fetch(url, { credentials: "include" });
    const data = await res.json();
    return data.attempted === true;
  } catch {
    return false;
  }
}
