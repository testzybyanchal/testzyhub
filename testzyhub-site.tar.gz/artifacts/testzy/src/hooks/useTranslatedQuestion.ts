import { useState, useEffect, useRef } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import type { Question } from "@/data/questions";

type TranslatedQuestion = Question & {
  translatedQuestion?: string;
  translatedOptions?: string[];
  translatedExplanation?: string;
  isTranslating?: boolean;
};

export function useTranslatedQuestion(question: Question | null): TranslatedQuestion | null {
  const { lang, translateText } = useLanguage();
  const [translated, setTranslated] = useState<TranslatedQuestion | null>(null);
  const prevRef = useRef<{ id: string | number; lang: string } | null>(null);

  useEffect(() => {
    if (!question) { setTranslated(null); return; }
    const id = `${question.question.slice(0, 20)}_${lang}`;

    if (lang === "hi") {
      setTranslated({ ...question });
      return;
    }

    if (prevRef.current?.id === id) return;
    prevRef.current = { id, lang };

    setTranslated({ ...question, isTranslating: true });

    Promise.all([
      translateText(question.question),
      ...question.options.map((o) => translateText(o)),
      question.explanation ? translateText(question.explanation) : Promise.resolve(""),
    ]).then(([tq, ...rest]) => {
      const tOptions = rest.slice(0, question.options.length);
      const tExpl = rest[question.options.length];
      setTranslated({
        ...question,
        translatedQuestion: tq,
        translatedOptions: tOptions,
        translatedExplanation: tExpl || undefined,
        isTranslating: false,
      });
    }).catch(() => {
      setTranslated({ ...question, isTranslating: false });
    });
  }, [question?.question, lang]);

  return translated;
}

export function useTranslatedQuestions(questions: Question[]): {
  questions: TranslatedQuestion[];
  translatingIdx: number | null;
} {
  const { lang, translateText } = useLanguage();
  const [translatedList, setTranslatedList] = useState<TranslatedQuestion[]>(questions);
  const [translatingIdx, setTranslatingIdx] = useState<number | null>(null);
  const langRef = useRef(lang);
  const questionsRef = useRef(questions);

  useEffect(() => {
    setTranslatedList(questions);
    if (lang === "hi") { setTranslatingIdx(null); return; }
    if (questions.length === 0) return;

    langRef.current = lang;
    questionsRef.current = questions;

    async function translateAll() {
      const results: TranslatedQuestion[] = [...questions];
      for (let i = 0; i < questions.length; i++) {
        if (langRef.current !== lang || questionsRef.current !== questions) break;
        setTranslatingIdx(i);
        const q = questions[i];
        try {
          const [tq, ...rest] = await Promise.all([
            translateText(q.question),
            ...q.options.map((o) => translateText(o)),
            q.explanation ? translateText(q.explanation) : Promise.resolve(""),
          ]);
          const tOptions = rest.slice(0, q.options.length);
          const tExpl = rest[q.options.length];
          results[i] = {
            ...q,
            translatedQuestion: tq,
            translatedOptions: tOptions,
            translatedExplanation: tExpl || undefined,
          };
          setTranslatedList([...results]);
        } catch {
          results[i] = { ...q };
        }
      }
      setTranslatingIdx(null);
    }

    translateAll();
  }, [lang, questions]);

  return { questions: translatedList, translatingIdx };
}
