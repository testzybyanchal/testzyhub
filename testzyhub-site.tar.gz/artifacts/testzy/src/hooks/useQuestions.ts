import { useState, useEffect } from "react";
import type { Question } from "@/data/questions";

type DBQuestion = {
  id: number;
  category: string;
  quiz_type: string;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
};

export async function fetchDBQuestions(category: string, type: string, setNumber?: number, subject?: string): Promise<Question[]> {
  try {
    const params = new URLSearchParams();
    if (category) params.set("category", category);
    if (type) params.set("type", type);
    if (setNumber !== undefined) params.set("set", String(setNumber));
    if (subject) params.set("subject", subject);
    const res = await fetch(`/api/questions?${params}`);
    if (!res.ok) return [];
    const data = await res.json();
    return (data.questions as DBQuestion[]).map((q) => ({
      id: q.id + 10000,
      category: q.category,
      question: q.question,
      options: q.options,
      correct: q.correct,
      explanation: q.explanation,
    }));
  } catch {
    return [];
  }
}

export async function fetchSubjects(category: string): Promise<Array<{ subject: string; count: string }>> {
  try {
    const params = new URLSearchParams();
    if (category) params.set("category", category);
    const res = await fetch(`/api/subjects?${params}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.subjects ?? [];
  } catch {
    return [];
  }
}

export function useQuestions(category: string, type: string, staticFallback: Question[]) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState<"db" | "static">("static");

  useEffect(() => {
    setLoading(true);
    fetchDBQuestions(category, type).then((dbQs) => {
      if (dbQs.length > 0) {
        setQuestions(dbQs);
        setSource("db");
      } else {
        setQuestions(staticFallback);
        setSource("static");
      }
      setLoading(false);
    });
  }, [category, type]);

  return { questions, loading, source };
}
