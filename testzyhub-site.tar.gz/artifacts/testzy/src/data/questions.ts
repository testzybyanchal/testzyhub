export type Category = {
  id: string;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
  description: string;
};

export type Question = {
  id: number;
  category: string;
  question: string;
  options: string[];
  correct: number;
  explanation?: string;
};

export const categories: Category[] = [
  {
    id: "ssc",
    name: "SSC Exams",
    icon: "📋",
    color: "#2563eb",
    bgColor: "#eff6ff",
    description: "CGL, CHSL, MTS, GD Constable",
  },
  {
    id: "railway",
    name: "Railway Exams",
    icon: "🚂",
    color: "#059669",
    bgColor: "#ecfdf5",
    description: "RRB NTPC, Group D, ALP",
  },
  {
    id: "police",
    name: "Police Exams",
    icon: "👮",
    color: "#7c3aed",
    bgColor: "#f5f3ff",
    description: "UP Police, Delhi Police, Constable",
  },
  {
    id: "banking",
    name: "Banking Exams",
    icon: "🏦",
    color: "#b45309",
    bgColor: "#fffbeb",
    description: "SBI PO/Clerk, IBPS PO/Clerk",
  },
];

export const questions: Question[] = [
  // SSC - Math
  {
    id: 1,
    category: "ssc",
    question: "यदि किसी संख्या का 15% = 45 हो, तो वह संख्या क्या है?",
    options: ["250", "300", "350", "400"],
    correct: 1,
    explanation: "15% = 45 → 1% = 3 → 100% = 300",
  },
  {
    id: 2,
    category: "ssc",
    question:
      "दो संख्याओं का अनुपात 3:5 है और उनका योग 160 है। बड़ी संख्या क्या है?",
    options: ["60", "80", "100", "120"],
    correct: 2,
    explanation: "3x + 5x = 160 → 8x = 160 → x = 20 → बड़ी संख्या = 5×20 = 100",
  },
  {
    id: 3,
    category: "ssc",
    question: "एक वृत्त की त्रिज्या 7 सेमी है। इसका क्षेत्रफल क्या होगा? (π = 22/7)",
    options: ["144 वर्ग सेमी", "154 वर्ग सेमी", "164 वर्ग सेमी", "174 वर्ग सेमी"],
    correct: 1,
    explanation: "क्षेत्रफल = π × r² = 22/7 × 7 × 7 = 154 वर्ग सेमी",
  },
  {
    id: 4,
    category: "ssc",
    question: "यदि A, B से 20% अधिक कमाता है, तो B, A से कितने प्रतिशत कम कमाता है?",
    options: ["16.67%", "20%", "25%", "18%"],
    correct: 0,
    explanation: "B = A से 16.67% कम (20/120 × 100)",
  },
  {
    id: 5,
    category: "ssc",
    question: "एक ट्रेन 360 किमी की दूरी 4 घंटे में तय करती है। उसकी गति क्या है?",
    options: ["80 km/h", "90 km/h", "95 km/h", "100 km/h"],
    correct: 1,
    explanation: "गति = दूरी / समय = 360 / 4 = 90 km/h",
  },
  // SSC - Reasoning
  {
    id: 6,
    category: "ssc",
    question: "श्रृंखला पूर्ण करें: 2, 6, 12, 20, 30, ?",
    options: ["40", "42", "44", "46"],
    correct: 1,
    explanation: "अंतर: 4, 6, 8, 10, 12 → अगला = 30 + 12 = 42",
  },
  {
    id: 7,
    category: "ssc",
    question: "यदि CAT = 3120, तो DOG = ?",
    options: ["4157", "4158", "4159", "4160"],
    correct: 0,
    explanation: "D=4, O=15, G=7 → 4×1000 + 15×10 + 7 = 4157",
  },
  {
    id: 8,
    category: "ssc",
    question: "विषम शब्द चुनें: गाय, भैंस, बकरी, मुर्गी, घोड़ा",
    options: ["गाय", "भैंस", "मुर्गी", "घोड़ा"],
    correct: 2,
    explanation: "मुर्गी पक्षी है, बाकी सब स्तनधारी चतुष्पाद हैं।",
  },
  {
    id: 9,
    category: "ssc",
    question: "रमेश उत्तर की ओर 5 किमी चलता है, फिर दाएं मुड़कर 3 किमी चलता है। वह किस दिशा में है?",
    options: ["उत्तर-पूर्व", "पूर्व", "उत्तर-पश्चिम", "दक्षिण-पूर्व"],
    correct: 0,
    explanation: "5 किमी उत्तर + 3 किमी पूर्व = उत्तर-पूर्व दिशा में",
  },
  {
    id: 10,
    category: "ssc",
    question: "यदि PENCIL को RGPEKN लिखा जाए तो ERASER को कैसे लिखेंगे?",
    options: ["GTHUGR", "GTUUGR", "GTAUGR", "GTCUGR"],
    correct: 0,
    explanation: "प्रत्येक अक्षर 2 आगे खिसकाया जाता है।",
  },

  // Railway - GK
  {
    id: 11,
    category: "railway",
    question: "भारतीय रेलवे की स्थापना कब हुई थी?",
    options: ["1848", "1851", "1853", "1855"],
    correct: 2,
    explanation: "16 अप्रैल 1853 को पहली ट्रेन मुंबई से ठाणे के बीच चली।",
  },
  {
    id: 12,
    category: "railway",
    question: "भारत की सबसे तेज ट्रेन कौन सी है?",
    options: ["राजधानी एक्सप्रेस", "शताब्दी एक्सप्रेस", "वंदे भारत एक्सप्रेस", "गतिमान एक्सप्रेस"],
    correct: 2,
    explanation: "वंदे भारत एक्सप्रेस भारत की सबसे तेज ट्रेन है जो 180 km/h तक की गति प्राप्त कर सकती है।",
  },
  {
    id: 13,
    category: "railway",
    question: "रेलवे बोर्ड का मुख्यालय कहाँ है?",
    options: ["मुंबई", "कोलकाता", "नई दिल्ली", "चेन्नई"],
    correct: 2,
    explanation: "रेलवे बोर्ड का मुख्यालय नई दिल्ली में है।",
  },
  {
    id: 14,
    category: "railway",
    question: "भारत में सबसे लंबी रेलवे लाइन कौन सी है?",
    options: ["दिल्ली-मुंबई", "विवेक एक्सप्रेस रूट", "दिल्ली-चेन्नई", "हावड़ा-मुंबई"],
    correct: 1,
    explanation: "विवेक एक्सप्रेस (डिब्रूगढ़ से कन्याकुमारी) सबसे लंबे मार्ग पर चलती है।",
  },
  {
    id: 15,
    category: "railway",
    question: "भारत में रेलवे जोन की संख्या कितनी है?",
    options: ["16", "17", "18", "19"],
    correct: 2,
    explanation: "भारत में कुल 18 रेलवे जोन हैं।",
  },
  {
    id: 16,
    category: "railway",
    question: "कोंकण रेलवे किन राज्यों से होकर गुजरती है?",
    options: ["महाराष्ट्र-गोवा-केरल", "महाराष्ट्र-गोवा-कर्नाटक-केरल", "गोवा-कर्नाटक", "महाराष्ट्र-कर्नाटक"],
    correct: 1,
    explanation: "कोंकण रेलवे महाराष्ट्र, गोवा, कर्नाटक और केरल से होकर गुजरती है।",
  },
  {
    id: 17,
    category: "railway",
    question: "पहली मेट्रो रेल सेवा भारत में कहाँ शुरू हुई?",
    options: ["दिल्ली", "मुंबई", "कोलकाता", "चेन्नई"],
    correct: 2,
    explanation: "कोलकाता में 1984 में भारत की पहली मेट्रो सेवा शुरू हुई।",
  },
  {
    id: 18,
    category: "railway",
    question: "भारत का सबसे ऊँचा रेलवे स्टेशन कौन सा है?",
    options: ["शिमला", "दार्जिलिंग", "घूम", "कालका"],
    correct: 2,
    explanation: "घूम स्टेशन (दार्जिलिंग) 2258 मीटर की ऊँचाई पर स्थित है।",
  },
  {
    id: 19,
    category: "railway",
    question: "RRB का पूर्ण रूप क्या है?",
    options: [
      "Railway Recruitment Board",
      "Regional Railway Bureau",
      "Rail Revenue Board",
      "Railway Regulation Bureau",
    ],
    correct: 0,
    explanation: "RRB = Railway Recruitment Board (रेलवे भर्ती बोर्ड)",
  },
  {
    id: 20,
    category: "railway",
    question: "भारत में सबसे व्यस्त रेलवे स्टेशन कौन सा है?",
    options: ["छत्रपति शिवाजी टर्मिनस", "हावड़ा जंक्शन", "नई दिल्ली", "लखनऊ चारबाग"],
    correct: 1,
    explanation: "हावड़ा जंक्शन भारत का सबसे व्यस्त रेलवे स्टेशन है।",
  },

  // Police - GK
  {
    id: 21,
    category: "police",
    question: "भारत का राष्ट्रीय खेल कौन सा है?",
    options: ["क्रिकेट", "हॉकी", "कबड्डी", "फुटबॉल"],
    correct: 1,
    explanation: "हॉकी भारत का राष्ट्रीय खेल है।",
  },
  {
    id: 22,
    category: "police",
    question: "भारत के प्रथम राष्ट्रपति कौन थे?",
    options: ["जवाहरलाल नेहरू", "डॉ. राजेंद्र प्रसाद", "सर्वपल्ली राधाकृष्णन", "जाकिर हुसैन"],
    correct: 1,
    explanation: "डॉ. राजेंद्र प्रसाद भारत के प्रथम राष्ट्रपति थे (1950-1962)।",
  },
  {
    id: 23,
    category: "police",
    question: "भारत का सबसे बड़ा राज्य (क्षेत्रफल के आधार पर) कौन सा है?",
    options: ["मध्यप्रदेश", "महाराष्ट्र", "राजस्थान", "उत्तर प्रदेश"],
    correct: 2,
    explanation: "राजस्थान क्षेत्रफल के आधार पर भारत का सबसे बड़ा राज्य है।",
  },
  {
    id: 24,
    category: "police",
    question: "भारत का संविधान कब लागू हुआ?",
    options: ["15 अगस्त 1947", "26 जनवरी 1950", "26 नवंबर 1949", "2 अक्टूबर 1950"],
    correct: 1,
    explanation: "26 जनवरी 1950 को भारत का संविधान लागू हुआ।",
  },
  {
    id: 25,
    category: "police",
    question: "IPC का पूर्ण रूप क्या है?",
    options: [
      "Indian Penal Code",
      "Indian Police Code",
      "Indian Protection Code",
      "Indian Public Code",
    ],
    correct: 0,
    explanation: "IPC = Indian Penal Code (भारतीय दंड संहिता)",
  },
  {
    id: 26,
    category: "police",
    question: "भारत में कितने उच्च न्यायालय हैं?",
    options: ["21", "23", "25", "27"],
    correct: 2,
    explanation: "भारत में 25 उच्च न्यायालय हैं।",
  },
  {
    id: 27,
    category: "police",
    question: "पुलिस का प्रशिक्षण संस्थान BPR&D का मुख्यालय कहाँ है?",
    options: ["मुंबई", "चेन्नई", "नई दिल्ली", "हैदराबाद"],
    correct: 2,
    explanation: "BPR&D (Bureau of Police Research & Development) का मुख्यालय नई दिल्ली में है।",
  },
  {
    id: 28,
    category: "police",
    question: "आर्टिकल 21 किससे संबंधित है?",
    options: ["वाक् स्वतंत्रता", "जीवन का अधिकार", "शिक्षा का अधिकार", "समानता का अधिकार"],
    correct: 1,
    explanation: "अनुच्छेद 21 - जीवन और व्यक्तिगत स्वतंत्रता का संरक्षण।",
  },
  {
    id: 29,
    category: "police",
    question: "भारत के प्रधानमंत्री की नियुक्ति कौन करता है?",
    options: ["संसद", "राष्ट्रपति", "मुख्य न्यायाधीश", "उपराष्ट्रपति"],
    correct: 1,
    explanation: "प्रधानमंत्री की नियुक्ति राष्ट्रपति द्वारा की जाती है।",
  },
  {
    id: 30,
    category: "police",
    question: "FIR का पूर्ण रूप क्या है?",
    options: [
      "First Information Report",
      "Formal Investigation Report",
      "First Investigation Record",
      "Final Information Register",
    ],
    correct: 0,
    explanation: "FIR = First Information Report (प्रथम सूचना रिपोर्ट)",
  },

  // Banking - SBI Level
  {
    id: 31,
    category: "banking",
    question: "SBI का मुख्यालय कहाँ है?",
    options: ["नई दिल्ली", "मुंबई", "कोलकाता", "चेन्नई"],
    correct: 1,
    explanation: "SBI (State Bank of India) का मुख्यालय मुंबई, महाराष्ट्र में है।",
  },
  {
    id: 32,
    category: "banking",
    question: "RBI की स्थापना कब हुई?",
    options: ["1930", "1934", "1935", "1947"],
    correct: 2,
    explanation: "RBI की स्थापना 1 अप्रैल 1935 को हुई।",
  },
  {
    id: 33,
    category: "banking",
    question: "IBPS का पूर्ण रूप क्या है?",
    options: [
      "Indian Banking Professional Society",
      "Institute of Banking Personnel Selection",
      "Indian Bureau of Public Sector",
      "Institute of Banking and Professional Studies",
    ],
    correct: 1,
    explanation: "IBPS = Institute of Banking Personnel Selection",
  },
  {
    id: 34,
    category: "banking",
    question: "NEFT का फुल फॉर्म क्या है?",
    options: [
      "National Electronic Fund Transfer",
      "National Easy Fund Transfer",
      "Net Electronic Funds Technology",
      "National Efficient Funds Transfer",
    ],
    correct: 0,
    explanation: "NEFT = National Electronic Fund Transfer",
  },
  {
    id: 35,
    category: "banking",
    question: "KYC का पूर्ण रूप क्या है?",
    options: [
      "Know Your Customer",
      "Keep Your Cash",
      "Know Your Credit",
      "Keep Your Customer",
    ],
    correct: 0,
    explanation: "KYC = Know Your Customer (अपने ग्राहक को जानें)",
  },
  {
    id: 36,
    category: "banking",
    question: "CRR का पूर्ण रूप क्या है?",
    options: [
      "Cash Reserve Ratio",
      "Credit Reserve Rate",
      "Commercial Reserve Ratio",
      "Current Reserve Rate",
    ],
    correct: 0,
    explanation: "CRR = Cash Reserve Ratio (नकद आरक्षित अनुपात)",
  },
  {
    id: 37,
    category: "banking",
    question: "भारत में बैंकों का राष्ट्रीयकरण पहली बार कब हुआ?",
    options: ["1955", "1969", "1980", "1991"],
    correct: 1,
    explanation: "1969 में 14 बड़े बैंकों का राष्ट्रीयकरण हुआ।",
  },
  {
    id: 38,
    category: "banking",
    question: "ATM का पूर्ण रूप क्या है?",
    options: [
      "Automated Teller Machine",
      "Automatic Transaction Machine",
      "Automated Transaction Monitor",
      "Any Time Money",
    ],
    correct: 0,
    explanation: "ATM = Automated Teller Machine",
  },
  {
    id: 39,
    category: "banking",
    question: "SLR का पूर्ण रूप क्या है?",
    options: [
      "Statutory Liquidity Ratio",
      "State Liquidity Reserve",
      "Standard Lending Rate",
      "Scheduled Liquidity Ratio",
    ],
    correct: 0,
    explanation: "SLR = Statutory Liquidity Ratio (वैधानिक तरलता अनुपात)",
  },
  {
    id: 40,
    category: "banking",
    question: "RTGS में न्यूनतम लेनदेन राशि कितनी है?",
    options: ["₹1 लाख", "₹2 लाख", "₹50,000", "₹5 लाख"],
    correct: 1,
    explanation: "RTGS में न्यूनतम लेनदेन राशि ₹2 लाख है।",
  },

  // Defence Exams
  {
    id: 41,
    category: "defence",
    question: "NDA का पूर्ण रूप क्या है?",
    options: [
      "National Defence Academy",
      "Naval Defence Alliance",
      "National Development Agency",
      "Naval Development Academy",
    ],
    correct: 0,
    explanation: "NDA = National Defence Academy (राष्ट्रीय रक्षा अकादमी)",
  },
  {
    id: 42,
    category: "defence",
    question: "NDA कहाँ स्थित है?",
    options: ["देहरादून", "खड़कवासला, पुणे", "चेन्नई", "नई दिल्ली"],
    correct: 1,
    explanation: "NDA खड़कवासला, पुणे (महाराष्ट्र) में स्थित है।",
  },
  {
    id: 43,
    category: "defence",
    question: "भारतीय थलसेना का प्रमुख कौन होता है?",
    options: ["राष्ट्रपति", "चीफ ऑफ आर्मी स्टाफ", "रक्षा मंत्री", "प्रधानमंत्री"],
    correct: 1,
    explanation: "चीफ ऑफ आर्मी स्टाफ (COAS) भारतीय थलसेना का प्रमुख होता है।",
  },
  {
    id: 44,
    category: "defence",
    question: "भारत का सर्वोच्च सैनिक सम्मान कौन सा है?",
    options: ["अशोक चक्र", "परम वीर चक्र", "महावीर चक्र", "वीर चक्र"],
    correct: 1,
    explanation: "परम वीर चक्र (PVC) भारत का सर्वोच्च सैनिक सम्मान है।",
  },
  {
    id: 45,
    category: "defence",
    question: "AFCAT का पूर्ण रूप क्या है?",
    options: [
      "Air Force Common Admission Test",
      "Armed Forces Combat Assessment Test",
      "Air Force Combat Aptitude Test",
      "Armed Forces Common Aptitude Test",
    ],
    correct: 0,
    explanation: "AFCAT = Air Force Common Admission Test",
  },
  {
    id: 46,
    category: "defence",
    question: "भारतीय नौसेना दिवस कब मनाया जाता है?",
    options: ["4 दिसंबर", "15 जनवरी", "8 अक्टूबर", "26 जनवरी"],
    correct: 0,
    explanation: "4 दिसंबर को भारतीय नौसेना दिवस मनाया जाता है।",
  },
  {
    id: 47,
    category: "defence",
    question: "CDS का पूर्ण रूप क्या है?",
    options: [
      "Combined Defence Services",
      "Central Defence System",
      "Chief Defence Staff",
      "Combat Defence Services",
    ],
    correct: 0,
    explanation: "CDS = Combined Defence Services (संयुक्त रक्षा सेवाएं)",
  },
  {
    id: 48,
    category: "defence",
    question: "भारत के पहले CDS (Chief of Defence Staff) कौन थे?",
    options: ["बिपिन रावत", "मनोज मुकुंद नरवाणे", "अनिल चौहान", "दलबीर सिंह"],
    correct: 0,
    explanation: "जनरल बिपिन रावत भारत के पहले CDS थे।",
  },
  {
    id: 49,
    category: "defence",
    question: "भारतीय थलसेना दिवस कब मनाया जाता है?",
    options: ["26 जनवरी", "15 जनवरी", "8 अक्टूबर", "4 दिसंबर"],
    correct: 1,
    explanation: "15 जनवरी को भारतीय थलसेना दिवस मनाया जाता है।",
  },
  {
    id: 50,
    category: "defence",
    question: "अग्निवीर योजना किस वर्ष शुरू की गई?",
    options: ["2020", "2021", "2022", "2023"],
    correct: 2,
    explanation: "अग्निवीर योजना 2022 में शुरू की गई।",
  },

  // UPSC Exams
  {
    id: 51,
    category: "upsc",
    question: "UPSC का पूर्ण रूप क्या है?",
    options: [
      "Union Public Service Commission",
      "United Public Service Committee",
      "Universal Public Service Commission",
      "Union Public Selection Committee",
    ],
    correct: 0,
    explanation: "UPSC = Union Public Service Commission (संघ लोक सेवा आयोग)",
  },
  {
    id: 52,
    category: "upsc",
    question: "IAS का पूर्ण रूप क्या है?",
    options: [
      "Indian Administrative Service",
      "Indian Army Service",
      "Indian Affairs Service",
      "Indian Audit Service",
    ],
    correct: 0,
    explanation: "IAS = Indian Administrative Service (भारतीय प्रशासनिक सेवा)",
  },
  {
    id: 53,
    category: "upsc",
    question: "UPSC Civil Services मुख्य परीक्षा में कितने वैकल्पिक विषय पेपर होते हैं?",
    options: ["1", "2", "3", "4"],
    correct: 1,
    explanation: "UPSC Mains में वैकल्पिक विषय के 2 पेपर (Paper VI और Paper VII) होते हैं।",
  },
  {
    id: 54,
    category: "upsc",
    question: "भारत का योजना आयोग किस वर्ष बंद हुआ?",
    options: ["2012", "2013", "2014", "2015"],
    correct: 2,
    explanation: "2014 में योजना आयोग को भंग कर NITI Aayog बनाया गया।",
  },
  {
    id: 55,
    category: "upsc",
    question: "लोकसभा में कुल कितनी सीटें हैं?",
    options: ["542", "543", "545", "550"],
    correct: 1,
    explanation: "लोकसभा में कुल 543 निर्वाचन क्षेत्र हैं।",
  },
  {
    id: 56,
    category: "upsc",
    question: "भारत का वित्तीय वर्ष कब से कब तक होता है?",
    options: ["जनवरी-दिसंबर", "अप्रैल-मार्च", "जुलाई-जून", "अक्टूबर-सितंबर"],
    correct: 1,
    explanation: "भारत का वित्तीय वर्ष 1 अप्रैल से 31 मार्च तक होता है।",
  },
  {
    id: 57,
    category: "upsc",
    question: "भारत की पहली महिला प्रधानमंत्री कौन थीं?",
    options: ["सरोजिनी नायडू", "इंदिरा गांधी", "प्रतिभा पाटिल", "सुषमा स्वराज"],
    correct: 1,
    explanation: "इंदिरा गांधी भारत की पहली और एकमात्र महिला प्रधानमंत्री रही हैं।",
  },
  {
    id: 58,
    category: "upsc",
    question: "संसद के दोनों सदनों की संयुक्त बैठक की अध्यक्षता कौन करता है?",
    options: ["राष्ट्रपति", "उपराष्ट्रपति", "लोकसभा अध्यक्ष", "प्रधानमंत्री"],
    correct: 2,
    explanation: "संसद की संयुक्त बैठक की अध्यक्षता लोकसभा अध्यक्ष करते हैं।",
  },
  {
    id: 59,
    category: "upsc",
    question: "भारत का सर्वोच्च न्यायालय कहाँ स्थित है?",
    options: ["मुंबई", "कोलकाता", "नई दिल्ली", "हैदराबाद"],
    correct: 2,
    explanation: "भारत का सर्वोच्च न्यायालय नई दिल्ली में है।",
  },
  {
    id: 60,
    category: "upsc",
    question: "राज्यसभा में राज्यों के प्रतिनिधि कितने वर्षों के लिए चुने जाते हैं?",
    options: ["4 वर्ष", "5 वर्ष", "6 वर्ष", "7 वर्ष"],
    correct: 2,
    explanation: "राज्यसभा सदस्यों का कार्यकाल 6 वर्ष होता है।",
  },
];

export function getQuestionsByCategory(categoryId: string): Question[] {
  return questions.filter((q) => q.category === categoryId);
}

export function getAllQuestions(): Question[] {
  return questions;
}

export function getDailyQuizQuestions(): Question[] {
  const shuffled = [...questions].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(90, shuffled.length));
}

export function getMockTestQuestions(categoryId: string): Question[] {
  const categoryQuestions = getQuestionsByCategory(categoryId);
  const shuffled = [...categoryQuestions].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(30, shuffled.length));
}
