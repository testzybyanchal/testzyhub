import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { categories, getQuestionsByCategory, getAllQuestions, type Question } from "@/data/questions";
import { fetchDBQuestions, fetchSubjects } from "@/hooks/useQuestions";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTranslatedQuestion } from "@/hooks/useTranslatedQuestion";

const QUESTION_TIME = 60;

const SUBJECT_ICONS: Record<string, string> = {
  "सामान्य ज्ञान": "🌍",
  "गणित": "🔢",
  "तार्किक क्षमता": "🧠",
  "सामान्य जागरूकता": "📰",
  "अंग्रेजी": "📝",
  "सामान्य विज्ञान": "🔬",
  "सामान्य हिंदी": "📖",
  "कंप्यूटर": "💻",
  "मात्रात्मक योग्यता": "📊",
};

const SUBJECT_ENGLISH: Record<string, string> = {
  "सामान्य ज्ञान":    "General Knowledge",
  "गणित":             "Mathematics",
  "तार्किक क्षमता":  "Reasoning",
  "सामान्य जागरूकता":"General Awareness",
  "अंग्रेजी":        "English",
  "सामान्य विज्ञान": "General Science",
  "सामान्य हिंदी":   "Hindi Language",
  "कंप्यूटर":        "Computer",
  "मात्रात्मक योग्यता": "Quantitative Aptitude",
};

function subjectLabel(s: string) {
  return SUBJECT_ENGLISH[s] || s;
}

// Seeded shuffle — each user gets a unique but consistent order
function seededShuffle<T>(arr: T[], seed: number): T[] {
  const a = [...arr];
  let s = Math.abs(seed);
  for (let i = a.length - 1; i > 0; i--) {
    s = ((s * 1664525) + 1013904223) & 0x7fffffff;
    const j = s % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const CATEGORY_CARDS = [
  { id: "ssc",     icon: "📋", name: "SSC Exams",      desc: "CGL, CHSL, MTS, GD Constable",  color: "#2563eb", bg: "linear-gradient(135deg,#1a3a6b,#2c5aa0)" },
  { id: "railway", icon: "🚂", name: "Railway Exams",  desc: "RRB NTPC, Group D, ALP",        color: "#059669", bg: "linear-gradient(135deg,#7c2d12,#dc2626)" },
  { id: "police",  icon: "👮", name: "Police Exams",   desc: "UP Police SI, Constable",       color: "#7c3aed", bg: "linear-gradient(135deg,#1e3a5f,#7c3aed)" },
  { id: "banking", icon: "💰", name: "Banking Exams",  desc: "SBI PO, IBPS, RBI Grade B",     color: "#065f46", bg: "linear-gradient(135deg,#065f46,#10b981)" },
];

export default function PracticeTest() {
  const [location, navigate] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const urlCategory = searchParams.get("category") || "all";
  const { user, setShowAuthModal, refreshUser } = useAuth();
  const { t } = useLanguage();

  // Step 1: Category selection
  const [localCategory, setLocalCategory] = useState<string | null>(
    urlCategory !== "all" ? urlCategory : null
  );

  // Step 2: Subject selection
  const [subjects, setSubjects] = useState<Array<{ subject: string; count: string }>>([]);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [loadingSubjects, setLoadingSubjects] = useState(false);

  // Quiz state
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loadingQ, setLoadingQ] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [finished, setFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(QUESTION_TIME);
  const [submitted, setSubmitted] = useState(false);
  const [rewards, setRewards] = useState<{ xp: number; coins: number } | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tq = useTranslatedQuestion(questions[currentIdx] ?? null);

  const category = categories.find((c) => c.id === (localCategory || urlCategory));

  // Load subjects when category is selected
  useEffect(() => {
    if (!user || !localCategory) return;
    setLoadingSubjects(true);
    setSubjects([]);
    setSelectedSubject(null);
    fetchSubjects(localCategory).then((subs) => {
      setSubjects(subs);
      setLoadingSubjects(false);
    });
  }, [localCategory, user]);

  // Load questions when subject is selected
  useEffect(() => {
    if (!user || !selectedSubject || !localCategory) return;
    setLoadingQ(true);
    fetchDBQuestions(localCategory, "practice", undefined, selectedSubject).then((dbQs) => {
      const staticQs = getQuestionsByCategory(localCategory);
      const qs = dbQs.length > 0 ? dbQs : staticQs;
      // Seed = user.id * today's date (so each user sees different order, changes daily)
      const today = new Date();
      const seed = (user.id * 31337) + today.getDate() + today.getMonth() * 31;
      const shuffled = seededShuffle([...qs], seed);
      setQuestions(shuffled);
      setCurrentIdx(0);
      setSelected(null);
      setScore(0);
      setCorrect(0);
      setWrong(0);
      setFinished(false);
      setTimeLeft(QUESTION_TIME);
      setSubmitted(false);
      setRewards(null);
      setLoadingQ(false);
    });
  }, [selectedSubject, localCategory, user]);

  // Timer
  useEffect(() => {
    if (!user || finished || selected !== null || !selectedSubject) return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          setWrong((w) => w + 1);
          setScore((s) => Math.max(0, s - 0.5));
          moveNext();
          return QUESTION_TIME;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [currentIdx, selected, finished, user, selectedSubject]);

  function moveNext() {
    setCurrentIdx((i) => {
      if (i + 1 >= questions.length) { setFinished(true); return i; }
      setSelected(null);
      setTimeLeft(QUESTION_TIME);
      return i + 1;
    });
  }

  function handleSelect(idx: number) {
    if (selected !== null) return;
    clearInterval(timerRef.current!);
    setSelected(idx);
    const current = questions[currentIdx];
    if (idx === current.correct) { setCorrect((c) => c + 1); setScore((s) => s + 1); }
    else { setWrong((w) => w + 1); setScore((s) => Math.max(0, s - 0.5)); }
  }

  function handleNext() { moveNext(); }

  async function submitResult() {
    if (submitted || !user) return;
    setSubmitted(true);
    try {
      const res = await fetch("/api/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          quizType: "practice",
          category: localCategory,
          correctCount: correct,
          wrongCount: wrong,
          totalQuestions: questions.length,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (data.xpEarned !== undefined) setRewards({ xp: data.xpEarned, coins: data.coinsEarned || 0 });
      await refreshUser();
    } catch {}
  }

  useEffect(() => { if (finished) submitResult(); }, [finished]);

  // ── Auth guard ──────────────────────────────────────────────────────────────
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--gray-50)" }}>
        <div className="text-center">
          <p className="text-xl font-semibold text-gray-700 mb-4">Practice Test के लिए Login ज़रूरी है</p>
          <button onClick={() => setShowAuthModal(true)} className="btn-primary px-6 py-2.5 rounded-xl">
            Login / Signup
          </button>
        </div>
      </div>
    );
  }

  // ── STEP 1: Category Selection ───────────────────────────────────────────────
  if (!localCategory) {
    return (
      <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
          <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
            <button onClick={() => navigate("/")} className="text-gray-500 hover:text-gray-700 text-sm">← वापस</button>
            <span className="font-bold text-[#1a3a6b]">📚 Practice Test — Exam चुनें</span>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <div className="text-5xl mb-3">🎯</div>
            <h1 className="text-2xl font-black text-[#1a3a6b] mb-2">कौनसी Exam की तैयारी?</h1>
            <p className="text-gray-500 text-sm">अपनी exam category चुनें, फिर subject select करें</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {CATEGORY_CARDS.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setLocalCategory(cat.id)}
                className="group rounded-3xl p-1 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
                style={{ background: cat.bg }}
              >
                <div className="bg-white/10 backdrop-blur-sm rounded-[22px] p-6 text-left">
                  <div className="text-5xl mb-3">{cat.icon}</div>
                  <h3 className="text-xl font-black text-white mb-1">{cat.name}</h3>
                  <p className="text-white/70 text-sm mb-4">{cat.desc}</p>
                  <div className="inline-flex items-center gap-2 bg-white/20 text-white text-xs font-bold px-4 py-2 rounded-xl">
                    Practice शुरू करें →
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── STEP 2: Subject Selection ────────────────────────────────────────────────
  if (!selectedSubject) {
    const catCard = CATEGORY_CARDS.find(c => c.id === localCategory);
    return (
      <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
          <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
            <button onClick={() => setLocalCategory(null)} className="text-gray-500 hover:text-gray-700 text-sm">← Category</button>
            <span className="font-bold text-[#1a3a6b]">
              {catCard?.icon} {catCard?.name} — Subject चुनें
            </span>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <div className="text-5xl mb-3">{catCard?.icon || "📚"}</div>
            <h1 className="text-2xl font-black text-[#1a3a6b] mb-2">{catCard?.name} Practice</h1>
            <p className="text-gray-500 text-sm">Subject चुनें और practice शुरू करें</p>
          </div>

          {loadingSubjects ? (
            <div className="text-center py-12">
              <div className="text-4xl mb-3 float-anim">📖</div>
              <p className="text-gray-500 font-semibold">Subjects लोड हो रहे हैं...</p>
            </div>
          ) : subjects.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-4xl mb-3">📭</div>
              <p className="text-gray-600 font-semibold mb-2">अभी कोई subject नहीं मिला</p>
              <p className="text-gray-400 text-sm mb-4">Admin questions upload करेगा या Mixed practice करें</p>
              <button
                onClick={() => {
                  fetchDBQuestions(localCategory!, "practice").then((dbQs) => {
                    const staticQs = getQuestionsByCategory(localCategory!);
                    const qs = dbQs.length > 0 ? dbQs : staticQs;
                    const today = new Date();
                    const seed = (user.id * 31337) + today.getDate() + today.getMonth() * 31;
                    setQuestions(seededShuffle([...qs], seed));
                    setSelectedSubject("mixed");
                  });
                }}
                className="btn-primary px-8 py-3 rounded-2xl"
              >
                🎲 Mixed Practice शुरू करें
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                {subjects.map(({ subject, count }) => {
                  const icon = SUBJECT_ICONS[subject] || "📋";
                  return (
                    <button
                      key={subject}
                      onClick={() => setSelectedSubject(subject)}
                      className="bg-white border-2 border-gray-100 rounded-3xl p-6 text-left hover:border-[#1a3a6b] hover:shadow-lg transition-all hover:-translate-y-1 group"
                    >
                      <div className="text-4xl mb-3">{icon}</div>
                      <h3 className="font-black text-[#1a3a6b] text-lg mb-1 group-hover:text-[#2c5aa0]">{subjectLabel(subject)}</h3>
                      <p className="text-gray-400 text-[11px] font-semibold mb-0.5">{subject}</p>
                      <p className="text-gray-400 text-xs font-semibold">{count} Questions Available</p>
                      <div className="mt-4 bg-[#1a3a6b] text-white text-xs font-bold py-2 px-4 rounded-xl inline-block opacity-0 group-hover:opacity-100 transition-all">
                        Start →
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200 rounded-3xl p-5 flex items-center justify-between">
                <div>
                  <h3 className="font-black text-purple-800 text-base">🎲 Mixed Practice</h3>
                  <p className="text-purple-600 text-sm">सभी subjects मिलाकर practice करें</p>
                </div>
                <button
                  onClick={() => {
                    fetchDBQuestions(localCategory!, "practice").then((dbQs) => {
                      const staticQs = getQuestionsByCategory(localCategory!);
                      const qs = dbQs.length > 0 ? dbQs : staticQs;
                      const today = new Date();
                      const seed = (user.id * 31337) + today.getDate() + today.getMonth() * 31;
                      setQuestions(seededShuffle([...qs], seed));
                      setSelectedSubject("mixed");
                    });
                  }}
                  className="bg-purple-600 text-white font-bold px-6 py-3 rounded-2xl hover:bg-purple-700 transition-all"
                >
                  शुरू करें →
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  // ── Loading questions ────────────────────────────────────────────────────────
  if (loadingQ || (selectedSubject && questions.length === 0)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 float-anim">📚</div>
          <p className="text-gray-500 text-lg font-semibold">Questions Load हो रहे हैं...</p>
          <p className="text-gray-400 text-sm mt-1">{selectedSubject !== "mixed" ? subjectLabel(selectedSubject) : ""}</p>
        </div>
      </div>
    );
  }

  // ── Result Screen ────────────────────────────────────────────────────────────
  if (finished) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="min-h-screen flex items-center justify-center px-4 pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white rounded-3xl shadow-xl p-8 max-w-md w-full text-center fade-in-up">
          <div className="text-5xl mb-4">
            {pct >= 80 ? "🎉" : pct >= 60 ? "👍" : pct >= 40 ? "📚" : "😔"}
          </div>
          <h2 className="text-2xl font-black text-[#1a3a6b] mb-1">Practice पूरी!</h2>
          {selectedSubject !== "mixed" && (
            <div className="inline-block bg-blue-50 text-blue-700 text-xs font-bold px-3 py-1 rounded-full mb-3">
              {SUBJECT_ICONS[selectedSubject] || "📋"} {subjectLabel(selectedSubject)}
            </div>
          )}
          <p className="text-gray-500 mb-6 text-sm">
            {pct >= 80 ? "शानदार!" : pct >= 60 ? "अच्छा प्रयास!" : "और पढ़ाई ज़रूरी है।"}
          </p>
          <div className="bg-gradient-to-br from-[#1a3a6b] to-[#2c5aa0] text-white rounded-2xl p-6 mb-5">
            <div className="text-4xl font-black mb-1">{score.toFixed(1)} pts</div>
            <div className="text-blue-200 text-sm">{correct}/{questions.length} सही • {pct}%</div>
          </div>
          <div className="grid grid-cols-3 gap-3 text-sm mb-6">
            <div className="bg-green-50 rounded-xl p-3">
              <div className="font-black text-green-700 text-xl">{correct}</div>
              <div className="text-green-600 text-xs">सही ✓</div>
            </div>
            <div className="bg-red-50 rounded-xl p-3">
              <div className="font-black text-red-700 text-xl">{wrong}</div>
              <div className="text-red-600 text-xs">गलत ✗</div>
            </div>
            <div className="bg-yellow-50 rounded-xl p-3">
              <div className="font-black text-yellow-700 text-xl">+{score.toFixed(1)}</div>
              <div className="text-yellow-600 text-xs">Points</div>
            </div>
          </div>
          {rewards && (
            <div className="flex gap-3 mb-5">
              <div className="flex-1 bg-purple-50 border border-purple-200 rounded-2xl p-3 text-center">
                <div className="font-black text-purple-700 text-2xl">+{rewards.xp}</div>
                <div className="text-purple-500 text-xs font-semibold">XP मिले ⚡</div>
              </div>
              <div className="flex-1 bg-yellow-50 border border-yellow-200 rounded-2xl p-3 text-center">
                <div className="font-black text-yellow-700 text-2xl">+{rewards.coins}</div>
                <div className="text-yellow-500 text-xs font-semibold">Coins 🪙</div>
              </div>
            </div>
          )}
          <div className="flex gap-3">
            <button
              onClick={() => {
                setFinished(false); setCurrentIdx(0); setSelected(null);
                setScore(0); setCorrect(0); setWrong(0);
                setTimeLeft(QUESTION_TIME); setSubmitted(false); setRewards(null);
                const today = new Date();
                const seed = (user.id * 31337) + today.getDate() + today.getMonth() * 31 + Math.floor(Math.random() * 1000);
                setQuestions(qs => seededShuffle([...qs], seed));
              }}
              className="flex-1 btn-primary py-3 rounded-xl"
            >
              🔄 फिर करें
            </button>
            <button onClick={() => setSelectedSubject(null)} className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 rounded-xl transition-all">
              📚 Subject बदलें
            </button>
          </div>
          <button onClick={() => { setLocalCategory(null); setSelectedSubject(null); }} className="mt-2 w-full text-gray-400 hover:text-gray-600 text-sm py-2">
            🎯 Category बदलें
          </button>
          <button onClick={() => navigate("/")} className="w-full text-gray-400 hover:text-gray-600 text-sm py-1">
            🏠 Home जाएं
          </button>
        </div>
      </div>
    );
  }

  // ── Quiz Screen ──────────────────────────────────────────────────────────────
  const current = questions[currentIdx];
  const progress = ((currentIdx + 1) / questions.length) * 100;
  const timerUrgent = timeLeft <= 10;

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <button onClick={() => setSelectedSubject(null)} className="text-gray-500 hover:text-gray-700 text-sm">
              ← Subject
            </button>
            <span className="font-bold text-[#1a3a6b] text-sm">
              {selectedSubject !== "mixed" ? (
                <>{SUBJECT_ICONS[selectedSubject] || "📋"} {subjectLabel(selectedSubject)}</>
              ) : (
                <>{category?.icon || "📚"} Mixed</>
              )}
            </span>
            <div className="flex items-center gap-3">
              <span className={`font-mono font-bold text-lg px-3 py-0.5 rounded-lg ${timerUrgent ? "timer-urgent bg-red-50" : "text-[#1a3a6b] bg-blue-50"}`}>
                ⏱{timeLeft}s
              </span>
              <span className="text-sm text-gray-500 font-semibold">{currentIdx + 1}/{questions.length}</span>
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="progress-bar h-2 rounded-full" style={{ width: `${progress}%`, background: "linear-gradient(90deg, #1a3a6b, #2c5aa0)" }} />
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pt-4">
        <div className="flex gap-2 mb-4">
          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">✓ {correct} सही</span>
          <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold">✗ {wrong} गलत</span>
          <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-xs font-bold">⭐ {score.toFixed(1)} pts</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-8 fade-in-up" key={currentIdx}>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-4">
          <div className="text-xs font-bold text-[#2c5aa0] uppercase tracking-widest mb-3">
            {t("questionNo")} {currentIdx + 1}
            {tq?.isTranslating && <span className="ml-2 text-orange-400 text-[10px] font-normal animate-pulse">{t("translating")}</span>}
          </div>
          <p className="text-gray-800 font-semibold text-lg leading-relaxed">{tq?.translatedQuestion ?? current.question}</p>
        </div>

        <div className="flex flex-col gap-3">
          {current.options.map((opt, idx) => {
            let cls = "option-btn w-full text-left px-5 py-4 rounded-2xl font-medium text-gray-700 bg-white";
            if (selected !== null) {
              if (idx === current.correct) cls += " correct";
              else if (idx === selected) cls += " wrong";
              else cls += " border-gray-100 opacity-50";
            }
            return (
              <button key={idx} className={cls} onClick={() => handleSelect(idx)} disabled={selected !== null}>
                <span className="inline-flex items-center gap-3">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0 ${
                    selected !== null && idx === current.correct ? "bg-emerald-500 text-white" :
                    selected !== null && idx === selected ? "bg-red-500 text-white" : "text-gray-500"
                  }`}
                    style={selected === null || (idx !== current.correct && idx !== selected) ? { background: "rgba(26,58,107,0.08)" } : {}}>
                    {["A","B","C","D"][idx]}
                  </span>
                  {tq?.translatedOptions?.[idx] ?? opt}
                </span>
              </button>
            );
          })}
        </div>

        {selected !== null && current.explanation && (
          <div className="mt-4 bg-blue-50 border border-blue-200 rounded-2xl p-4 fade-in-up">
            <p className="text-sm font-bold text-[#1a3a6b] mb-1">💡</p>
            <p className="text-sm text-blue-700">{tq?.translatedExplanation ?? current.explanation}</p>
          </div>
        )}

        {selected !== null && (
          <button onClick={handleNext} className="mt-4 w-full btn-primary py-4 rounded-2xl text-lg font-bold fade-in-up">
            {currentIdx + 1 >= questions.length ? "✅ Result देखें" : "अगला प्रश्न →"}
          </button>
        )}
      </div>
    </div>
  );
}
