import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { categories } from "@/data/questions";

type Prize = { id: number; rank_position: number; title: string; description: string; amount: string; };
type UserRow = { id: number; name: string; email: string; is_admin: boolean; totalPoints: number; created_at: string; };
type DBQuestion = { id: number; category: string; quiz_type: string; question: string; option_a: string; option_b: string; option_c: string; option_d: string; correct_option: number; explanation: string; };

const quizTypes = [
  { id: "practice", label: "📚 Practice Test" },
  { id: "mock", label: "⏱️ Mock Test" },
  { id: "quiz", label: "⚡ Category Quiz" },
  { id: "daily", label: "🎯 Daily Quiz" },
  { id: "mega_quiz", label: "🏆 Mega Quiz" },
];

export default function AdminPanel() {
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [dbQuestions, setDbQuestions] = useState<DBQuestion[]>([]);
  const [tab, setTab] = useState<"upload" | "questions" | "prizes" | "users">("upload");
  const [editing, setEditing] = useState<Prize[]>([]);
  const [saveMsg, setSaveMsg] = useState("");
  const [loading, setLoading] = useState(true);

  // Upload form state
  const [uploadCat, setUploadCat] = useState("ssc");
  const [uploadType, setUploadType] = useState("practice");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [uploadResult, setUploadResult] = useState<{ success?: boolean; inserted?: number; error?: string; hint?: string } | null>(null);
  const [previewData, setPreviewData] = useState<{ total: number; questions: any[]; rawSnippet?: string } | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // Filter for questions tab
  const [filterCat, setFilterCat] = useState("all");
  const [filterType, setFilterType] = useState("all");

  // Bulk delete state
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);

  // Upload set number (for mock/quiz types)
  const [uploadSetNumber, setUploadSetNumber] = useState(1);
  const [uploadSubject, setUploadSubject] = useState("");
  const [megaQs, setMegaQs] = useState<DBQuestion[]>([]);

  // Mega Quiz Settings
  type MegaSettings = { quiz_date: string; start_time: string; end_time: string; entry_fee: number; title: string; is_active: boolean };
  const [megaSettings, setMegaSettings] = useState<MegaSettings>({ quiz_date: "", start_time: "20:00", end_time: "20:30", entry_fee: 10, title: "Weekly Mega Quiz", is_active: true });
  const [megaSettingsMsg, setMegaSettingsMsg] = useState("");
  const [savingMegaSettings, setSavingMegaSettings] = useState(false);

  // Reviews tab
  type AdminReview = { id: number; user_name: string; email: string; rating: number; comment: string; approved: boolean; created_at: string };
  const [adminReviews, setAdminReviews] = useState<AdminReview[]>([]);
  const [reviewMsg, setReviewMsg] = useState("");

  // Help queries tab
  type HelpQuery = { id: number; name: string; email: string; subject: string; message: string; status: string; admin_reply: string | null; created_at: string };
  const [helpQueries, setHelpQueries] = useState<HelpQuery[]>([]);
  const [replyText, setReplyText] = useState<Record<number, string>>({});
  const [helpMsg, setHelpMsg] = useState("");

  useEffect(() => {
    if (!user?.isAdmin) return;
    Promise.all([
      fetch("/api/prizes", { credentials: "include" }).then(r => r.json()),
      fetch("/api/admin/users", { credentials: "include" }).then(r => r.json()),
    ]).then(([pr, us]) => {
      setPrizes(pr.prizes || []);
      setEditing(JSON.parse(JSON.stringify(pr.prizes || [])));
      setUsers(us.users || []);
    }).finally(() => setLoading(false));
  }, [user]);

  async function loadQuestions() {
    const params = new URLSearchParams();
    if (filterCat !== "all") params.set("category", filterCat);
    if (filterType !== "all") params.set("type", filterType);
    const res = await fetch(`/api/admin/questions?${params}`, { credentials: "include" });
    const data = await res.json();
    setDbQuestions(data.questions || []);
  }

  useEffect(() => {
    if (tab === "questions" && user?.isAdmin) loadQuestions();
  }, [tab, filterCat, filterType, user]);

  async function handlePreview() {
    if (!uploadFile) return;
    setPreviewing(true);
    setPreviewData(null);
    setUploadResult(null);
    try {
      const form = new FormData();
      form.append("file", uploadFile);
      const res = await fetch("/api/admin/preview-questions", {
        method: "POST",
        credentials: "include",
        body: form,
      });
      const data = await res.json();
      if (data.error) setUploadResult({ error: data.error });
      else setPreviewData(data);
    } catch {
      setUploadResult({ error: "Preview error — Network problem" });
    } finally {
      setPreviewing(false);
    }
  }

  async function handleUpload() {
    if (!uploadFile) return;
    setUploading(true);
    setUploadResult(null);
    try {
      const form = new FormData();
      form.append("file", uploadFile);
      form.append("category", uploadCat);
      form.append("quiz_type", uploadType);
      if (uploadType === "mock") form.append("set_number", String(uploadSetNumber));
      if (uploadType === "practice" && uploadSubject.trim()) form.append("subject", uploadSubject.trim());
      const res = await fetch("/api/admin/upload-questions", {
        method: "POST",
        credentials: "include",
        body: form,
      });
      const data = await res.json();
      setUploadResult(data);
      if (data.success) {
        setUploadFile(null);
        setPreviewData(null);
        if (fileRef.current) fileRef.current.value = "";
      }
    } catch {
      setUploadResult({ error: "Network error" });
    } finally {
      setUploading(false);
    }
  }

  function handleFileDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) { setUploadFile(file); setPreviewData(null); setUploadResult(null); }
  }

  async function deleteQuestion(id: number) {
    if (!confirm("यह question delete करें?")) return;
    await fetch(`/api/admin/questions/${id}`, { method: "DELETE", credentials: "include" });
    setDbQuestions(prev => prev.filter(q => q.id !== id));
    setSelectedIds(prev => { const s = new Set(prev); s.delete(id); return s; });
  }

  async function bulkDelete() {
    if (selectedIds.size === 0) return;
    if (!confirm(`${selectedIds.size} questions delete करें? यह undo नहीं होगा!`)) return;
    setBulkDeleting(true);
    try {
      const res = await fetch("/api/admin/questions/bulk-delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ ids: [...selectedIds] }),
      });
      if ((await res.json()).success) {
        setDbQuestions(prev => prev.filter(q => !selectedIds.has(q.id)));
        setSelectedIds(new Set());
      }
    } finally {
      setBulkDeleting(false);
    }
  }

  function toggleSelect(id: number) {
    setSelectedIds(prev => {
      const s = new Set(prev);
      if (s.has(id)) s.delete(id); else s.add(id);
      return s;
    });
  }

  function toggleSelectAll() {
    if (selectedIds.size === dbQuestions.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(dbQuestions.map(q => q.id)));
    }
  }

  async function loadMegaQs() {
    const res = await fetch(`/api/admin/questions?type=mega_quiz`, { credentials: "include" });
    const data = await res.json();
    setMegaQs(data.questions || []);
  }

  useEffect(() => {
    if (tab === "mega" && user?.isAdmin) {
      loadMegaQs();
      fetch("/api/mega-quiz/settings", { credentials: "include" })
        .then(r => r.json())
        .then(d => {
          if (d.quiz_date) {
            setMegaSettings({
              quiz_date: d.quiz_date ? String(d.quiz_date).slice(0, 10) : "",
              start_time: d.start_time || "20:00",
              end_time: d.end_time || "20:30",
              entry_fee: d.entry_fee ?? 10,
              title: d.title || "Weekly Mega Quiz",
              is_active: d.is_active !== false,
            });
          }
        });
    }
  }, [tab, user]);

  useEffect(() => {
    if (tab === "reviews" && user?.isAdmin) {
      fetch("/api/admin/reviews", { credentials: "include" })
        .then(r => r.json())
        .then(d => setAdminReviews(d.reviews || []));
    }
  }, [tab, user]);

  useEffect(() => {
    if (tab === "help" && user?.isAdmin) {
      fetch("/api/admin/help-queries", { credentials: "include" })
        .then(r => r.json())
        .then(d => setHelpQueries(d.queries || []));
    }
  }, [tab, user]);

  async function toggleReviewApproval(id: number, approved: boolean) {
    await fetch(`/api/admin/reviews/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ approved }),
    });
    setAdminReviews(prev => prev.map(r => r.id === id ? { ...r, approved } : r));
    setReviewMsg(`✅ Review ${approved ? "approved" : "rejected"}!`);
    setTimeout(() => setReviewMsg(""), 2000);
  }

  async function replyToQuery(id: number) {
    const reply = replyText[id]?.trim();
    if (!reply) return;
    await fetch(`/api/admin/help-queries/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ reply, status: "resolved" }),
    });
    setHelpQueries(prev => prev.map(q => q.id === id ? { ...q, admin_reply: reply, status: "resolved" } : q));
    setReplyText(prev => ({ ...prev, [id]: "" }));
    setHelpMsg("✅ Reply भेज दिया!");
    setTimeout(() => setHelpMsg(""), 2000);
  }

  function updateEditing(idx: number, field: keyof Prize, value: string) {
    const updated = [...editing];
    (updated[idx] as any)[field] = value;
    setEditing(updated);
  }

  async function savePrizes() {
    setSaveMsg("Saving...");
    try {
      const res = await fetch("/api/prizes", {
        method: "PUT", headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ prizes: editing }),
      });
      if (res.ok) {
        const data = await res.json();
        setPrizes(data.prizes);
        setEditing(JSON.parse(JSON.stringify(data.prizes)));
        setSaveMsg("✅ Saved!");
      } else {
        setSaveMsg("❌ Error");
      }
    } catch { setSaveMsg("❌ Network error"); }
    setTimeout(() => setSaveMsg(""), 3000);
  }

  async function saveMegaSettings() {
    setSavingMegaSettings(true);
    setMegaSettingsMsg("Saving...");
    try {
      const res = await fetch("/api/mega-quiz/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(megaSettings),
      });
      if (res.ok) { setMegaSettingsMsg("✅ Settings save हो गए!"); }
      else { setMegaSettingsMsg("❌ Error saving"); }
    } catch { setMegaSettingsMsg("❌ Network error"); }
    setSavingMegaSettings(false);
    setTimeout(() => setMegaSettingsMsg(""), 3000);
  }

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 gap-4">
        <div className="text-5xl">🔐</div>
        <h2 className="text-2xl font-black text-gray-800">Admin Login करें</h2>
        <p className="text-gray-500 text-sm">Admin Panel केवल admin के लिए है।</p>
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5 max-w-sm w-full text-sm text-center">
          <p className="text-gray-600">अपने admin account से Home page पर Login करें, फिर यहाँ आएं।</p>
        </div>
        <button
          onClick={() => navigate("/")}
          className="btn-primary px-6 py-2.5 rounded-xl"
        >
          Home जाकर Login करें
        </button>
      </div>
    );
  }

  const tabs = [
    { id: "upload", label: "📤 Upload" },
    { id: "questions", label: "📋 Questions" },
    { id: "mega", label: "🏆 Mega Quiz" },
    { id: "prizes", label: "💰 Prizes" },
    { id: "users", label: `👤 Users` },
    { id: "reviews", label: "⭐ Reviews" },
    { id: "help", label: "🛟 Help" },
  ];

  return (
    <div className="min-h-screen pb-24 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {/* Header */}
      <div className="py-8 px-4" style={{ background: "linear-gradient(135deg, #4f46e5, #7c3aed)" }}>
        <div className="max-w-5xl mx-auto">
          <button onClick={() => navigate("/")} className="text-white/70 hover:text-white text-sm mb-4 flex items-center gap-1">← Home</button>
          <h1 className="text-3xl font-black text-white">🛡️ Admin Panel</h1>
          <p className="text-purple-200 mt-1">Testzy — Question Manager & Settings</p>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-5xl mx-auto px-4 flex gap-1 overflow-x-auto py-2">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as any)}
              className={`px-4 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all flex-shrink-0 ${tab === t.id ? "text-white shadow" : "text-gray-500 hover:bg-gray-100"}`}
              style={tab === t.id ? { background: "linear-gradient(135deg, #4f46e5, #7c3aed)" } : {}}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">

        {/* ══════ UPLOAD TAB ══════ */}
        {tab === "upload" && (
          <div className="max-w-2xl">
            <h2 className="font-black text-[#1a3a6b] text-xl mb-1">PDF / TXT Upload करें</h2>
            <p className="text-gray-500 text-sm mb-5">कोई भी format की PDF upload करें — questions automatically detect होंगे।</p>

            {/* File Drop Zone — FIRST */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-4">
              <label className="block text-sm font-bold text-gray-700 mb-3">📂 File Choose करें (PDF या TXT)</label>
              <div
                className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${dragOver ? "border-purple-500 bg-purple-50" : uploadFile ? "border-green-400 bg-green-50" : "border-gray-300 hover:border-purple-400"}`}
                onClick={() => fileRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleFileDrop}
              >
                <div className="text-4xl mb-2">{uploadFile ? "✅" : "📄"}</div>
                {uploadFile ? (
                  <>
                    <p className="font-black text-green-700 text-base">{uploadFile.name}</p>
                    <p className="text-green-600 text-xs mt-1">{(uploadFile.size / 1024).toFixed(0)} KB • Click to change</p>
                  </>
                ) : (
                  <>
                    <p className="text-gray-600 font-semibold">यहाँ drag करें या click करें</p>
                    <p className="text-gray-400 text-xs mt-1">PDF • TXT • Max 20MB • Any Format</p>
                  </>
                )}
              </div>
              <input
                ref={fileRef}
                type="file"
                accept=".pdf,.txt,application/pdf,text/plain"
                className="hidden"
                onChange={(e) => { setUploadFile(e.target.files?.[0] || null); setPreviewData(null); setUploadResult(null); }}
              />
            </div>

            {/* Preview Button */}
            {uploadFile && !previewData && (
              <button
                onClick={handlePreview}
                disabled={previewing}
                className="w-full py-3.5 rounded-2xl font-black text-white text-base mb-4 disabled:opacity-70 transition-all"
                style={{ background: "linear-gradient(135deg, #0ea5e9, #6d28d9)" }}
              >
                {previewing ? "🔍 Parsing हो रहा है..." : "🔍 Preview करें — कितने Questions मिले?"}
              </button>
            )}

            {/* ── PREVIEW RESULT ────────────────────────────────────────────── */}
            {previewData && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-4">
                <div className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 mb-4 font-black text-sm ${previewData.total > 0 ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                  {previewData.total > 0 ? `✅ ${previewData.total} Questions मिले!` : "❌ कोई Question नहीं मिला"}
                </div>

                {previewData.total > 0 ? (
                  <>
                    <p className="text-gray-500 text-xs mb-3">पहले 5 questions का preview (सभी {previewData.total} save होंगे):</p>
                    <div className="space-y-3 mb-4">
                      {previewData.questions.map((q: any, idx: number) => (
                        <div key={idx} className="bg-gray-50 rounded-xl p-3 text-xs border border-gray-200">
                          <p className="font-bold text-gray-800 mb-1.5">Q{idx + 1}. {q.question}</p>
                          <div className="grid grid-cols-2 gap-1 text-gray-600 mb-1">
                            <span className={q.correct_option === 0 ? "text-green-700 font-bold" : ""}>A) {q.option_a}</span>
                            <span className={q.correct_option === 1 ? "text-green-700 font-bold" : ""}>B) {q.option_b}</span>
                            <span className={q.correct_option === 2 ? "text-green-700 font-bold" : ""}>C) {q.option_c}</span>
                            <span className={q.correct_option === 3 ? "text-green-700 font-bold" : ""}>D) {q.option_d}</span>
                          </div>
                          <span className="inline-block bg-green-100 text-green-700 rounded-lg px-2 py-0.5 text-xs font-semibold">
                            ✅ Ans: {["A","B","C","D"][q.correct_option]}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Category & Type Selection */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                      <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1.5">Exam Category</label>
                        <select className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-purple-400"
                          value={uploadCat} onChange={(e) => setUploadCat(e.target.value)}>
                          {categories.map((c) => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1.5">Quiz Type</label>
                        <select className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-purple-400"
                          value={uploadType} onChange={(e) => setUploadType(e.target.value)}>
                          {quizTypes.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
                        </select>
                      </div>
                    </div>

                    {/* Set Number (only for mock type) */}
                    {uploadType === "mock" && (
                      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
                        <label className="block text-xs font-bold text-blue-700 mb-1.5">📦 Mock Set Number</label>
                        <div className="flex items-center gap-3">
                          <input
                            type="number"
                            min={1}
                            max={99}
                            value={uploadSetNumber}
                            onChange={(e) => setUploadSetNumber(Number(e.target.value))}
                            className="w-24 border-2 border-blue-300 rounded-xl px-3 py-2 text-sm font-black text-center focus:outline-none focus:border-blue-500"
                          />
                          <span className="text-xs text-blue-600">इस PDF को Mock {uploadSetNumber} में save किया जाएगा</span>
                        </div>
                      </div>
                    )}

                    {/* Subject (only for practice type) */}
                    {uploadType === "practice" && (
                      <div className="bg-green-50 border border-green-200 rounded-xl p-3 mb-3">
                        <label className="block text-xs font-bold text-green-700 mb-1.5">📚 Subject (Practice के लिए)</label>
                        <input
                          type="text"
                          placeholder="जैसे: गणित, सामान्य ज्ञान, तार्किक क्षमता, अंग्रेजी..."
                          value={uploadSubject}
                          onChange={(e) => setUploadSubject(e.target.value)}
                          className="w-full border-2 border-green-300 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-green-500"
                        />
                        <p className="text-xs text-green-600 mt-1.5">
                          ⚠️ Subject name बिल्कुल वही लिखें जो Practice Test में दिखाना है। खाली छोड़ने पर subject filter में नहीं आएगा।
                        </p>
                        {uploadSubject && (
                          <p className="text-xs font-bold text-green-800 mt-1">
                            ✅ यह questions "{uploadSubject}" subject में save होंगे
                          </p>
                        )}
                      </div>
                    )}

                    <button
                      onClick={handleUpload}
                      disabled={uploading}
                      className="w-full py-4 rounded-2xl font-black text-white text-lg disabled:opacity-70"
                      style={{ background: "linear-gradient(135deg, #4f46e5, #7c3aed)" }}
                    >
                      {uploading ? "⏳ Save हो रहा है..." : `💾 सभी ${previewData.total} Questions Save करें`}
                    </button>
                  </>
                ) : (
                  <div className="text-xs text-gray-500">
                    <p className="font-bold mb-1">PDF का raw text (पहले 500 chars):</p>
                    <pre className="bg-gray-100 rounded-lg p-3 whitespace-pre-wrap overflow-auto max-h-40">{previewData.rawSnippet}</pre>
                    <p className="mt-2 text-red-600">नीचे दिए format में PDF बनाकर दोबारा try करें।</p>
                  </div>
                )}

                <button onClick={() => { setPreviewData(null); setUploadFile(null); if (fileRef.current) fileRef.current.value = ""; }}
                  className="mt-3 text-gray-500 text-xs underline w-full text-center">
                  ✕ Cancel — दूसरी file choose करें
                </button>
              </div>
            )}

            {/* Result after save */}
            {uploadResult && (
              <div className={`rounded-2xl p-4 text-sm font-semibold mb-4 ${uploadResult.success ? "bg-green-50 border border-green-300 text-green-800" : "bg-red-50 border border-red-300 text-red-800"}`}>
                {uploadResult.success ? (
                  <div>
                    <p className="text-lg font-black mb-1">🎉 Upload सफल!</p>
                    <p>{uploadResult.inserted} questions database में add हो गए।</p>
                    <button onClick={() => setTab("questions")} className="mt-3 bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold">
                      Questions देखें →
                    </button>
                  </div>
                ) : (
                  <div>
                    <p>❌ Error: {uploadResult.error}</p>
                    {uploadResult.hint && <p className="mt-1 text-xs opacity-80">{uploadResult.hint}</p>}
                  </div>
                )}
              </div>
            )}

            {/* Format Guide — Collapsible */}
            <details className="bg-gray-50 rounded-2xl border border-gray-200 p-4 text-xs">
              <summary className="font-bold text-gray-700 cursor-pointer mb-1">📝 Supported Formats — क्लिक करें देखने के लिए</summary>
              <div className="mt-3 space-y-3">
                <div>
                  <p className="font-semibold text-gray-600 mb-1">Format 1 — Standard (सबसे आम)</p>
                  <pre className="bg-white p-2.5 rounded-xl border font-mono leading-5 text-gray-600">{`1. Question text?
A) Option 1    B) Option 2
C) Option 3    D) Option 4
Ans: B`}</pre>
                </div>
                <div>
                  <p className="font-semibold text-gray-600 mb-1">Format 2 — Brackets with explanation</p>
                  <pre className="bg-white p-2.5 rounded-xl border font-mono leading-5 text-gray-600">{`Q1. प्रश्न यहाँ लिखें?
(A) विकल्प 1
(B) विकल्प 2
(C) विकल्प 3
(D) विकल्प 4
Answer: C
Explanation: व्याख्या यहाँ`}</pre>
                </div>
                <div>
                  <p className="font-semibold text-gray-600 mb-1">Format 3 — Numbered Options</p>
                  <pre className="bg-white p-2.5 rounded-xl border font-mono leading-5 text-gray-600">{`1. Question?
1) Option A    2) Option B
3) Option C    4) Option D
Correct: 3`}</pre>
                </div>
                <div>
                  <p className="font-semibold text-gray-600 mb-1">Format 4 — Compact (single line)</p>
                  <pre className="bg-white p-2.5 rounded-xl border font-mono leading-5 text-gray-600">{`Q1. Question? A) Opt1 B) Opt2 C) Opt3 D) Opt4 Ans: D`}</pre>
                </div>
              </div>
            </details>
          </div>
        )}

        {/* ══════ QUESTIONS LIST TAB ══════ */}
        {tab === "questions" && (
          <div>
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <h2 className="font-black text-[#1a3a6b] text-xl">Uploaded Questions</h2>
              <div className="ml-auto flex gap-2 flex-wrap">
                <select value={filterCat} onChange={e => { setFilterCat(e.target.value); setSelectedIds(new Set()); }}
                  className="border-2 border-gray-200 rounded-xl px-3 py-2 text-sm font-semibold text-gray-700">
                  <option value="all">सभी Categories</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                </select>
                <select value={filterType} onChange={e => { setFilterType(e.target.value); setSelectedIds(new Set()); }}
                  className="border-2 border-gray-200 rounded-xl px-3 py-2 text-sm font-semibold text-gray-700">
                  <option value="all">सभी Types</option>
                  {quizTypes.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                </select>
              </div>
            </div>

            {/* Bulk Delete Bar */}
            {dbQuestions.length > 0 && (
              <div className="flex items-center gap-3 bg-white rounded-2xl border border-gray-200 px-4 py-2.5 mb-4 shadow-sm">
                <input
                  type="checkbox"
                  className="w-4 h-4 accent-[#1a3a6b] cursor-pointer"
                  checked={selectedIds.size === dbQuestions.length && dbQuestions.length > 0}
                  onChange={toggleSelectAll}
                />
                <span className="text-sm font-semibold text-gray-700">
                  {selectedIds.size > 0 ? `${selectedIds.size} selected` : "Select All"}
                </span>
                {selectedIds.size > 0 && (
                  <button
                    onClick={bulkDelete}
                    disabled={bulkDeleting}
                    className="ml-auto bg-red-500 hover:bg-red-600 text-white text-sm font-black px-4 py-1.5 rounded-xl disabled:opacity-60 transition-all"
                  >
                    {bulkDeleting ? "⏳ Deleting..." : `🗑️ Delete ${selectedIds.size} Selected`}
                  </button>
                )}
              </div>
            )}

            {dbQuestions.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
                <div className="text-5xl mb-3">📭</div>
                <p className="text-gray-500 font-semibold">इस filter में कोई question नहीं मिला।</p>
                <button onClick={() => setTab("upload")} className="mt-4 btn-primary px-5 py-2 rounded-xl text-sm">
                  PDF Upload करें
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-gray-500 text-sm">{dbQuestions.length} questions मिले</p>
                {dbQuestions.map((q, idx) => {
                  const cat = categories.find(c => c.id === q.category);
                  const qType = quizTypes.find(t => t.id === q.quiz_type);
                  const checked = selectedIds.has(q.id);
                  return (
                    <div key={q.id} className={`bg-white rounded-2xl border p-4 shadow-sm transition-all ${checked ? "border-blue-400 bg-blue-50" : "border-gray-100"}`}>
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <input type="checkbox" className="w-4 h-4 accent-[#1a3a6b] cursor-pointer mt-0.5 flex-shrink-0"
                            checked={checked} onChange={() => toggleSelect(q.id)} />
                          <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: cat?.bgColor, color: cat?.color }}>
                            {cat?.icon} {cat?.name}
                          </span>
                          <span className="text-xs bg-purple-100 text-purple-700 font-bold px-2 py-0.5 rounded-full">
                            {qType?.label}
                          </span>
                        </div>
                        <button onClick={() => deleteQuestion(q.id)} className="text-red-400 hover:text-red-600 text-xs font-bold flex-shrink-0">
                          🗑️
                        </button>
                      </div>
                      <p className="text-gray-800 font-semibold text-sm mb-2">
                        <span className="text-gray-400 font-bold mr-1">Q{idx + 1}.</span> {q.question}
                      </p>
                      <div className="grid grid-cols-2 gap-1 text-xs text-gray-600">
                        {[q.option_a, q.option_b, q.option_c, q.option_d].map((opt, i) => (
                          <span key={i} className={`px-2 py-1 rounded-lg ${i === q.correct_option ? "bg-green-100 text-green-700 font-bold" : "bg-gray-50"}`}>
                            {["A","B","C","D"][i]}) {opt}
                          </span>
                        ))}
                      </div>
                      {q.explanation && (
                        <p className="text-xs text-blue-600 mt-2">💡 {q.explanation}</p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ══════ MEGA QUIZ TAB ══════ */}
        {tab === "mega" && (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <h2 className="font-black text-[#1a3a6b] text-xl">🏆 Mega Quiz Management</h2>
              {megaSettingsMsg && <span className="ml-auto text-sm font-bold text-green-600">{megaSettingsMsg}</span>}
            </div>

            {/* ── Editable Settings Card ── */}
            <div className="bg-white rounded-2xl border-2 border-yellow-200 shadow-sm p-6 mb-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-black text-yellow-800 text-base">⚙️ Quiz Settings (Edit करें)</h3>
                <button
                  onClick={saveMegaSettings}
                  disabled={savingMegaSettings}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-black px-5 py-2 rounded-xl disabled:opacity-60 transition-all"
                >
                  {savingMegaSettings ? "⏳ Saving..." : "💾 Save Settings"}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">📅 Quiz Date</label>
                  <input
                    type="date"
                    value={megaSettings.quiz_date}
                    onChange={e => setMegaSettings(s => ({ ...s, quiz_date: e.target.value }))}
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-yellow-400"
                  />
                  <p className="text-xs text-gray-400 mt-1">यह date Home page पर show होगी</p>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">🏷️ Quiz Title</label>
                  <input
                    type="text"
                    value={megaSettings.title}
                    onChange={e => setMegaSettings(s => ({ ...s, title: e.target.value }))}
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-yellow-400"
                    placeholder="Weekly Mega Quiz"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">🕗 Start Time</label>
                  <input
                    type="time"
                    value={megaSettings.start_time}
                    onChange={e => setMegaSettings(s => ({ ...s, start_time: e.target.value }))}
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-yellow-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">🕗 End Time</label>
                  <input
                    type="time"
                    value={megaSettings.end_time}
                    onChange={e => setMegaSettings(s => ({ ...s, end_time: e.target.value }))}
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-yellow-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1.5">💰 Entry Fee (₹)</label>
                  <input
                    type="number"
                    min={0}
                    value={megaSettings.entry_fee}
                    onChange={e => setMegaSettings(s => ({ ...s, entry_fee: Number(e.target.value) }))}
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-yellow-400"
                  />
                </div>
                <div className="flex items-end">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={megaSettings.is_active}
                      onChange={e => setMegaSettings(s => ({ ...s, is_active: e.target.checked }))}
                      className="w-5 h-5 accent-yellow-500 cursor-pointer"
                    />
                    <div>
                      <div className="text-sm font-black text-gray-700">Quiz Active है?</div>
                      <div className="text-xs text-gray-400">Uncheck करने पर Home page पर Upcoming दिखेगा</div>
                    </div>
                  </label>
                </div>
              </div>

              <div className="mt-4 bg-yellow-50 border border-yellow-100 rounded-xl p-3 text-xs text-yellow-800">
                💡 Prize amounts बदलने के लिए <button onClick={() => setTab("prizes")} className="underline font-black">Prizes Tab</button> में जाएं।
              </div>
            </div>

            {/* Mega Quiz Questions */}
            <div className="flex items-center justify-between mb-3">
              <p className="font-bold text-gray-700">{megaQs.length} Mega Quiz Questions Uploaded</p>
              <button onClick={() => { setTab("upload"); setUploadType("mega_quiz"); }}
                className="bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-black px-4 py-2 rounded-xl transition-all">
                + Upload Mega Quiz PDF
              </button>
            </div>

            {megaQs.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                <div className="text-5xl mb-3">🏆</div>
                <p className="text-gray-500 font-semibold mb-1">अभी कोई Mega Quiz question नहीं है</p>
                <p className="text-gray-400 text-sm">90 questions का PDF upload करें (quiz_type = mega_quiz)</p>
                <button onClick={() => { setTab("upload"); setUploadType("mega_quiz"); }}
                  className="mt-4 bg-yellow-500 text-white font-black px-5 py-2 rounded-xl text-sm">
                  PDF Upload करें
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {megaQs.map((q, idx) => (
                  <div key={q.id} className="bg-white rounded-2xl border border-yellow-100 p-4 shadow-sm">
                    <p className="text-gray-800 font-semibold text-sm mb-2">
                      <span className="text-yellow-600 font-black mr-1">Q{idx + 1}.</span> {q.question}
                    </p>
                    <div className="grid grid-cols-2 gap-1 text-xs text-gray-600">
                      {[q.option_a, q.option_b, q.option_c, q.option_d].map((opt, i) => (
                        <span key={i} className={`px-2 py-1 rounded-lg ${i === q.correct_option ? "bg-green-100 text-green-700 font-bold" : "bg-gray-50"}`}>
                          {["A","B","C","D"][i]}) {opt}
                        </span>
                      ))}
                    </div>
                    <div className="flex justify-end mt-2">
                      <button onClick={() => deleteQuestion(q.id)} className="text-red-400 hover:text-red-600 text-xs font-bold">🗑️ Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══════ PRIZES TAB ══════ */}
        {tab === "prizes" && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-black text-[#1a3a6b] text-xl">Prize Management</h2>
              <div className="flex items-center gap-3">
                {saveMsg && <span className="text-sm font-semibold text-gray-600">{saveMsg}</span>}
                <button onClick={savePrizes} className="bg-gradient-to-r from-purple-600 to-purple-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow">
                  💾 Save Changes
                </button>
              </div>
            </div>
            <div className="space-y-3">
              {editing.map((prize, idx) => (
                <div key={prize.id} className={`bg-white rounded-2xl p-5 border-2 shadow-sm ${prize.rank_position === 1 ? "border-yellow-300" : prize.rank_position === 2 ? "border-gray-300" : prize.rank_position === 3 ? "border-orange-300" : "border-gray-100"}`}>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Title (Rank #{prize.rank_position})</label>
                      <input type="text" value={prize.title} onChange={(e) => updateEditing(idx, "title", e.target.value)} className="w-full border-2 border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-purple-400" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Description</label>
                      <input type="text" value={prize.description} onChange={(e) => updateEditing(idx, "description", e.target.value)} className="w-full border-2 border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-purple-400" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Amount / Reward</label>
                      <input type="text" value={prize.amount} onChange={(e) => updateEditing(idx, "amount", e.target.value)} className="w-full border-2 border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-purple-400" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══════ USERS TAB ══════ */}
        {tab === "users" && (
          <div>
            <h2 className="font-black text-[#1a3a6b] text-xl mb-4">User Management</h2>
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      {["#","Name","Email","Points","Role","Joined"].map(h => (
                        <th key={h} className="text-left px-5 py-3.5 font-bold text-gray-600">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u, i) => (
                      <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-5 py-3.5 text-gray-400 font-semibold">{i + 1}</td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-black" style={{ background: "linear-gradient(135deg, #1a3a6b, #f97316)" }}>
                              {u.name.charAt(0).toUpperCase()}
                            </div>
                            <span className="font-semibold text-gray-800">{u.name}</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-gray-500">{u.email}</td>
                        <td className="px-5 py-3.5"><span className="font-black text-[#1a3a6b]">{u.totalPoints.toFixed(1)}</span></td>
                        <td className="px-5 py-3.5">
                          {u.is_admin ? <span className="bg-purple-100 text-purple-700 px-2.5 py-0.5 rounded-full text-xs font-bold">Admin</span> : <span className="bg-blue-100 text-blue-700 px-2.5 py-0.5 rounded-full text-xs font-bold">Student</span>}
                        </td>
                        <td className="px-5 py-3.5 text-gray-400 text-xs">{new Date(u.created_at).toLocaleDateString("en-IN")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ══════ REVIEWS TAB ══════ */}
        {tab === "reviews" && (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <h2 className="font-black text-[#1a3a6b] text-xl">⭐ User Reviews</h2>
              {reviewMsg && <span className="text-green-600 text-sm font-bold ml-auto">{reviewMsg}</span>}
            </div>
            {adminReviews.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                <div className="text-5xl mb-3">⭐</div>
                <p className="text-gray-500 font-semibold">अभी कोई review नहीं है</p>
              </div>
            ) : (
              <div className="space-y-4">
                {adminReviews.map(r => (
                  <div key={r.id} className={`bg-white rounded-2xl border-2 p-5 shadow-sm ${r.approved ? "border-green-200" : "border-orange-200"}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="font-black text-gray-800">{r.user_name}</div>
                        <div className="text-xs text-gray-400">{r.email} • {new Date(r.created_at).toLocaleDateString("en-IN")}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex">{[1,2,3,4,5].map(s => <span key={s} className="text-sm">{s <= r.rating ? "⭐" : "☆"}</span>)}</div>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${r.approved ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                          {r.approved ? "✅ Approved" : "⏳ Pending"}
                        </span>
                      </div>
                    </div>
                    <p className="text-gray-700 text-sm mb-3">"{r.comment}"</p>
                    <div className="flex gap-2">
                      {!r.approved ? (
                        <button onClick={() => toggleReviewApproval(r.id, true)}
                          className="bg-green-500 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-green-600">
                          ✅ Approve
                        </button>
                      ) : (
                        <button onClick={() => toggleReviewApproval(r.id, false)}
                          className="bg-gray-200 text-gray-700 text-xs font-bold px-4 py-2 rounded-xl hover:bg-gray-300">
                          ❌ Reject
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══════ HELP QUERIES TAB ══════ */}
        {tab === "help" && (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <h2 className="font-black text-[#1a3a6b] text-xl">🛟 Help Queries</h2>
              {helpMsg && <span className="text-green-600 text-sm font-bold ml-auto">{helpMsg}</span>}
              <span className="ml-auto bg-orange-100 text-orange-700 text-xs font-bold px-2.5 py-1 rounded-full">
                {helpQueries.filter(q => q.status === "open").length} Open
              </span>
            </div>
            {helpQueries.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                <div className="text-5xl mb-3">📬</div>
                <p className="text-gray-500 font-semibold">अभी कोई query नहीं है</p>
              </div>
            ) : (
              <div className="space-y-4">
                {helpQueries.map(q => (
                  <div key={q.id} className={`bg-white rounded-2xl border-2 p-5 shadow-sm ${q.status === "open" ? "border-orange-200" : "border-green-200"}`}>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="font-black text-gray-800 flex items-center gap-2">
                          {q.name}
                          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${q.status === "open" ? "bg-orange-100 text-orange-700" : "bg-green-100 text-green-700"}`}>
                            {q.status === "open" ? "🔴 Open" : "✅ Resolved"}
                          </span>
                        </div>
                        <div className="text-xs text-gray-400">{q.email} • {new Date(q.created_at).toLocaleDateString("en-IN")}</div>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-xl p-3 mb-3">
                      <div className="text-xs font-bold text-purple-700 mb-1">📂 {q.subject}</div>
                      <p className="text-gray-700 text-sm leading-relaxed">{q.message}</p>
                    </div>
                    {q.admin_reply && (
                      <div className="bg-green-50 border border-green-200 rounded-xl p-3 mb-3">
                        <div className="text-xs font-bold text-green-700 mb-1">✅ Admin Reply:</div>
                        <p className="text-green-800 text-sm">{q.admin_reply}</p>
                      </div>
                    )}
                    {q.status === "open" && (
                      <div className="flex gap-2">
                        <textarea
                          value={replyText[q.id] || ""}
                          onChange={e => setReplyText(prev => ({ ...prev, [q.id]: e.target.value }))}
                          rows={2}
                          placeholder="Reply लिखें..."
                          className="flex-1 border-2 border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-[#1a3a6b] resize-none"
                        />
                        <button onClick={() => replyToQuery(q.id)} disabled={!replyText[q.id]?.trim()}
                          className="btn-primary px-4 py-2 rounded-xl text-sm font-bold disabled:opacity-50">
                          Send
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
