import { useState, useRef } from "react";

const GK_CARDS = [
  { q: "भारत का राष्ट्रीय पशु क्या है?", a: "बाघ (Royal Bengal Tiger)", category: "भारत GK", emoji: "🐯" },
  { q: "भारत का सबसे बड़ा राज्य (क्षेत्रफल में) कौन सा है?", a: "राजस्थान", category: "भारत GK", emoji: "🏜️" },
  { q: "भारतीय संविधान में कितने अनुच्छेद हैं?", a: "395 अनुच्छेद (वर्तमान में 448)", category: "संविधान", emoji: "📜" },
  { q: "भारत के प्रथम राष्ट्रपति कौन थे?", a: "डॉ. राजेंद्र प्रसाद", category: "इतिहास", emoji: "🏛️" },
  { q: "विश्व का सबसे बड़ा महासागर कौन सा है?", a: "प्रशांत महासागर (Pacific Ocean)", category: "भूगोल", emoji: "🌊" },
  { q: "भारत में लोकसभा की कुल सीटें कितनी हैं?", a: "545 (543 निर्वाचित + 2 मनोनीत)", category: "संविधान", emoji: "🏛️" },
  { q: "विश्व का सबसे ऊँचा पर्वत कौन सा है?", a: "माउंट एवरेस्ट (8848.86 मीटर)", category: "भूगोल", emoji: "⛰️" },
  { q: "भारत का राष्ट्रीय फूल क्या है?", a: "कमल (Lotus)", category: "भारत GK", emoji: "🪷" },
  { q: "प्रकाश की गति कितनी होती है?", a: "3 × 10⁸ m/s (3 लाख km/s)", category: "विज्ञान", emoji: "💡" },
  { q: "भारत की पहली महिला प्रधानमंत्री कौन थीं?", a: "इंदिरा गांधी", category: "इतिहास", emoji: "👩" },
  { q: "Human body में कितनी हड्डियाँ होती हैं?", a: "206 हड्डियाँ", category: "विज्ञान", emoji: "🦴" },
  { q: "भारत का सबसे लंबा नदी कौन सी है?", a: "गंगा (2525 km)", category: "भूगोल", emoji: "🌊" },
  { q: "1 km में कितने मीटर होते हैं?", a: "1000 मीटर", category: "Math", emoji: "📏" },
  { q: "भारत का राष्ट्रीय खेल क्या है?", a: "हॉकी", category: "भारत GK", emoji: "🏑" },
  { q: "भारत की राजधानी क्या है?", a: "नई दिल्ली (New Delhi)", category: "भारत GK", emoji: "🏙️" },
  { q: "DNA का पूरा नाम क्या है?", a: "Deoxyribonucleic Acid", category: "विज्ञान", emoji: "🧬" },
  { q: "भारत में कितने राज्य हैं?", a: "28 राज्य और 8 केंद्र शासित प्रदेश", category: "भारत GK", emoji: "🗺️" },
  { q: "RBI का पूरा नाम क्या है?", a: "Reserve Bank of India (भारतीय रिजर्व बैंक)", category: "Banking", emoji: "🏦" },
  { q: "पृथ्वी सूर्य की परिक्रमा कितने दिन में करती है?", a: "365 दिन 6 घंटे (365.25 days)", category: "विज्ञान", emoji: "🌍" },
  { q: "भारत का सबसे बड़ा बंदरगाह कौन सा है?", a: "मुंबई बंदरगाह (Jawaharlal Nehru Port)", category: "भूगोल", emoji: "⚓" },
  { q: "SSC CGL में कितने tier होते हैं?", a: "4 Tier (Tier I, II, III, IV)", category: "Exam Info", emoji: "📝" },
  { q: "भारत का राष्ट्रीय वृक्ष क्या है?", a: "बरगद (Banyan Tree)", category: "भारत GK", emoji: "🌳" },
  { q: "विटामिन C का रासायनिक नाम क्या है?", a: "Ascorbic Acid (एस्कॉर्बिक एसिड)", category: "विज्ञान", emoji: "🍊" },
  { q: "भारत का सबसे पुराना हाई कोर्ट कौन सा है?", a: "कलकत्ता हाई कोर्ट (1862)", category: "संविधान", emoji: "⚖️" },
  { q: "CPU का पूरा नाम क्या है?", a: "Central Processing Unit", category: "Computer", emoji: "💻" },
  { q: "भारत में पंचायती राज की स्थापना किस अनुच्छेद में है?", a: "अनुच्छेद 243 (73वां संशोधन 1992)", category: "संविधान", emoji: "🏘️" },
  { q: "परमाणु का केंद्र क्या कहलाता है?", a: "नाभिक (Nucleus)", category: "विज्ञान", emoji: "⚛️" },
  { q: "भारत में Railway की शुरुआत कब हुई?", a: "16 अप्रैल 1853 (Mumbai-Thane)", category: "इतिहास", emoji: "🚂" },
  { q: "INR का symbol क्या है?", a: "₹ (Rupee Sign, 2010 में अपनाया)", category: "Banking", emoji: "💰" },
  { q: "Olympic Games कितने वर्षों में एक बार होते हैं?", a: "4 वर्षों में एक बार", category: "Sports", emoji: "🏅" },
];

const CATEGORIES = ["All", ...Array.from(new Set(GK_CARDS.map(c => c.category)))];

export default function Flashcards() {
  const [cardIndex, setCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<Set<number>>(new Set());
  const [notKnown, setNotKnown] = useState<Set<number>>(new Set());
  const [activeCategory, setActiveCategory] = useState("All");
  const [showSummary, setShowSummary] = useState(false);
  const [dragStart, setDragStart] = useState<number | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const filtered = GK_CARDS.filter((c, i) =>
    activeCategory === "All" || c.category === activeCategory
  ).map((c, i) => ({ ...c, origIdx: GK_CARDS.indexOf(c) }));

  const current = filtered[cardIndex % filtered.length];
  const progress = ((known.size + notKnown.size) / filtered.length) * 100;

  function handleKnow() {
    setKnown(k => new Set([...k, cardIndex]));
    setFlipped(false);
    if (cardIndex >= filtered.length - 1) setShowSummary(true);
    else setCardIndex(i => i + 1);
  }

  function handleNotKnow() {
    setNotKnown(k => new Set([...k, cardIndex]));
    setFlipped(false);
    if (cardIndex >= filtered.length - 1) setShowSummary(true);
    else setCardIndex(i => i + 1);
  }

  function restart() {
    setCardIndex(0); setFlipped(false); setKnown(new Set()); setNotKnown(new Set()); setShowSummary(false);
  }

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #fef3c7 0%, #fde68a 50%, #fbbf24 100%)" }}>
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-8 text-center">
        <div className="text-4xl mb-2">🃏</div>
        <h1 className="text-2xl font-black mb-1">GK Flashcards</h1>
        <p className="text-amber-100 text-sm">Swipe करके GK याद करो — जाने = ✅ नहीं जाने = 🔄</p>
      </div>

      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-5 hide-scrollbar">
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => { setActiveCategory(cat); setCardIndex(0); setFlipped(false); }}
              className="shrink-0 text-xs px-4 py-2 rounded-full font-bold border-2 transition-all"
              style={activeCategory === cat
                ? { background: "#d97706", color: "white", borderColor: "#d97706" }
                : { background: "white", color: "#92400e", borderColor: "#fcd34d" }}>
              {cat}
            </button>
          ))}
        </div>

        {/* Progress */}
        <div className="bg-white rounded-2xl px-4 py-3 mb-5 shadow-md flex items-center gap-3">
          <div className="flex-1">
            <div className="flex justify-between text-xs font-bold text-gray-600 mb-1">
              <span>Progress</span>
              <span>{cardIndex + 1} / {filtered.length}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-500"
                style={{ width: `${((cardIndex + 1) / filtered.length) * 100}%` }} />
            </div>
          </div>
          <div className="flex gap-3 text-xs font-black">
            <span className="text-green-600">✅ {known.size}</span>
            <span className="text-red-500">🔄 {notKnown.size}</span>
          </div>
        </div>

        {showSummary ? (
          /* Summary Screen */
          <div className="space-y-5">
            {/* Score Card */}
            <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
              <div className="text-6xl mb-4">🎉</div>
              <h2 className="text-2xl font-black text-gray-900 mb-2">Session Complete!</h2>
              <p className="text-gray-600 mb-6">{filtered.length} cards revise किए</p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-4">
                  <div className="text-3xl font-black text-green-600">{known.size}</div>
                  <div className="text-sm text-green-700 font-semibold">✅ पता था</div>
                </div>
                <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4">
                  <div className="text-3xl font-black text-red-500">{notKnown.size}</div>
                  <div className="text-sm text-red-600 font-semibold">🔄 याद करना है</div>
                </div>
              </div>
              <button onClick={restart}
                className="w-full py-4 rounded-2xl font-black text-white text-base"
                style={{ background: "linear-gradient(135deg, #d97706, #ef4444)" }}>
                🔄 फिर से Practice करें
              </button>
            </div>

            {/* All Q&A Review */}
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
                <span className="text-xl">📋</span>
                <h3 className="font-black text-gray-900 text-base">सभी Cards — Review</h3>
              </div>
              <div className="divide-y divide-gray-50">
                {filtered.map((card, idx) => {
                  const isKnown = known.has(idx);
                  const isNotKnown = notKnown.has(idx);
                  return (
                    <div key={idx} className="px-5 py-4"
                      style={{ background: isKnown ? "#f0fdf4" : isNotKnown ? "#fff1f2" : "#fafafa" }}>
                      <div className="flex items-start gap-3">
                        <span className="text-xl mt-0.5 shrink-0">{card.emoji}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                              style={{ background: isKnown ? "#dcfce7" : isNotKnown ? "#fee2e2" : "#f3f4f6",
                                color: isKnown ? "#15803d" : isNotKnown ? "#dc2626" : "#6b7280" }}>
                              {card.category}
                            </span>
                            <span className="text-sm">{isKnown ? "✅" : isNotKnown ? "🔄" : "⬜"}</span>
                          </div>
                          <p className="text-sm font-bold text-gray-800 mb-1 leading-snug">{card.q}</p>
                          <p className="text-sm text-purple-700 font-semibold leading-snug">
                            <span className="text-gray-400 font-normal">Ans: </span>{card.a}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Restart */}
            <button onClick={restart}
              className="w-full py-4 rounded-2xl font-black text-white text-base shadow-xl"
              style={{ background: "linear-gradient(135deg, #d97706, #ef4444)" }}>
              🔄 फिर से Practice करें
            </button>
          </div>
        ) : current ? (
          <>
            {/* Flashcard */}
            <div ref={cardRef} onClick={() => setFlipped(f => !f)}
              className="cursor-pointer mb-6"
              style={{ perspective: 1000 }}>
              <div className="relative transition-transform duration-500 shadow-2xl rounded-3xl"
                style={{ transformStyle: "preserve-3d", transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)", minHeight: 280 }}>
                {/* Front */}
                <div className="absolute inset-0 bg-white rounded-3xl p-8 flex flex-col items-center justify-center text-center"
                  style={{ backfaceVisibility: "hidden" }}>
                  <div className="text-5xl mb-4">{current.emoji}</div>
                  <span className="inline-block bg-amber-100 text-amber-700 text-xs font-bold px-3 py-1 rounded-full mb-4">{current.category}</span>
                  <h2 className="text-lg font-black text-gray-900 leading-relaxed">{current.q}</h2>
                  <p className="text-xs text-gray-400 mt-6 font-semibold">👆 Tap करके Answer देखें</p>
                </div>
                {/* Back */}
                <div className="absolute inset-0 rounded-3xl p-8 flex flex-col items-center justify-center text-center"
                  style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)", background: "linear-gradient(135deg, #7c3aed, #2563eb)" }}>
                  <div className="text-5xl mb-4">{current.emoji}</div>
                  <span className="inline-block bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full mb-4">{current.category}</span>
                  <p className="text-sm text-white/80 mb-3">Answer:</p>
                  <h2 className="text-xl font-black text-white leading-relaxed">{current.a}</h2>
                  <p className="text-xs text-white/60 mt-4">👆 Tap to flip back</p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4">
              <button onClick={handleNotKnow}
                className="py-4 rounded-2xl font-black text-white text-base shadow-xl flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, #ef4444, #f97316)" }}>
                🔄 याद नहीं
              </button>
              <button onClick={handleKnow}
                className="py-4 rounded-2xl font-black text-white text-base shadow-xl flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, #10b981, #3b82f6)" }}>
                ✅ पता है!
              </button>
            </div>

            <p className="text-center text-xs text-amber-800/60 mt-4 font-semibold">
              पहले card tap करके answer देखो, फिर बताओ पता था या नहीं
            </p>
          </>
        ) : null}
      </div>
    </div>
  );
}
