import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

type Bookmark = {
  id: number;
  question_text: string;
  options: string[];
  correct_answer: string;
  explanation: string;
  subject: string;
  category: string;
  created_at: string;
};

export default function Bookmarks() {
  const { user, setShowAuthModal } = useAuth();
  const [, navigate] = useLocation();
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    fetch("/api/bookmarks", { credentials: "include" })
      .then((r) => r.json())
      .then((d) => setBookmarks(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  }, [user]);

  async function remove(id: number) {
    await fetch(`/api/bookmarks/${id}`, { method: "DELETE", credentials: "include" });
    setBookmarks((prev) => prev.filter((b) => b.id !== id));
  }

  const subjects = ["all", ...Array.from(new Set(bookmarks.map((b) => b.subject).filter(Boolean)))];
  const filtered = filter === "all" ? bookmarks : bookmarks.filter((b) => b.subject === filter);

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8">
          <div className="text-6xl mb-4">🔖</div>
          <h2 className="text-xl font-black text-gray-800 mb-2">Login करें</h2>
          <p className="text-gray-500 text-sm mb-6">Bookmarks देखने के लिए login करना ज़रूरी है</p>
          <button onClick={() => setShowAuthModal(true)}
            className="btn-primary px-8 py-3 rounded-2xl font-black">
            Login / Signup
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 text-white px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-2xl font-black">🔖 मेरे Bookmarks</h1>
          <p className="text-white/80 text-sm mt-1">Save किए गए questions को यहाँ review करें</p>
          <div className="mt-4 bg-white/15 border border-white/20 rounded-2xl p-4 inline-block">
            <span className="text-3xl font-black">{bookmarks.length}</span>
            <span className="text-sm text-white/70 ml-2">Questions Saved</span>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Subject Filter */}
        {subjects.length > 1 && (
          <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
            {subjects.map((s) => (
              <button key={s} onClick={() => setFilter(s)}
                className={`shrink-0 px-4 py-2 rounded-full text-sm font-bold transition-all capitalize ${
                  filter === s ? "text-white shadow-md" : "bg-white text-gray-600 border border-gray-200 hover:border-orange-300"
                }`}
                style={filter === s ? { background: "linear-gradient(135deg, #f97316, #ef4444)" } : {}}>
                {s === "all" ? "📚 सभी" : s}
              </button>
            ))}
          </div>
        )}

        {loading ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-4xl mb-2">⏳</div><p>Loading...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-5xl mb-4">🔖</div>
            <h3 className="font-bold text-gray-600 mb-2">कोई Bookmark नहीं</h3>
            <p className="text-sm mb-6">Quiz करते समय 🔖 बटन से questions save करें</p>
            <button onClick={() => navigate("/practice")}
              className="btn-primary px-6 py-2.5 rounded-2xl font-bold text-sm">
              Practice शुरू करें →
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {filtered.map((bm, idx) => {
              const isOpen = expanded === bm.id;
              const opts = Array.isArray(bm.options) ? bm.options : [];
              return (
                <div key={bm.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all">
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <span className="text-xs bg-orange-100 text-orange-700 px-2.5 py-0.5 rounded-full font-bold capitalize">{bm.subject || "General"}</span>
                          <span className="text-xs text-gray-400">#{idx + 1}</span>
                        </div>
                        <p className="font-bold text-gray-800 text-sm leading-relaxed">{bm.question_text}</p>
                      </div>
                      <button onClick={() => remove(bm.id)} className="text-red-300 hover:text-red-500 text-lg transition-all shrink-0" title="Remove bookmark">🗑️</button>
                    </div>

                    <button onClick={() => setExpanded(isOpen ? null : bm.id)}
                      className="mt-3 text-xs font-bold text-orange-600 hover:text-orange-700 transition-all">
                      {isOpen ? "▲ Hide Answer" : "▼ Show Answer"}
                    </button>

                    {isOpen && (
                      <div className="mt-3 border-t border-gray-100 pt-3">
                        {opts.length > 0 && (
                          <div className="grid grid-cols-2 gap-2 mb-3">
                            {opts.map((opt: string, oi: number) => (
                              <div key={oi} className={`px-3 py-2 rounded-xl text-xs font-semibold border ${
                                opt === bm.correct_answer
                                  ? "bg-green-50 border-green-300 text-green-800"
                                  : "bg-gray-50 border-gray-200 text-gray-600"
                              }`}>
                                {opt === bm.correct_answer && "✅ "}
                                {String.fromCharCode(65 + oi)}. {opt}
                              </div>
                            ))}
                          </div>
                        )}
                        {bm.correct_answer && (
                          <div className="bg-green-50 border border-green-200 rounded-xl px-3 py-2 text-xs mb-2">
                            <span className="font-black text-green-800">✅ सही उत्तर: </span>
                            <span className="text-green-700">{bm.correct_answer}</span>
                          </div>
                        )}
                        {bm.explanation && (
                          <div className="bg-blue-50 border border-blue-100 rounded-xl px-3 py-2 text-xs text-blue-800">
                            💡 {bm.explanation}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
