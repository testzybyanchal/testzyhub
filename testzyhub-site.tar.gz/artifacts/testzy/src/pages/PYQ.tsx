import { useState, useEffect } from "react";

type Question = {
  id: number; exam: string; year: number; subject: string;
  question: string; option_a: string; option_b: string; option_c: string; option_d: string;
  correct_answer: string; explanation?: string; difficulty: string;
};

const SAMPLE_PYQ: Question[] = [
  { id: 1, exam: "SSC CGL", year: 2023, subject: "Math", question: "एक वस्तु ₹400 में खरीदकर ₹500 में बेची गई। Profit% क्या है?", option_a: "20%", option_b: "25%", option_c: "15%", option_d: "30%", correct_answer: "B", explanation: "Profit = 500-400 = 100, Profit% = (100/400)×100 = 25%", difficulty: "easy" },
  { id: 2, exam: "SSC CGL", year: 2023, subject: "GK", question: "भारत का सबसे बड़ा राज्य (क्षेत्रफल में) कौन सा है?", option_a: "मध्यप्रदेश", option_b: "उत्तरप्रदेश", option_c: "राजस्थान", option_d: "महाराष्ट्र", correct_answer: "C", explanation: "राजस्थान भारत का सबसे बड़ा राज्य है — 342,239 km²", difficulty: "easy" },
  { id: 3, exam: "Railway NTPC", year: 2022, subject: "Math", question: "₹5000 पर 2 वर्ष के लिए 10% वार्षिक दर से Simple Interest क्या होगा?", option_a: "₹500", option_b: "₹1000", option_c: "₹1500", option_d: "₹2000", correct_answer: "B", explanation: "SI = PRT/100 = 5000×10×2/100 = ₹1000", difficulty: "easy" },
  { id: 4, exam: "Railway NTPC", year: 2022, subject: "GK", question: "भारत में पहली बार रेलगाड़ी कब चली थी?", option_a: "1853", option_b: "1857", option_c: "1860", option_d: "1848", correct_answer: "A", explanation: "16 अप्रैल 1853 को Mumbai से Thane पहली ट्रेन चली", difficulty: "medium" },
  { id: 5, exam: "SSC CHSL", year: 2023, subject: "Reasoning", question: "ABCD : DCBA :: EFGH : ?", option_a: "HGFE", option_b: "GHFE", option_c: "FGHE", option_d: "HEFG", correct_answer: "A", explanation: "Pattern: Letters reversed — EFGH reversed = HGFE", difficulty: "easy" },
  { id: 6, exam: "UP Police", year: 2024, subject: "GK", question: "उत्तर प्रदेश की राजधानी क्या है?", option_a: "आगरा", option_b: "वाराणसी", option_c: "लखनऊ", option_d: "प्रयागराज", correct_answer: "C", explanation: "लखनऊ उत्तर प्रदेश की राजधानी है", difficulty: "easy" },
  { id: 7, exam: "IBPS PO", year: 2023, subject: "Math", question: "एक ट्रेन 60 km/h की speed से चल रही है। 1 घंटे में कितनी दूरी तय करेगी?", option_a: "30 km", option_b: "60 km", option_c: "90 km", option_d: "120 km", correct_answer: "B", explanation: "Speed = Distance/Time → Distance = 60×1 = 60 km", difficulty: "easy" },
  { id: 8, exam: "SSC CGL", year: 2022, subject: "English", question: "Choose the correct spelling:", option_a: "Accomodation", option_b: "Accommodation", option_c: "Acommodation", option_d: "Accomodattion", correct_answer: "B", explanation: "Accommodation — double c, double m", difficulty: "medium" },
  { id: 9, exam: "Railway Group D", year: 2022, subject: "Science", question: "प्रकाश की गति क्या है?", option_a: "2×10⁸ m/s", option_b: "3×10⁸ m/s", option_c: "4×10⁸ m/s", option_d: "1×10⁸ m/s", correct_answer: "B", explanation: "प्रकाश की गति = 3×10⁸ m/s (3 लाख km/s)", difficulty: "easy" },
  { id: 10, exam: "SBI Clerk", year: 2023, subject: "Math", question: "15% of 400 = ?", option_a: "50", option_b: "55", option_c: "60", option_d: "65", correct_answer: "C", explanation: "15/100 × 400 = 6000/100 = 60", difficulty: "easy" },
];

const EXAMS = ["All", "SSC CGL", "SSC CHSL", "Railway NTPC", "Railway Group D", "UP Police", "IBPS PO", "SBI Clerk"];
const YEARS = ["All", "2024", "2023", "2022", "2021", "2020"];
const SUBJECTS = ["All", "Math", "GK", "Reasoning", "English", "Science", "Hindi"];
const DIFF_COLORS: Record<string, string> = { easy: "#10b981", medium: "#f59e0b", hard: "#ef4444" };

export default function PYQ() {
  const [questions, setQuestions] = useState<Question[]>(SAMPLE_PYQ);
  const [exam, setExam] = useState("All");
  const [year, setYear] = useState("All");
  const [subject, setSubject] = useState("All");
  const [selected, setSelected] = useState<Record<number, string>>({});
  const [revealed, setRevealed] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadQuestions();
  }, [exam, year, subject]);

  async function loadQuestions() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (exam !== "All") params.set("exam", exam);
      if (year !== "All") params.set("year", year);
      if (subject !== "All") params.set("subject", subject);
      const res = await fetch(`/api/pyq?${params}&limit=30`, { credentials: "include" });
      if (res.ok) {
        const data = await res.json();
        if (data.papers?.length) setQuestions(data.papers);
        else setQuestions(SAMPLE_PYQ.filter(q =>
          (exam === "All" || q.exam === exam) &&
          (year === "All" || q.year === parseInt(year)) &&
          (subject === "All" || q.subject === subject)
        ));
      }
    } catch { }
    setLoading(false);
  }

  const score = Object.entries(selected).filter(([id, ans]) => {
    const q = questions.find(q => q.id === parseInt(id));
    return q && ans === q.correct_answer;
  }).length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-700 text-white px-4 py-8 text-center">
        <div className="text-4xl mb-2">📋</div>
        <h1 className="text-2xl font-black mb-1">Previous Year Papers</h1>
        <p className="text-blue-200 text-sm">Real exam questions — year & subject filter करके practice करो</p>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Filters */}
        <div className="bg-white rounded-2xl shadow-md p-5 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-bold text-gray-600 mb-1.5 block">📚 Exam</label>
              <select value={exam} onChange={e => setExam(e.target.value)}
                className="w-full border-2 border-gray-200 rounded-xl px-3 py-2 text-sm font-semibold focus:outline-none focus:border-blue-400">
                {EXAMS.map(e => <option key={e}>{e}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 mb-1.5 block">📅 Year</label>
              <select value={year} onChange={e => setYear(e.target.value)}
                className="w-full border-2 border-gray-200 rounded-xl px-3 py-2 text-sm font-semibold focus:outline-none focus:border-blue-400">
                {YEARS.map(y => <option key={y}>{y}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 mb-1.5 block">🎯 Subject</label>
              <select value={subject} onChange={e => setSubject(e.target.value)}
                className="w-full border-2 border-gray-200 rounded-xl px-3 py-2 text-sm font-semibold focus:outline-none focus:border-blue-400">
                {SUBJECTS.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* Score Strip */}
        {Object.keys(selected).length > 0 && (
          <div className="bg-blue-600 text-white rounded-2xl px-5 py-3 mb-5 flex items-center justify-between">
            <span className="font-bold text-sm">📊 Score: {score}/{Object.keys(selected).length}</span>
            <span className="text-blue-200 text-xs">{Math.round((score / Object.keys(selected).length) * 100)}% Accuracy</span>
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin text-4xl mb-3">⏳</div>
            <p className="text-gray-500 font-semibold">Questions load हो रहे हैं...</p>
          </div>
        ) : (
          <div className="space-y-5">
            <p className="text-sm text-gray-500 font-semibold">{questions.length} questions found</p>
            {questions.map((q, idx) => {
              const userAns = selected[q.id];
              const isRevealed = revealed.has(q.id);
              return (
                <div key={q.id} className="bg-white rounded-2xl shadow-md overflow-hidden">
                  {/* Question Header */}
                  <div className="px-5 pt-5 pb-3">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs bg-blue-100 text-blue-700 font-bold px-3 py-1 rounded-full">{q.exam}</span>
                      <span className="text-xs bg-gray-100 text-gray-600 font-bold px-2 py-1 rounded-full">{q.year}</span>
                      <span className="text-xs bg-purple-100 text-purple-700 font-bold px-2 py-1 rounded-full">{q.subject}</span>
                      <span className="text-xs font-bold px-2 py-1 rounded-full text-white ml-auto"
                        style={{ background: DIFF_COLORS[q.difficulty] || "#94a3b8" }}>{q.difficulty}</span>
                    </div>
                    <p className="font-semibold text-gray-900 text-sm leading-relaxed">
                      <span className="text-blue-600 font-black mr-2">Q{idx + 1}.</span>{q.question}
                    </p>
                  </div>

                  {/* Options */}
                  <div className="px-5 pb-4 grid grid-cols-1 gap-2">
                    {(["A", "B", "C", "D"] as const).map(opt => {
                      const optText = q[`option_${opt.toLowerCase()}` as keyof Question] as string;
                      const isSelected = userAns === opt;
                      const isCorrect = q.correct_answer === opt;
                      let bg = "bg-gray-50 border-gray-200 text-gray-700";
                      if (isRevealed) {
                        if (isCorrect) bg = "bg-green-50 border-green-400 text-green-800";
                        else if (isSelected) bg = "bg-red-50 border-red-400 text-red-700";
                      } else if (isSelected) {
                        bg = "bg-blue-50 border-blue-400 text-blue-800";
                      }
                      return (
                        <button key={opt}
                          onClick={() => !isRevealed && setSelected(s => ({ ...s, [q.id]: opt }))}
                          className={`w-full text-left px-4 py-2.5 rounded-xl border-2 text-sm font-semibold transition-all ${bg}`}>
                          <span className="font-black mr-2">{opt}.</span>{optText}
                          {isRevealed && isCorrect && " ✅"}
                          {isRevealed && isSelected && !isCorrect && " ❌"}
                        </button>
                      );
                    })}
                  </div>

                  {/* Actions */}
                  <div className="px-5 pb-5 flex gap-2">
                    {!isRevealed && (
                      <button onClick={() => setRevealed(r => new Set([...r, q.id]))}
                        className="text-xs bg-blue-600 text-white font-bold px-4 py-2 rounded-xl hover:bg-blue-700 transition-all">
                        ✅ Answer देखें
                      </button>
                    )}
                    {isRevealed && q.explanation && (
                      <div className="w-full bg-yellow-50 border border-yellow-200 rounded-xl px-4 py-3">
                        <p className="text-xs font-bold text-yellow-800 mb-1">💡 Explanation:</p>
                        <p className="text-xs text-yellow-700">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
