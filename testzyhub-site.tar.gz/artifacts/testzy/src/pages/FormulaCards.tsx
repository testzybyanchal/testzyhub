import { useState } from "react";

const FORMULAS = [
  // Math
  { topic: "Simple Interest", formula: "SI = (P × R × T) / 100", detail: "P = Principal, R = Rate%, T = Time(years)", trick: "PRT/100 याद करो — 'PaRTy 100'", category: "Math", color: "#2563eb" },
  { topic: "Compound Interest", formula: "CI = P[(1 + R/100)ⁿ - 1]", detail: "n = number of years", trick: "CI > SI always (jab interest compound ho)", category: "Math", color: "#2563eb" },
  { topic: "Profit & Loss", formula: "Profit% = (Profit/CP) × 100\nSP = CP × (100+P%)/100", detail: "CP = Cost Price, SP = Selling Price", trick: "अगर SP > CP → Profit; SP < CP → Loss", category: "Math", color: "#2563eb" },
  { topic: "Speed Distance Time", formula: "Speed = Distance / Time\nD = S × T, T = D/S", detail: "Units: km/h or m/s (×5/18 to convert)", trick: "SDT triangle — ऊपर D, नीचे S×T", category: "Math", color: "#2563eb" },
  { topic: "Percentage", formula: "% = (Value/Total) × 100\nValue = (Total × %)/100", detail: "Percentage change = (Change/Original)×100", trick: "x% of y = y% of x (shortcut!)", category: "Math", color: "#2563eb" },
  { topic: "Average", formula: "Average = Sum of items / Number of items", detail: "Sum = Avg × Count", trick: "Avg बदले तो: New sum = New avg × New count", category: "Math", color: "#2563eb" },
  { topic: "Ratio & Proportion", formula: "a:b :: c:d → ad = bc (cross multiply)", detail: "Product of means = Product of extremes", trick: "Means = बीच वाले, Extremes = किनारे वाले", category: "Math", color: "#2563eb" },
  { topic: "Area of Triangle", formula: "Area = ½ × base × height\nHeron's: √[s(s-a)(s-b)(s-c)]", detail: "s = (a+b+c)/2 (semi-perimeter)", trick: "Right triangle: ½ × two legs", category: "Math", color: "#2563eb" },
  { topic: "Quadratic Formula", formula: "x = [-b ± √(b²-4ac)] / 2a", detail: "For ax² + bx + c = 0", trick: "Discriminant b²-4ac > 0 → real roots", category: "Math", color: "#2563eb" },
  { topic: "Train Problems", formula: "Time = (L1+L2)/Relative Speed\nSame dir: S1-S2, Opposite: S1+S2", detail: "L = length of train", trick: "Platform cross: (Train + Platform length) / Speed", category: "Math", color: "#2563eb" },
  // Reasoning
  { topic: "Number Series", formula: "Difference Pattern: D1, D2, D3...\nRatio Pattern: ×2, ×3...", detail: "Look for AP, GP, or alternating patterns", trick: "Pehle consecutive differences dekho", category: "Reasoning", color: "#7c3aed" },
  { topic: "Blood Relations", formula: "Father's brother = Uncle\nMother's sister = Aunt\nSon's wife = Daughter-in-law", detail: "Draw family tree for complex problems", trick: "Symbol use karo: M=Male, F=Female, +=Married", category: "Reasoning", color: "#7c3aed" },
  { topic: "Direction & Distance", formula: "N↑ S↓ E→ W←\nNE=45°, NW=135°", detail: "Final distance = √(x² + y²) by Pythagoras", trick: "Always start from initial point, draw diagram", category: "Reasoning", color: "#7c3aed" },
  { topic: "Coding-Decoding", formula: "Alphabet position: A=1, B=2...Z=26\nReverse: A=26, Z=1", detail: "Shift by fixed number (Caesar cipher type)", trick: "EJOT = 5,10,15,20 (multiples of 5)", category: "Reasoning", color: "#7c3aed" },
  // English
  { topic: "Tenses Overview", formula: "Present: V1/V1+s/is+V1+ing/has+V3\nPast: V2/was+V1+ing/had+V3", detail: "12 tenses total: 4 present + 4 past + 4 future", trick: "Has/have = Present Perfect; Had = Past Perfect", category: "English", color: "#059669" },
  { topic: "Active/Passive Voice", formula: "Active: Subject + V + Object\nPassive: Object + is/was/be + V3 + by + Subject", detail: "Passive always uses 3rd form of verb", trick: "'By' keyword = Passive voice likely hai", category: "English", color: "#059669" },
  { topic: "Subject-Verb Agreement", formula: "Singular subject → singular verb (adds -s)\nPlural subject → plural verb (no -s)", detail: "Either/Neither/Each/Every → singular verb", trick: "Neither A nor B → B ke gender pe depend karo", category: "English", color: "#059669" },
  // Science
  { topic: "Newton's Laws", formula: "1st: F=0 → no change in motion\n2nd: F = ma\n3rd: Every action = equal opposite reaction", detail: "m = mass (kg), a = acceleration (m/s²)", trick: "1st=Inertia, 2nd=Force, 3rd=Reaction", category: "Science", color: "#dc2626" },
  { topic: "Ohm's Law", formula: "V = I × R\nI = V/R, R = V/I", detail: "V=Voltage(V), I=Current(A), R=Resistance(Ω)", trick: "VIR triangle — V on top, I×R on bottom", category: "Science", color: "#dc2626" },
  { topic: "Chemical Formula (Common)", formula: "H₂O = Water, NaCl = Salt\nCO₂ = Carbon Dioxide, H₂SO₄ = Sulfuric Acid", detail: "HCl = Hydrochloric Acid, NaOH = Caustic Soda", trick: "Na=Sodium, Fe=Iron, Cu=Copper, Au=Gold", category: "Science", color: "#dc2626" },
];

const CATEGORIES = ["All", "Math", "Reasoning", "English", "Science"];

export default function FormulaCards() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [flippedCard, setFlippedCard] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  const filtered = FORMULAS.filter(f =>
    (activeCategory === "All" || f.category === activeCategory) &&
    (search === "" || f.topic.toLowerCase().includes(search.toLowerCase()) || f.formula.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-8 text-center">
        <div className="text-4xl mb-2">📐</div>
        <h1 className="text-2xl font-black mb-1">Formula Quick Cards</h1>
        <p className="text-indigo-200 text-sm">Tap करके formula flip करो — exam ready रहो!</p>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Search */}
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="🔍 Formula search करें... (e.g. SI, profit, speed)"
          className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-400 mb-5 transition-colors"
        />

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 hide-scrollbar">
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setActiveCategory(cat)}
              className="shrink-0 text-sm px-5 py-2 rounded-full font-bold border-2 transition-all"
              style={activeCategory === cat
                ? { background: "#4f46e5", color: "white", borderColor: "#4f46e5" }
                : { background: "white", color: "#4b5563", borderColor: "#e5e7eb" }}>
              {cat === "Math" ? "📐 " : cat === "Reasoning" ? "🧠 " : cat === "English" ? "📝 " : cat === "Science" ? "🔬 " : "📚 "}{cat}
            </button>
          ))}
        </div>

        <p className="text-sm text-gray-500 font-semibold mb-4">{filtered.length} formulas • Card tap करके flip करें</p>

        {/* Formula Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((f, i) => (
            <div key={i} onClick={() => setFlippedCard(flippedCard === i ? null : i)}
              className="cursor-pointer h-52"
              style={{ perspective: 1000 }}>
              <div className="relative w-full h-full transition-transform duration-500 shadow-lg rounded-2xl"
                style={{ transformStyle: "preserve-3d", transform: flippedCard === i ? "rotateY(180deg)" : "rotateY(0deg)" }}>
                {/* Front */}
                <div className="absolute inset-0 rounded-2xl p-5 flex flex-col justify-between"
                  style={{ backfaceVisibility: "hidden", background: `linear-gradient(135deg, ${f.color}15, ${f.color}30)`, border: `2px solid ${f.color}40` }}>
                  <div>
                    <span className="text-xs font-black px-2 py-0.5 rounded-full text-white mb-3 inline-block"
                      style={{ background: f.color }}>{f.category}</span>
                    <h3 className="font-black text-gray-900 text-base">{f.topic}</h3>
                  </div>
                  <div className="bg-white/80 rounded-xl px-3 py-2">
                    <pre className="text-xs font-bold whitespace-pre-wrap leading-relaxed" style={{ color: f.color, fontFamily: "inherit" }}>{f.formula}</pre>
                  </div>
                  <p className="text-[10px] text-gray-400 font-semibold text-center">👆 Tap for details & trick</p>
                </div>
                {/* Back */}
                <div className="absolute inset-0 rounded-2xl p-5 flex flex-col justify-between text-white"
                  style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)", background: `linear-gradient(135deg, ${f.color}, ${f.color}cc)` }}>
                  <div>
                    <h3 className="font-black text-base mb-2">{f.topic}</h3>
                    <p className="text-xs text-white/90 leading-relaxed">{f.detail}</p>
                  </div>
                  <div className="bg-white/20 rounded-xl px-3 py-2 border border-white/30">
                    <p className="text-[10px] text-white/70 font-bold mb-1">💡 TRICK:</p>
                    <p className="text-xs font-semibold text-white">{f.trick}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 text-gray-400">
            <p className="text-4xl mb-2">🔍</p>
            <p className="font-semibold">कोई formula नहीं मिला</p>
          </div>
        )}
      </div>
    </div>
  );
}
