import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

type LeaderEntry = { rank: number; id: number; name: string; totalPoints: number; };

export default function Leaderboard() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/leaderboard")
      .then(r => r.json())
      .then(lb => setLeaderboard(lb.leaderboard || []))
      .finally(() => setLoading(false));
  }, []);

  const rankIcons = ["🥇", "🥈", "🥉"];
  const rankStyles = [
    "bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-300",
    "bg-gradient-to-r from-gray-50 to-gray-100 border-gray-300",
    "bg-gradient-to-r from-orange-50 to-orange-100 border-orange-300",
  ];

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {/* Header */}
      <div className="hero-gradient text-white py-10 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="text-5xl mb-3">🏆</div>
          <h1 className="text-3xl font-black mb-2">Leaderboard</h1>
          <p className="text-blue-200">Top Students • XP Rankings</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">

        {/* XP Info Banner */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-6 flex items-start gap-3">
          <span className="text-2xl flex-shrink-0">⭐</span>
          <div>
            <p className="font-bold text-blue-900 text-sm">यह XP Leaderboard है</p>
            <p className="text-blue-700 text-xs mt-0.5">
              Daily Quiz खेलने से XP मिलता है — जितना ज़्यादा quiz खेलें, उतना ऊपर आएं।
              Cash prizes सिर्फ <strong>Weekly Mega Quiz (रविवार)</strong> में मिलते हैं।
            </p>
          </div>
        </div>

        {/* Weekly Quiz CTA */}
        <div
          className="rounded-2xl p-4 mb-6 flex items-center justify-between cursor-pointer"
          style={{ background: "linear-gradient(135deg, #7c3aed, #4f46e5)" }}
          onClick={() => navigate("/mega-quiz")}
        >
          <div>
            <p className="text-white font-black text-sm">🏆 Weekly Mega Quiz</p>
            <p className="text-purple-200 text-xs mt-0.5">रविवार को होगी • ₹10 Entry • Cash Prizes जीतें</p>
          </div>
          <div className="text-right">
            <p className="text-yellow-300 font-black text-sm">₹300 🥇</p>
            <p className="text-purple-200 text-xs">1st Prize</p>
          </div>
        </div>

        {/* Leaderboard List */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="bg-[#1a3a6b] text-white px-6 py-4 flex items-center justify-between">
            <h2 className="font-black text-lg">Top 10 Students — XP</h2>
            <button
              onClick={() => window.location.reload()}
              className="text-blue-200 hover:text-white text-sm"
            >
              🔄 Refresh
            </button>
          </div>

          {loading ? (
            <div className="text-center py-12 text-gray-400">Loading...</div>
          ) : leaderboard.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-4xl mb-3">🎯</div>
              <p className="text-gray-500 font-semibold">अभी कोई data नहीं है।</p>
              <p className="text-gray-400 text-sm mt-1">Quiz खेलें और यहाँ आएं!</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {leaderboard.map((entry) => {
                const isCurrentUser = user?.id === entry.id;
                return (
                  <div
                    key={entry.id}
                    className={`flex items-center gap-4 px-6 py-4 transition-all ${
                      isCurrentUser ? "bg-blue-50 border-l-4 border-[#1a3a6b]" :
                      entry.rank <= 3 ? rankStyles[entry.rank - 1] + " border-l-4" : "hover:bg-gray-50"
                    }`}
                  >
                    <div className="w-10 text-center">
                      {entry.rank <= 3 ? (
                        <span className="text-2xl">{rankIcons[entry.rank - 1]}</span>
                      ) : (
                        <span className="font-black text-gray-500 text-lg">#{entry.rank}</span>
                      )}
                    </div>

                    <div className="w-10 h-10 rounded-full flex items-center justify-center font-black text-white text-sm flex-shrink-0"
                      style={{ background: `linear-gradient(135deg, #1a3a6b, #f97316)` }}>
                      {entry.name.charAt(0).toUpperCase()}
                    </div>

                    <div className="flex-1">
                      <div className="font-bold text-gray-800 text-sm">
                        {entry.name}
                        {isCurrentUser && (
                          <span className="ml-2 text-xs bg-[#1a3a6b] text-white px-2 py-0.5 rounded-full">आप</span>
                        )}
                      </div>
                      <div className="text-xs text-gray-400 mt-0.5">XP Rank #{entry.rank}</div>
                    </div>

                    <div className="text-right">
                      <div className="font-black text-[#1a3a6b] text-lg">{entry.totalPoints.toFixed(0)}</div>
                      <div className="text-xs text-gray-400">XP</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Not in top 10 */}
        {user && !leaderboard.some(e => e.id === user.id) && (
          <div className="mt-4 bg-orange-50 border border-orange-200 rounded-2xl p-4 text-center">
            <p className="text-orange-700 font-semibold text-sm">
              आप अभी Top 10 में नहीं हैं। Quiz खेलें और XP कमाएं! 🎯
            </p>
            <button onClick={() => navigate("/daily-quiz")} className="mt-3 btn-saffron px-5 py-2 rounded-xl text-sm font-bold">
              ⚡ Daily Quiz खेलें
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
