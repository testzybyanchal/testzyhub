import { useEffect } from "react";
import { useLocation } from "wouter";
import { categories } from "@/data/questions";
import { useAuth } from "@/contexts/AuthContext";

export default function SelectCategory() {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) navigate("/");
  }, [user, loading]);

  if (loading || !user) return null;

  return (
    <div className="min-h-screen pb-24 lg:pb-8" style={{ background: "linear-gradient(180deg, #fdf4ff 0%, #fce7f3 40%, #eff6ff 100%)" }}>

      {/* Header */}
      <div className="hero-gradient text-white py-10 px-4 relative overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute top-4 right-10 w-20 h-20 rounded-full opacity-20 float-anim" style={{ background: "radial-gradient(circle, #fbbf24, transparent)" }} />
        <div className="absolute bottom-2 left-8 w-14 h-14 rounded-full opacity-20" style={{ background: "radial-gradient(circle, #60a5fa, transparent)" }} />

        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-white/20 border border-white/30 px-4 py-1.5 rounded-full text-sm font-semibold mb-4 backdrop-blur-sm">
            👋 नमस्ते, {user.name}!
          </div>
          <h1 className="text-3xl md:text-4xl font-black mb-2 drop-shadow-lg">अपनी Category चुनें</h1>
          <p className="text-pink-100 font-medium">जिस exam की तैयारी करनी है, उसे select करें</p>
          <div className="flex items-center justify-center gap-3 mt-5">
            <div className="px-5 py-2.5 rounded-2xl text-sm font-bold shadow-lg"
              style={{ background: "rgba(255,255,255,0.2)", border: "1.5px solid rgba(255,255,255,0.35)", backdropFilter: "blur(8px)" }}>
              ⭐ आपके Total Points: <span className="font-black text-yellow-200 text-lg ml-1">{user.totalPoints.toFixed(1)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Grid */}
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {categories.map((cat, idx) => (
            <div
              key={cat.id}
              onClick={() => navigate(`/category/${cat.id}`)}
              className="category-card rounded-2xl shadow-md cursor-pointer overflow-hidden fade-in-up bg-white"
              style={{ animationDelay: `${idx * 70}ms` }}
            >
              {/* Colorful top bar */}
              <div className="h-2" style={{ background: `linear-gradient(90deg, ${cat.color}, ${cat.color}88)` }} />
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl shadow-md"
                    style={{ backgroundColor: cat.bgColor }}
                  >
                    {cat.icon}
                  </div>
                  <div
                    className="text-xs font-bold px-3 py-1.5 rounded-full"
                    style={{ backgroundColor: cat.bgColor, color: cat.color }}
                  >
                    Select →
                  </div>
                </div>
                <h3 className="font-black text-gray-800 text-xl mb-1">{cat.name}</h3>
                <p className="text-gray-500 text-sm mb-4">{cat.description}</p>
                <div
                  className="w-full text-center py-2.5 rounded-xl font-bold text-sm text-white shadow"
                  style={{ background: `linear-gradient(135deg, ${cat.color}, ${cat.color}bb)` }}
                >
                  Practice शुरू करें →
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Links */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            onClick={() => navigate("/daily-quiz")}
            className="rounded-2xl p-5 text-left text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
            style={{ background: "linear-gradient(135deg, #f97316, #ec4899)" }}
          >
            <div className="text-3xl mb-2">⚡</div>
            <div className="font-black text-lg">Daily Quiz</div>
            <div className="text-orange-100 text-sm mt-1 font-medium">शाम 8 बजे • 90 Questions • Prizes</div>
          </button>
          <button
            onClick={() => navigate("/leaderboard")}
            className="rounded-2xl p-5 text-left text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
            style={{ background: "linear-gradient(135deg, #6d28d9, #0ea5e9)" }}
          >
            <div className="text-3xl mb-2">🏆</div>
            <div className="font-black text-lg">Leaderboard</div>
            <div className="text-blue-100 text-sm mt-1 font-medium">Top 10 Students • Prizes देखें</div>
          </button>
          <button
            onClick={() => navigate("/")}
            className="rounded-2xl p-5 text-left text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
            style={{ background: "linear-gradient(135deg, #059669, #0ea5e9)" }}
          >
            <div className="text-3xl mb-2">🏠</div>
            <div className="font-black text-lg">Home Page</div>
            <div className="text-green-100 text-sm mt-1 font-medium">सारी जानकारी एक जगह</div>
          </button>
        </div>
      </div>
    </div>
  );
}
