import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

export default function ReferralPage() {
  const [, navigate] = useLocation();
  const { user, setShowAuthModal } = useAuth();
  const [code, setCode] = useState("");
  const [referredCount, setReferredCount] = useState(0);
  const [bonusXp, setBonusXp] = useState(0);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  // Apply code state
  const [applyCode, setApplyCode] = useState("");
  const [applying, setApplying] = useState(false);
  const [applyMsg, setApplyMsg] = useState("");

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    fetch("/api/referral/my-code", { credentials: "include" })
      .then(r => r.json())
      .then(d => {
        setCode(d.code || "");
        setReferredCount(d.referredCount || 0);
        setBonusXp(d.bonusXp || 0);
      })
      .finally(() => setLoading(false));
  }, [user]);

  function copyCode() {
    const shareText = `TestzyHub पर Government Exam की तैयारी करो — Free! मेरे referral code "${code}" से join करो और Extra 50 XP + 20 Coins पाओ! 🎯\nhttps://testzyhub.replit.app`;
    navigator.clipboard.writeText(shareText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function shareWhatsApp() {
    const text = encodeURIComponent(`TestzyHub पर Government Exam की तैयारी करो — Free! 🎯\nमेरे referral code "${code}" से join करो और Extra +50 XP + 20 Coins पाओ!\nhttps://testzyhub.replit.app`);
    window.open(`https://wa.me/?text=${text}`, "_blank");
  }

  async function handleApply(e: React.FormEvent) {
    e.preventDefault();
    if (!user) { setShowAuthModal(true); return; }
    if (!applyCode.trim()) return;
    setApplying(true);
    setApplyMsg("");
    try {
      const res = await fetch("/api/referral/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ code: applyCode }),
      });
      const data = await res.json();
      if (data.success) setApplyMsg(data.message);
      else setApplyMsg("❌ " + (data.error || "कुछ गलत हुआ"));
    } finally {
      setApplying(false);
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 pb-20" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white rounded-3xl shadow-xl p-8 max-w-sm w-full text-center">
          <div className="text-5xl mb-4">🎁</div>
          <h2 className="text-2xl font-black text-[#1a3a6b] mb-2">Referral Program</h2>
          <p className="text-gray-500 text-sm mb-6">Friends को invite करें और Extra XP + Coins कमाएं!</p>
          <button onClick={() => setShowAuthModal(true)} className="w-full btn-primary py-3 rounded-2xl font-bold">
            Login / Signup करें
          </button>
          <button onClick={() => navigate("/")} className="mt-3 text-gray-400 text-sm w-full">← वापस</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {/* Hero */}
      <div className="text-white py-10 px-4 text-center mb-6"
        style={{ background: "linear-gradient(135deg, #1a3a6b, #7c3aed)" }}>
        <div className="text-5xl mb-3">🎁</div>
        <h1 className="text-3xl font-black mb-2">Refer & Earn</h1>
        <p className="text-blue-200 text-sm">Friends को invite करें — दोनों को reward मिलेगा!</p>
      </div>

      <div className="max-w-lg mx-auto px-4">
        {/* Reward Info Cards */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { icon: "⭐", label: "आपको मिलेगा", val: "+50 XP" },
            { icon: "🪙", label: "आपको मिलेगा", val: "+20 Coins" },
            { icon: "🎯", label: "Friend को भी", val: "+50 XP" },
          ].map(c => (
            <div key={c.val} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-3 text-center">
              <div className="text-2xl mb-1">{c.icon}</div>
              <div className="font-black text-[#1a3a6b] text-base">{c.val}</div>
              <div className="text-xs text-gray-400 mt-0.5">{c.label}</div>
            </div>
          ))}
        </div>

        {/* My Stats */}
        <div className="bg-gradient-to-br from-[#1a3a6b]/5 to-purple-50 border-2 border-[#1a3a6b]/20 rounded-2xl p-5 mb-5">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-4xl font-black text-[#1a3a6b]">{referredCount}</div>
              <div className="text-sm text-gray-500 font-semibold">Friends Joined</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-black text-purple-600">{bonusXp}</div>
              <div className="text-sm text-gray-500 font-semibold">Total Bonus XP</div>
            </div>
          </div>
        </div>

        {/* My Referral Code */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-5 border border-gray-100">
          <h2 className="font-black text-[#1a3a6b] text-lg mb-4">🔗 आपका Referral Code</h2>
          {loading ? (
            <div className="h-16 bg-gray-100 rounded-2xl animate-pulse" />
          ) : (
            <>
              <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-2xl px-6 py-4 text-center mb-4">
                <div className="text-3xl font-black text-[#1a3a6b] tracking-widest">{code}</div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={copyCode}
                  className={`flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm transition-all ${copied ? "bg-green-500 text-white" : "bg-[#1a3a6b] text-white hover:bg-[#15306a]"}`}
                >
                  {copied ? "✅ Copied!" : "📋 Code Copy करें"}
                </button>
                <button
                  onClick={shareWhatsApp}
                  className="flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm bg-green-500 hover:bg-green-600 text-white transition-all"
                >
                  💬 WhatsApp Share
                </button>
              </div>
            </>
          )}
        </div>

        {/* Apply a Referral Code */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-5 border border-gray-100">
          <h2 className="font-black text-[#1a3a6b] text-lg mb-2">🎟️ Friend का Code Apply करें</h2>
          <p className="text-gray-500 text-sm mb-4">अगर किसी ने आपको invite किया है तो उनका code डालें और दोनों को reward पाएं!</p>

          {applyMsg && applyMsg.startsWith("✅") ? (
            <div className="text-center py-6">
              <div className="text-5xl mb-3">🎉</div>
              <p className="font-black text-green-700">{applyMsg}</p>
            </div>
          ) : (
            <form onSubmit={handleApply} className="flex gap-3">
              <input
                value={applyCode}
                onChange={e => setApplyCode(e.target.value.toUpperCase())}
                placeholder="जैसे: RAVI123"
                maxLength={12}
                className="flex-1 border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm font-bold tracking-wider focus:outline-none focus:border-[#1a3a6b] uppercase"
              />
              <button type="submit" disabled={applying || !applyCode.trim()}
                className="btn-primary px-5 py-3 rounded-2xl font-bold text-sm disabled:opacity-60">
                {applying ? "⏳" : "Apply"}
              </button>
            </form>
          )}
          {applyMsg && !applyMsg.startsWith("✅") && (
            <p className="text-red-600 text-sm font-semibold mt-2">{applyMsg}</p>
          )}
        </div>

        {/* How it Works */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-6 border border-gray-100">
          <h2 className="font-black text-[#1a3a6b] text-lg mb-4">📋 कैसे काम करता है?</h2>
          <div className="space-y-4">
            {[
              { n: "1", icon: "🔗", t: "अपना Referral Code copy करें या WhatsApp पर share करें" },
              { n: "2", icon: "👥", t: "Friend TestzyHub पर signup करे और आपका code apply करे" },
              { n: "3", icon: "⭐", t: "आपको +50 XP और +20 Coins तुरंत मिलेंगे" },
              { n: "4", icon: "🎯", t: "Friend को भी +50 XP और +20 Coins मिलेंगे" },
            ].map(({ n, icon, t }) => (
              <div key={n} className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-black flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, #1a3a6b, #7c3aed)" }}>
                  {n}
                </div>
                <p className="text-gray-700 text-sm leading-relaxed"><span className="mr-1">{icon}</span>{t}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-xl p-3 text-xs text-yellow-700 font-semibold">
            ⚠️ खुद का code खुद apply नहीं कर सकते। एक account पर एक बार ही apply होगा।
          </div>
        </div>

        <button onClick={() => navigate("/")} className="text-[#1a3a6b]/60 hover:text-[#1a3a6b] text-sm text-center w-full">
          ← वापस Home
        </button>
      </div>
    </div>
  );
}
