import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

type MegaInfo = {
  weekOf: string;
  quizDate: string;
  totalParticipants: number;
  entryFee: number;
  prizePool: Array<{ rank: number; prize: number }>;
  totalPrize: number;
  userRegistered: boolean;
};

const ADS = [
  { text: "📚 SSC CGL Complete Course — Enroll Now", color: "#7c3aed" },
  { text: "🎯 Railway NTPC Mock Test Series — Free!", color: "#0ea5e9" },
  { text: "📖 UPSC 2025 — Daily Current Affairs PDF", color: "#dc2626" },
  { text: "⚡ Banking PO Speed Test — Practice Daily", color: "#d97706" },
];

function Countdown({ to }: { to: string }) {
  const [diff, setDiff] = useState(0);
  useEffect(() => {
    const target = new Date(to).getTime();
    const tick = () => setDiff(Math.max(0, target - Date.now()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [to]);

  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  const secs = Math.floor((diff % 60000) / 1000);

  return (
    <div className="flex gap-3 justify-center">
      {[
        { v: days, l: "Days" },
        { v: hours, l: "Hours" },
        { v: mins, l: "Mins" },
        { v: secs, l: "Secs" },
      ].map(({ v, l }) => (
        <div key={l} className="bg-white/20 backdrop-blur rounded-xl px-4 py-3 text-white min-w-[64px] text-center">
          <div className="text-3xl font-black">{String(v).padStart(2, "0")}</div>
          <div className="text-xs opacity-70">{l}</div>
        </div>
      ))}
    </div>
  );
}

export default function MegaQuiz() {
  const [, navigate] = useLocation();
  const { user, setShowAuthModal } = useAuth();
  const [info, setInfo] = useState<MegaInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);
  const [adIdx, setAdIdx] = useState(0);
  const [leaderboard, setLeaderboard] = useState<Array<{ rank_position: number; score: number; name: string; level: string }>>([]);

  useEffect(() => {
    const interval = setInterval(() => setAdIdx((i) => (i + 1) % ADS.length), 4000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    fetch("/api/megaquiz/info", { credentials: "include" })
      .then((r) => r.json())
      .then((d) => { setInfo(d); setLoading(false); })
      .catch(() => setLoading(false));

    fetch("/api/megaquiz/leaderboard", { credentials: "include" })
      .then((r) => r.json())
      .then((d) => setLeaderboard(d.leaderboard || []));
  }, []);

  async function handleRegister() {
    if (!user) { setShowAuthModal(true); return; }
    setRegistering(true);
    try {
      const res = await fetch("/api/megaquiz/create-order", { method: "POST", credentials: "include" });
      const data = await res.json();

      if (!res.ok) {
        if (data.error?.includes("setup nahi")) {
          alert("⚠️ Payment gateway abhi setup nahi hai.\n\nAdmin se Razorpay keys configure karane ko bolein.\n\nJab tak ke liye: Admin se contact karein.");
        } else {
          alert(data.error || "कुछ गलत हुआ");
        }
        return;
      }

      // Razorpay checkout
      const rzpScript = document.createElement("script");
      rzpScript.src = "https://checkout.razorpay.com/v1/checkout.js";
      document.head.appendChild(rzpScript);

      rzpScript.onload = () => {
        const rzp = new (window as any).Razorpay({
          key: data.keyId,
          amount: data.amount,
          currency: data.currency,
          order_id: data.orderId,
          name: "Testzy Mega Quiz",
          description: `Weekly Mega Quiz — ₹${info?.entryFee} Entry Fee`,
          handler: async (response: any) => {
            const verifyRes = await fetch("/api/megaquiz/verify-payment", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              credentials: "include",
              body: JSON.stringify(response),
            });
            const verifyData = await verifyRes.json();
            if (verifyRes.ok) {
              alert("✅ " + verifyData.message);
              window.location.reload();
            } else {
              alert("❌ Payment verify नहीं हुआ");
            }
          },
          prefill: { name: user.name, email: user.email, contact: user.mobile || "" },
          theme: { color: "#6d28d9" },
        });
        rzp.open();
      };
    } catch {
      alert("कुछ गलत हुआ, फिर से try करें");
    } finally {
      setRegistering(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-4xl animate-pulse">🏆</div>
      </div>
    );
  }

  const quizDate = info ? new Date(info.quizDate) : null;
  const isRegistered = info?.userRegistered;

  // ── Timing Logic ─────────────────────────────────────────────────────────
  function getNextSunday8PM() {
    const now = new Date();
    const day = now.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
    const daysToSun = day === 0 ? 0 : 7 - day;
    const sun = new Date(now);
    sun.setDate(now.getDate() + daysToSun);
    sun.setHours(20, 0, 0, 0); // 8:00 PM
    // If today is Sunday but past 8:30 PM, get next Sunday
    if (day === 0 && now.getHours() >= 20 && now.getMinutes() >= 30) {
      sun.setDate(sun.getDate() + 7);
    }
    return sun;
  }

  function getNextSundayCutoff() { // 7:55 PM
    const s = getNextSunday8PM();
    s.setMinutes(s.getMinutes() - 5);
    return s;
  }

  function getNextFriday() { // Registration opens Friday 12 AM
    const now = new Date();
    const day = now.getDay();
    // Friday = 5
    const daysToFri = day <= 5 ? 5 - day : 7 - day + 5;
    const fri = new Date(now);
    fri.setDate(now.getDate() + (daysToFri === 0 && now.getHours() < 0 ? 0 : daysToFri));
    fri.setHours(0, 0, 0, 0);
    return fri;
  }

  const now = new Date();
  const day = now.getDay();
  const hour = now.getHours();
  const min = now.getMinutes();
  const nextSun8PM = getNextSunday8PM();
  const nextSunCutoff = getNextSundayCutoff();

  // isRegistrationOpen: Friday, Saturday, or Sunday before 7:55 PM
  const isRegistrationOpen = (() => {
    if (day === 5 || day === 6) return true; // Friday or Saturday
    if (day === 0) {
      // Sunday: open until 7:55 PM
      if (hour < 19) return true;
      if (hour === 19 && min < 55) return true;
      return false;
    }
    return false;
  })();

  // isQuizLive: Sunday 8:00 PM - 8:30 PM
  const isQuizLive = day === 0 && hour === 20 && min < 30;
  const isQuizEnded = day === 0 && (hour > 20 || (hour === 20 && min >= 30));

  // Countdown target
  const countdownTarget = isQuizLive
    ? new Date(nextSun8PM.getTime() + 30 * 60000) // End of quiz
    : isRegistrationOpen
    ? nextSun8PM // Time until quiz starts
    : getNextFriday(); // Time until registration opens

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-950 via-amber-900 to-orange-950 pb-20 lg:pb-0">
      {/* Running Ad Banner */}
      <div className="overflow-hidden py-2 border-b border-white/10" style={{ background: ADS[adIdx].color }}>
        <p className="text-white text-sm font-semibold text-center animate-pulse px-4">{ADS[adIdx].text}</p>
      </div>

      {/* Hero */}
      <div className="max-w-3xl mx-auto px-4 py-10 text-center text-white">
        <div className="text-7xl mb-4">🏆</div>
        <h1 className="text-4xl font-black mb-2">Weekly Mega Quiz</h1>
        <p className="text-amber-200 text-lg mb-2">हर Sunday 8 PM — ₹10 Entry, बड़े Prizes!</p>

        <div className="mb-8">
          {/* Quiz Date Badge */}
          <div className="inline-flex items-center gap-2 bg-white/15 border border-white/25 rounded-full px-5 py-2 mb-4 backdrop-blur-sm">
            <span className="text-yellow-300 font-black text-base">📅</span>
            <span className="text-white font-black text-sm">
              {nextSun8PM.toLocaleDateString("hi-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
            </span>
            <span className="text-amber-300 font-bold text-sm">• रात 8:00 बजे</span>
          </div>

          {isQuizLive ? (
            <div className="bg-red-500/30 border-2 border-red-400 rounded-2xl px-4 py-3 mb-4 animate-pulse">
              <p className="text-red-300 font-black text-lg">🔴 LIVE — Quiz चल रही है! समाप्त होने में:</p>
            </div>
          ) : isRegistrationOpen ? (
            <p className="text-amber-300 text-sm mb-4 font-semibold">
              🟢 Registration Open! Quiz शुरू होने में:
            </p>
          ) : (
            <p className="text-amber-300 text-sm mb-4 font-semibold">
              Registration शुक्रवार से शुरू होती है। अगली Mega Quiz में:
            </p>
          )}
          <Countdown to={countdownTarget.toISOString()} />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4">
            <div className="text-3xl font-black text-yellow-300">{info?.totalParticipants || 0}</div>
            <div className="text-sm text-amber-200">Participants</div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4">
            <div className="text-3xl font-black text-green-300">₹{info?.totalPrize || 0}</div>
            <div className="text-sm text-amber-200">Prize Pool</div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4">
            <div className="text-3xl font-black text-orange-300">₹10</div>
            <div className="text-sm text-amber-200">Entry Fee</div>
          </div>
        </div>

        {/* Prize Distribution */}
        <div className="bg-white/10 backdrop-blur rounded-2xl p-6 mb-8 text-left">
          <h2 className="text-lg font-black text-white mb-4 text-center">🥇 Prize Distribution (Fixed)</h2>
          <div className="space-y-2">
            {[
              { label: "🥇 1st Place", prize: "₹300", icon: "text-yellow-300 bg-yellow-500/20" },
              { label: "🥈 2nd Place", prize: "₹200", icon: "text-gray-300 bg-white/10" },
              { label: "🥉 3rd Place", prize: "₹100", icon: "text-amber-500 bg-amber-500/20" },
              { label: "4th Place", prize: "₹50", icon: "text-amber-200 bg-white/5" },
              { label: "5th Place", prize: "₹25", icon: "text-amber-200 bg-white/5" },
            ].map(({ label, prize, icon }) => (
              <div key={label} className={`flex items-center justify-between rounded-xl px-4 py-2.5 ${icon.split(" ")[1]}`}>
                <span className={`font-bold text-sm ${icon.split(" ")[0]}`}>{label}</span>
                <span className={`font-black text-lg ${icon.split(" ")[0]}`}>{prize}</span>
              </div>
            ))}
          </div>
          <p className="text-amber-300/60 text-xs mt-4 text-center">90 questions · 30 minutes · Entry ₹10</p>
        </div>

        {/* Register / Live / Closed Button */}
        {isQuizLive && isRegistered ? (
          <div className="bg-red-500/30 border-2 border-red-400 rounded-2xl p-6 mb-6 animate-pulse">
            <div className="text-4xl mb-2">🔴</div>
            <h3 className="text-xl font-black text-red-300">Quiz अभी LIVE है!</h3>
            <p className="text-red-200 text-sm mt-1">जल्दी participate करें — बस 30 मिनट!</p>
            <div className="mt-3 bg-red-400/20 rounded-xl px-4 py-2 text-red-100 text-sm font-semibold">
              🎮 Quiz Feature जल्द आ रहा है — Registered participants को notify किया जाएगा
            </div>
          </div>
        ) : isQuizEnded ? (
          <div className="bg-white/10 border-2 border-white/20 rounded-2xl p-6 mb-6">
            <div className="text-4xl mb-2">⏱️</div>
            <h3 className="text-xl font-black text-white/80">इस हफ्ते की Quiz समाप्त हो गई</h3>
            <p className="text-amber-200 text-sm mt-1">अगले शुक्रवार से फिर registration शुरू होगी</p>
          </div>
        ) : isRegistered ? (
          <div className="bg-green-500/20 border-2 border-green-400 rounded-2xl p-6 mb-6">
            <div className="text-4xl mb-2">✅</div>
            <h3 className="text-xl font-black text-green-300">आप Registered हैं!</h3>
            <p className="text-green-200 text-sm mt-1">Sunday 8 PM को ready रहें। Good luck! 🍀</p>
          </div>
        ) : isRegistrationOpen ? (
          <button onClick={handleRegister} disabled={registering}
            className="w-full py-4 rounded-2xl text-xl font-black text-white mb-4 hover:scale-105 transition-transform disabled:opacity-70 shadow-2xl"
            style={{ background: "linear-gradient(135deg, #d97706, #f59e0b, #d97706)" }}>
            {registering ? "Processing..." : "🎯 ₹10 देकर Register करें"}
          </button>
        ) : (
          <div className="bg-white/10 border-2 border-white/20 rounded-2xl p-4 mb-6">
            <p className="text-amber-200 font-semibold text-sm">⏳ Registration शुक्रवार 12 AM से शुरू होगी</p>
          </div>
        )}

        {isRegistrationOpen && !isRegistered && (
          <p className="text-amber-300/60 text-xs mb-6">Payment: Razorpay (UPI, Card, Net Banking)</p>
        )}

        {/* How it works */}
        <div className="bg-white/10 backdrop-blur rounded-2xl p-6 mt-8 text-left">
          <h2 className="text-lg font-black text-white mb-4">📋 कैसे काम करता है?</h2>
          <div className="space-y-3">
            {[
              { s: "1", t: "₹10 entry fee देकर register करें (शुक्रवार - रविवार 7:55 PM तक)" },
              { s: "2", t: "Sunday 8:00 PM को TestzyHub पर आएं" },
              { s: "3", t: "90 questions, 30 minutes — सभी को same questions" },
              { s: "4", t: "Top 5 को prize money transfer होगी" },
            ].map(({ s, t }) => (
              <div key={s} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-500 text-gray-900 flex items-center justify-center text-xs font-black shrink-0">{s}</div>
                <p className="text-amber-100 text-sm">{t}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Leaderboard of last week */}
        {leaderboard.length > 0 && (
          <div className="bg-white/10 backdrop-blur rounded-2xl p-6 mt-8 text-left">
            <h2 className="text-lg font-black text-white mb-4">🏅 इस हफ्ते के Top Players</h2>
            <div className="space-y-2">
              {leaderboard.slice(0, 5).map((p, i) => (
                <div key={i} className="flex items-center justify-between bg-white/10 rounded-xl px-4 py-2">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`}</span>
                    <span className="font-bold text-white text-sm">{p.name}</span>
                    <span className="text-xs text-amber-300">{p.level}</span>
                  </div>
                  <span className="font-black text-yellow-300">{p.score} pts</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <button onClick={() => navigate("/")} className="mt-8 text-amber-400/60 hover:text-amber-300 text-sm transition-colors">
          ← वापस जाएं
        </button>
      </div>
    </div>
  );
}
