import { useState, useEffect } from "react";
import { useLocation } from "wouter";

type TournamentState = "lobby" | "waiting" | "quiz" | "results";

const QUIZ_QUESTIONS = [
  { q: "भारत का राष्ट्रीय पशु कौन सा है?", opts: ["शेर", "बाघ", "हाथी", "मोर"], ans: 1 },
  { q: "1 km में कितने meter होते हैं?", opts: ["100", "500", "1000", "1500"], ans: 2 },
  { q: "SSC CGL में कितने tier होते हैं?", opts: ["2", "3", "4", "5"], ans: 2 },
  { q: "SI = PRT/100 में T का मतलब क्या है?", opts: ["Total", "Time", "Tax", "Type"], ans: 1 },
  { q: "भारत का सबसे बड़ा राज्य (area) कौन सा है?", opts: ["MP", "UP", "Rajasthan", "Maharashtra"], ans: 2 },
  { q: "H₂O किसका formula है?", opts: ["Hydrogen", "Water", "Oxygen", "Acid"], ans: 1 },
  { q: "F = ma किसका formula है?", opts: ["Speed", "Newton's 2nd Law", "Ohm's Law", "Energy"], ans: 1 },
  { q: "Average = ?", opts: ["Sum × Count", "Sum / Count", "Sum + Count", "Count / Sum"], ans: 1 },
  { q: "DNA का full form क्या है?", opts: ["Deoxyribonucleic Acid", "Diribonucleic Acid", "Deoxyribonicle Acid", "Dinucleoribic Acid"], ans: 0 },
  { q: "प्रकाश की गति लगभग कितनी है?", opts: ["1 लाख km/s", "2 लाख km/s", "3 लाख km/s", "4 लाख km/s"], ans: 2 },
];

const FAKE_PLAYERS = [
  { name: "Rahul_SSC", avatar: "👦", score: 0, xp: 1250 },
  { name: "Priya_NTPC", avatar: "👧", score: 0, xp: 980 },
  { name: "Aakash_UP", avatar: "🧑", score: 0, xp: 2100 },
];

export default function Tournament() {
  const [state, setState] = useState<TournamentState>("lobby");
  const [, navigate] = useLocation();
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [myScore, setMyScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [players, setPlayers] = useState(FAKE_PLAYERS);
  const [waitCount, setWaitCount] = useState(3);
  const [tournamentType, setTournamentType] = useState<"quick" | "mega">("quick");

  // Waiting room countdown
  useEffect(() => {
    if (state !== "waiting") return;
    if (waitCount <= 0) { setState("quiz"); return; }
    const id = setTimeout(() => setWaitCount(c => c - 1), 1000);
    return () => clearTimeout(id);
  }, [state, waitCount]);

  // Quiz timer
  useEffect(() => {
    if (state !== "quiz") return;
    if (timeLeft <= 0) {
      handleAnswer(-1);
      return;
    }
    const id = setInterval(() => setTimeLeft(t => t - 1), 1000);
    return () => clearInterval(id);
  }, [state, timeLeft, currentQ]);

  function handleAnswer(optIdx: number) {
    if (selected !== null) return;
    setSelected(optIdx);
    const correct = optIdx === QUIZ_QUESTIONS[currentQ].ans;
    if (correct) setMyScore(s => s + (timeLeft * 10));
    setAnswers(a => [...a, correct]);

    // Simulate opponents answering
    setPlayers(ps => ps.map(p => ({
      ...p,
      score: p.score + (Math.random() > 0.4 ? Math.floor(Math.random() * 120 + 60) : 0)
    })));

    setTimeout(() => {
      if (currentQ >= QUIZ_QUESTIONS.length - 1) {
        setState("results");
      } else {
        setCurrentQ(q => q + 1);
        setSelected(null);
        setTimeLeft(15);
      }
    }, 1500);
  }

  function joinTournament(type: "quick" | "mega") {
    setTournamentType(type);
    setState("waiting");
    setWaitCount(3);
  }

  const allPlayers = [
    { name: "आप (You)", avatar: "🎯", score: myScore, xp: 0 },
    ...players
  ].sort((a, b) => b.score - a.score);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900 text-white">
      {/* Header */}
      <div className="text-center px-4 py-8">
        <div className="text-5xl mb-3">🏆</div>
        <h1 className="text-3xl font-black mb-1">Tournament Mode</h1>
        <p className="text-purple-300 text-sm">4-8 players के साथ real-time quiz tournament!</p>
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-10">

        {/* LOBBY */}
        {state === "lobby" && (
          <div className="space-y-5">
            {/* Quick Tournament */}
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-2xl flex items-center justify-center text-2xl">⚡</div>
                <div>
                  <h3 className="font-black text-lg">Quick Tournament</h3>
                  <p className="text-purple-300 text-xs">4 players • 10 questions • Free</p>
                </div>
                <span className="ml-auto text-xs bg-green-500/20 text-green-300 border border-green-400/30 px-3 py-1 rounded-full font-bold">FREE</span>
              </div>
              <div className="flex gap-3 mb-4">
                {["⚡ Fast Pace", "🎯 GK+Math", "🏅 XP Prize"].map(t => (
                  <span key={t} className="text-xs bg-white/10 px-3 py-1 rounded-full font-semibold">{t}</span>
                ))}
              </div>
              <button onClick={() => joinTournament("quick")}
                className="w-full py-3.5 rounded-2xl font-black text-base text-white shadow-xl transition-all hover:scale-105 active:scale-95"
                style={{ background: "linear-gradient(135deg, #10b981, #3b82f6)" }}>
                ⚡ Quick Tournament Join करें
              </button>
            </div>

            {/* Mega Tournament */}
            <div className="bg-white/10 backdrop-blur-sm border border-yellow-400/30 rounded-3xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-yellow-500/20 rounded-2xl flex items-center justify-center text-2xl">👑</div>
                <div>
                  <h3 className="font-black text-lg">Mega Tournament</h3>
                  <p className="text-yellow-300 text-xs">8 players • 15 questions • ₹20 Entry</p>
                </div>
                <span className="ml-auto text-xs bg-yellow-500/20 text-yellow-300 border border-yellow-400/30 px-3 py-1 rounded-full font-bold">₹20</span>
              </div>
              <div className="flex gap-3 mb-4">
                {["👑 ₹500 Prize", "🏆 Bracket", "📊 Leaderboard"].map(t => (
                  <span key={t} className="text-xs bg-white/10 px-3 py-1 rounded-full font-semibold">{t}</span>
                ))}
              </div>
              <button onClick={() => joinTournament("mega")}
                className="w-full py-3.5 rounded-2xl font-black text-base text-white shadow-xl transition-all hover:scale-105 active:scale-95"
                style={{ background: "linear-gradient(135deg, #d97706, #ef4444)" }}>
                👑 Mega Tournament Join करें (₹20)
              </button>
            </div>

            {/* Recent Winners */}
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-5">
              <h3 className="font-black mb-4 flex items-center gap-2">🏅 Recent Winners</h3>
              <div className="space-y-3">
                {[
                  { name: "Rahul Kumar", exam: "SSC CGL", score: 1450, prize: "₹500" },
                  { name: "Priya Singh", exam: "Railway NTPC", score: 1380, prize: "₹300" },
                  { name: "Amit Sharma", exam: "UP Police", score: 1290, prize: "₹200" },
                ].map((w, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-2xl">
                    <span className="text-xl">{["🥇", "🥈", "🥉"][i]}</span>
                    <div className="flex-1">
                      <p className="font-bold text-sm">{w.name}</p>
                      <p className="text-purple-300 text-xs">{w.exam} • {w.score} pts</p>
                    </div>
                    <span className="text-yellow-300 font-black text-sm">{w.prize}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* WAITING */}
        {state === "waiting" && (
          <div className="text-center">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8 mb-5">
              <div className="text-6xl mb-4 animate-bounce">⏳</div>
              <h2 className="text-2xl font-black mb-2">Players ढूंढे जा रहे हैं...</h2>
              <p className="text-purple-300 mb-6">Tournament शुरू होने में</p>
              <div className="text-6xl font-black text-yellow-300 mb-6">{waitCount}</div>
              <div className="space-y-3">
                {[{ name: "आप (You)", status: "ready" }, ...FAKE_PLAYERS.map(p => ({ name: p.name, status: "ready" }))].map((p, i) => (
                  <div key={i} className="flex items-center gap-3 bg-white/10 rounded-2xl px-4 py-3">
                    <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse" />
                    <span className="font-bold text-sm flex-1 text-left">{p.name}</span>
                    <span className="text-xs text-green-400 font-semibold">✅ Ready</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* QUIZ */}
        {state === "quiz" && (
          <div>
            {/* Progress + Timer */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex gap-1.5">
                {QUIZ_QUESTIONS.map((_, i) => (
                  <div key={i} className="h-2 rounded-full transition-all"
                    style={{ width: i === currentQ ? 20 : 8, background: i < currentQ ? "#10b981" : i === currentQ ? "white" : "rgba(255,255,255,0.3)" }} />
                ))}
              </div>
              <div className="flex items-center gap-2">
                <div className="text-sm font-black">{currentQ + 1}/{QUIZ_QUESTIONS.length}</div>
                <div className="w-12 h-12 rounded-full border-4 flex items-center justify-center font-black text-lg"
                  style={{ borderColor: timeLeft <= 5 ? "#ef4444" : "#10b981", color: timeLeft <= 5 ? "#ef4444" : "white" }}>
                  {timeLeft}
                </div>
              </div>
            </div>

            {/* Live Scores */}
            <div className="flex gap-2 mb-5 overflow-x-auto hide-scrollbar">
              {[{ name: "आप", score: myScore }, ...players.map(p => ({ name: p.name, score: p.score }))].map((p, i) => (
                <div key={i} className="shrink-0 bg-white/10 rounded-xl px-3 py-2 text-center">
                  <p className="text-xs font-bold truncate max-w-16">{p.name}</p>
                  <p className="text-sm font-black text-yellow-300">{p.score}</p>
                </div>
              ))}
            </div>

            {/* Question */}
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-6 mb-5">
              <p className="text-sm text-purple-300 font-bold mb-2">Question {currentQ + 1}</p>
              <h2 className="text-lg font-black leading-relaxed">{QUIZ_QUESTIONS[currentQ].q}</h2>
            </div>

            {/* Options */}
            <div className="grid grid-cols-1 gap-3">
              {QUIZ_QUESTIONS[currentQ].opts.map((opt, i) => {
                const isSelected = selected === i;
                const isCorrect = i === QUIZ_QUESTIONS[currentQ].ans;
                let style = { background: "rgba(255,255,255,0.1)", border: "2px solid rgba(255,255,255,0.2)", color: "white" };
                if (selected !== null) {
                  if (isCorrect) style = { background: "rgba(16,185,129,0.3)", border: "2px solid #10b981", color: "white" };
                  else if (isSelected) style = { background: "rgba(239,68,68,0.3)", border: "2px solid #ef4444", color: "white" };
                }
                return (
                  <button key={i} onClick={() => handleAnswer(i)}
                    className="w-full text-left px-5 py-4 rounded-2xl font-semibold text-sm transition-all hover:brightness-110"
                    style={style}>
                    <span className="font-black mr-3">{["A", "B", "C", "D"][i]}.</span>{opt}
                    {selected !== null && isCorrect && " ✅"}
                    {selected !== null && isSelected && !isCorrect && " ❌"}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* RESULTS */}
        {state === "results" && (
          <div>
            <div className="text-center mb-6">
              <div className="text-5xl mb-3">
                {allPlayers[0].name === "आप (You)" ? "🥇" : allPlayers[1]?.name === "आप (You)" ? "🥈" : "🥉"}
              </div>
              <h2 className="text-2xl font-black mb-1">Tournament Complete!</h2>
              <p className="text-purple-300">आपका Score: <span className="text-white font-black text-xl">{myScore}</span></p>
              <p className="text-sm text-purple-300">{answers.filter(Boolean).length}/{QUIZ_QUESTIONS.length} सही</p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-5 mb-5">
              <h3 className="font-black mb-4 text-center">🏆 Final Leaderboard</h3>
              {allPlayers.map((p, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-2xl mb-2"
                  style={{ background: p.name === "आप (You)" ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.05)" }}>
                  <span className="text-2xl w-8">{["🥇", "🥈", "🥉", "4️⃣"][i]}</span>
                  <div className="flex-1">
                    <p className="font-bold text-sm">{p.name} {p.name === "आप (You)" && "← आप"}</p>
                  </div>
                  <span className="font-black text-yellow-300">{p.score} pts</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => { setState("lobby"); setMyScore(0); setCurrentQ(0); setAnswers([]); setPlayers(FAKE_PLAYERS); }}
                className="py-3.5 rounded-2xl font-black text-white text-sm"
                style={{ background: "linear-gradient(135deg, #7c3aed, #2563eb)" }}>
                🔄 फिर खेलें
              </button>
              <button onClick={() => navigate("/")}
                className="py-3.5 rounded-2xl font-black text-sm border-2 border-white/30 text-white">
                🏠 Home जाएं
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
