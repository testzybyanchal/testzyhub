import { useState, useRef } from "react";

const SUBJECTS = ["General (सामान्य)", "Math / गणित", "Reasoning / तर्कशक्ति", "English", "Hindi", "GK / सामान्य ज्ञान", "Science / विज्ञान", "Computer"];

const SAMPLE_QUESTIONS = [
  "SI aur CI mein kya fark hota hai?",
  "Profit and Loss mein selling price kaise nikaalte hain?",
  "Blood relation problems solve karne ka shortcut kya hai?",
  "SSC CGL mein kitne questions hote hain?",
  "Train problems mein relative speed kaise calculate karein?",
];

export default function AiDoubt() {
  const [question, setQuestion] = useState("");
  const [subject, setSubject] = useState("General (सामान्य)");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<{ q: string; a: string; sub: string }[]>([]);
  const answerRef = useRef<HTMLDivElement>(null);

  async function solveDoubt() {
    if (!question.trim() || loading) return;
    setLoading(true);
    setAnswer("");
    try {
      const res = await fetch("/api/ai-doubt/solve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ question: question.trim(), subject }),
      });
      const data = await res.json();
      if (data.answer) {
        setAnswer(data.answer);
        setHistory(h => [{ q: question.trim(), a: data.answer, sub: subject }, ...h.slice(0, 9)]);
        setTimeout(() => answerRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
      } else {
        setAnswer("❌ Answer generate nahi ho saka. Please try again.");
      }
    } catch {
      setAnswer("❌ Server se connect nahi ho saka. Please try again.");
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-blue-600 text-white px-4 py-10 text-center">
        <div className="text-5xl mb-3">🤖</div>
        <h1 className="text-3xl font-black mb-2">AI Doubt Solver</h1>
        <p className="text-violet-200 text-sm max-w-md mx-auto">
          Koi bhi doubt puchho — SSC, Railway, Police, Banking — AI turant explain karega Hindi + English mein!
        </p>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Input Box */}
        <div className="bg-white rounded-3xl shadow-xl p-6 mb-6">
          <label className="block text-sm font-bold text-gray-700 mb-2">📚 Subject चुनें</label>
          <div className="flex flex-wrap gap-2 mb-4">
            {SUBJECTS.map(s => (
              <button key={s} onClick={() => setSubject(s)}
                className="text-xs px-3 py-1.5 rounded-full font-semibold border transition-all"
                style={subject === s
                  ? { background: "#7c3aed", color: "white", borderColor: "#7c3aed" }
                  : { background: "white", color: "#4b5563", borderColor: "#d1d5db" }}>
                {s}
              </button>
            ))}
          </div>

          <label className="block text-sm font-bold text-gray-700 mb-2">❓ अपना Doubt लिखें</label>
          <textarea
            value={question}
            onChange={e => setQuestion(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && e.ctrlKey) solveDoubt(); }}
            placeholder="जैसे: Train ki speed 60 km/h है और 200m लंबी है, तो platform cross करने में कितना समय लगेगा?"
            className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm resize-none focus:outline-none focus:border-violet-400 transition-colors"
            rows={4}
          />
          <p className="text-xs text-gray-400 mt-1">💡 Ctrl+Enter se bhi submit kar sakte ho</p>

          {/* Sample Questions */}
          <div className="mt-3">
            <p className="text-xs font-bold text-gray-500 mb-2">🔍 Sample Questions:</p>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_QUESTIONS.map(q => (
                <button key={q} onClick={() => setQuestion(q)}
                  className="text-xs bg-violet-50 text-violet-700 border border-violet-200 px-3 py-1.5 rounded-xl hover:bg-violet-100 transition-all font-medium">
                  {q}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={solveDoubt}
            disabled={loading || !question.trim()}
            className="mt-5 w-full py-4 rounded-2xl font-black text-white text-base transition-all disabled:opacity-60"
            style={{ background: "linear-gradient(135deg, #7c3aed, #2563eb)" }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="animate-spin">⏳</span> AI सोच रहा है...
              </span>
            ) : "🚀 Doubt Solve करो!"}
          </button>
        </div>

        {/* Answer Box */}
        {answer && (
          <div ref={answerRef} className="bg-white rounded-3xl shadow-xl p-6 mb-6 border-l-4 border-violet-500">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-full bg-violet-100 flex items-center justify-center text-base">🤖</div>
              <div>
                <p className="font-black text-gray-900 text-sm">AI का जवाब</p>
                <p className="text-xs text-gray-500">{subject} • Powered by Gemini</p>
              </div>
              <button
                onClick={() => navigator.clipboard?.writeText(answer)}
                className="ml-auto text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-xl font-semibold text-gray-600 transition-all">
                📋 Copy
              </button>
            </div>
            <div className="prose prose-sm max-w-none">
              {answer.split("\n").map((line, i) => (
                <p key={i} className={`text-sm leading-relaxed mb-2 ${line.match(/^\d\./) ? "font-semibold text-violet-700" : "text-gray-700"}`}>
                  {line}
                </p>
              ))}
            </div>
          </div>
        )}

        {/* History */}
        {history.length > 0 && (
          <div className="bg-white rounded-3xl shadow-xl p-6">
            <h3 className="font-black text-gray-900 mb-4 flex items-center gap-2">
              <span>📜</span> पिछले Doubts
            </h3>
            <div className="space-y-3">
              {history.map((h, i) => (
                <button key={i} onClick={() => { setQuestion(h.q); setAnswer(h.a); setSubject(h.sub); }}
                  className="w-full text-left p-4 bg-gray-50 hover:bg-violet-50 rounded-2xl transition-all group">
                  <p className="text-sm font-semibold text-gray-800 group-hover:text-violet-700 truncate">❓ {h.q}</p>
                  <p className="text-xs text-gray-500 mt-1 truncate">{h.sub} • {h.a.substring(0, 80)}...</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
