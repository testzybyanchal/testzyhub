import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { categories, getQuestionsByCategory, type Question } from "@/data/questions";
import { fetchDBQuestions } from "@/hooks/useQuestions";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTranslatedQuestion } from "@/hooks/useTranslatedQuestion";
import { useAntiCheat, checkAlreadyAttempted } from "@/hooks/useAntiCheat";

const TOTAL_QUESTIONS = 10;

export default function CategoryQuiz() {
  const [location, navigate] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const categoryId = searchParams.get("category") || "ssc";
  const { user, setShowAuthModal, refreshUser } = useAuth();
  const { t } = useLanguage();

  const [questions, setQuestions] = useState<Question[]>([]);
  const [allPoolQuestions, setAllPoolQuestions] = useState<Question[]>([]);
  const [loadingQ, setLoadingQ] = useState(true);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [finished, setFinished] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [rewards, setRewards] = useState<{ xp: number; coins: number } | null>(null);
  const [alreadyAttempted, setAlreadyAttempted] = useState(false);

  const handleViolation = useCallback(() => { setFinished(true); }, []);
  const { warning: antiCheatWarning } = useAntiCheat({
    isActive: !loadingQ && !finished && !alreadyAttempted,
    onViolation: handleViolation,
  });

  const category = categories.find((c) => c.id === categoryId);
  const tq = useTranslatedQuestion(questions[currentIdx] ?? null);

  function pickQuestions(pool: Question[]) {
    return [...pool].sort(() => Math.random() - 0.5).slice(0, TOTAL_QUESTIONS);
  }

  useEffect(() => {
    if (!user) { setShowAuthModal(true); return; }
    setLoadingQ(true);
    checkAlreadyAttempted("category", categoryId).then((a) => setAlreadyAttempted(a));
    fetchDBQuestions(categoryId, "quiz").then((dbQs) => {
      const staticQs = getQuestionsByCategory(categoryId);
      const pool = dbQs.length > 0 ? dbQs : staticQs;
      setAllPoolQuestions(pool);
      setQuestions(pickQuestions(pool));
      setCurrentIdx(0);
      setSelected(null);
      setScore(0);
      setCorrect(0);
      setWrong(0);
      setFinished(false);
      setSubmitted(false);
      setLoadingQ(false);
    });
  }, [categoryId, user]);

  function handleSelect(idx: number) {
    if (selected !== null) return;
    setSelected(idx);
    const current = questions[currentIdx];
    if (idx === current.correct) {
      setCorrect((c) => c + 1);
      setScore((s) => s + 1);
    } else {
      setWrong((w) => w + 1);
      setScore((s) => Math.max(0, s - 0.5));
    }
  }

  function handleNext() {
    if (currentIdx + 1 >= questions.length) {
      setFinished(true);
    } else {
      setCurrentIdx((i) => i + 1);
      setSelected(null);
    }
  }

  async function submitResult() {
    if (submitted || !user) return;
    setSubmitted(true);
    try {
      const res = await fetch("/api/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          quizType: "category",
          category: categoryId,
          correctCount: correct,
          wrongCount: wrong,
          totalQuestions: questions.length,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (data.xpEarned !== undefined) setRewards({ xp: data.xpEarned, coins: data.coinsEarned || 0 });
      await refreshUser();
    } catch {}
  }

  useEffect(() => {
    if (finished) submitResult();
  }, [finished]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center">
          <p className="text-xl font-semibold text-gray-700 mb-4">Quiz के लिए Login ज़रूरी है</p>
          <button onClick={() => setShowAuthModal(true)} className="btn-primary px-6 py-2.5 rounded-xl">Login / Signup</button>
        </div>
      </div>
    );
  }

  if (alreadyAttempted && !finished) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 pb-20" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white rounded-3xl shadow-xl p-8 max-w-sm w-full text-center">
          <div className="text-6xl mb-4">✅</div>
          <h2 className="text-2xl font-black text-gray-800 mb-2">आज का Quiz दे दिया!</h2>
          <p className="text-gray-600 text-sm mb-6">
            आप आज यह Category Quiz पहले ही दे चुके हैं।<br />
            कल दोबारा आएं।
          </p>
          <button onClick={() => navigate("/")} className="btn-primary px-6 py-3 rounded-2xl font-bold">
            ← Home पर जाएं
          </button>
        </div>
      </div>
    );
  }

  if (loadingQ) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-3 float-anim">🎯</div>
          <p className="text-gray-500 text-lg font-semibold">प्रश्न लोड हो रहे हैं...</p>
        </div>
      </div>
    );
  }

  if (finished) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="min-h-screen flex items-center justify-center px-4 pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white rounded-3xl shadow-xl p-8 max-w-md w-full text-center fade-in-up">
          <div className="text-5xl mb-3">{pct >= 80 ? "🎉" : pct >= 60 ? "👍" : "📚"}</div>
          <h2 className="text-2xl font-black text-[#1a3a6b] mb-1">Quiz Complete!</h2>
          <p className="text-gray-500 mb-5">{category?.name} • {questions.length} Questions</p>

          <div className="rounded-2xl p-6 mb-5 text-white" style={{ background: `linear-gradient(135deg, ${category?.color || "#1a3a6b"}, #1a3a6b)` }}>
            <div className="text-4xl font-black mb-1">+{score.toFixed(1)} pts</div>
            <div className="text-white/80 text-sm">{correct}/{questions.length} सही • {pct}%</div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-5 text-sm">
            <div className="bg-green-50 rounded-xl p-3">
              <div className="font-black text-green-700 text-xl">{correct}</div>
              <div className="text-green-600 text-xs">सही</div>
            </div>
            <div className="bg-red-50 rounded-xl p-3">
              <div className="font-black text-red-700 text-xl">{wrong}</div>
              <div className="text-red-600 text-xs">गलत</div>
            </div>
            <div className="bg-yellow-50 rounded-xl p-3">
              <div className="font-black text-yellow-700 text-xl">{score.toFixed(1)}</div>
              <div className="text-yellow-600 text-xs">Points</div>
            </div>
          </div>

          {rewards && (
            <div className="flex gap-3 mb-5">
              <div className="flex-1 bg-purple-50 border border-purple-200 rounded-2xl p-3 text-center">
                <div className="font-black text-purple-700 text-2xl">+{rewards.xp}</div>
                <div className="text-purple-500 text-xs font-semibold">XP मिले ⚡</div>
              </div>
              <div className="flex-1 bg-yellow-50 border border-yellow-200 rounded-2xl p-3 text-center">
                <div className="font-black text-yellow-700 text-2xl">+{rewards.coins}</div>
                <div className="text-yellow-500 text-xs font-semibold">Coins 🪙</div>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={() => { setFinished(false); setQuestions(pickQuestions(allPoolQuestions)); setCurrentIdx(0); setSelected(null); setScore(0); setCorrect(0); setWrong(0); setSubmitted(false); setRewards(null); }}
              className="flex-1 btn-primary py-3 rounded-xl text-sm"
            >
              🔄 फिर खेलें
            </button>
            <button onClick={() => navigate(`/category/${categoryId}`)} className="flex-1 bg-gray-100 text-gray-700 font-semibold py-3 rounded-xl text-sm">
              ← Category
            </button>
          </div>
        </div>
      </div>
    );
  }

  const current = questions[currentIdx];
  const progress = ((currentIdx + 1) / questions.length) * 100;
  const catColor = category?.color || "#1a3a6b";

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {antiCheatWarning && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center bg-red-900/90 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-8 max-w-sm mx-4 text-center shadow-2xl">
            <div className="text-5xl mb-3">⚠️</div>
            <h3 className="text-xl font-black text-red-600 mb-2">Tab Switch Detected!</h3>
            <p className="text-gray-700 text-sm mb-3">
              Quiz में cheating की कोशिश पकड़ी गई।<br />
              <strong>Quiz अपने आप Submit हो रहा है...</strong>
            </p>
            <div className="w-full bg-red-100 rounded-full h-2 mt-3">
              <div className="bg-red-500 h-2 rounded-full animate-pulse" style={{ width: "100%" }} />
            </div>
          </div>
        </div>
      )}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-sm" style={{ color: catColor }}>
              {category?.icon} {category?.name} Quiz
            </span>
            <span className="text-sm text-gray-500 font-semibold">{currentIdx + 1} / {questions.length}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="progress-bar h-2.5 rounded-full" style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${catColor}, ${catColor}aa)` }} />
          </div>
        </div>
      </div>

      {/* Score row */}
      <div className="max-w-2xl mx-auto px-4 pt-4">
        <div className="flex gap-2 mb-4">
          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">✓ {correct}</span>
          <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold">✗ {wrong}</span>
          <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-xs font-bold">⭐ {score.toFixed(1)} pts</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-8 fade-in-up" key={currentIdx}>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-4">
          <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: catColor }}>
            {t("questionNo")} {currentIdx + 1}
            {tq?.isTranslating && <span className="ml-2 text-orange-400 text-[10px] font-normal animate-pulse">{t("translating")}</span>}
          </div>
          <p className="text-gray-800 font-semibold text-lg leading-relaxed">{tq?.translatedQuestion ?? current.question}</p>
        </div>

        <div className="flex flex-col gap-3">
          {current.options.map((opt, idx) => {
            let cls = "option-btn w-full text-left px-5 py-4 rounded-2xl font-medium text-gray-700 bg-white";
            if (selected !== null) {
              if (idx === current.correct) cls += " correct";
              else if (idx === selected) cls += " wrong";
              else cls += " border-gray-100 opacity-50";
            }
            return (
              <button key={idx} className={cls} onClick={() => handleSelect(idx)} disabled={selected !== null}>
                <span className="inline-flex items-center gap-3">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0 ${
                    selected !== null && idx === current.correct ? "bg-emerald-500 text-white" :
                    selected !== null && idx === selected ? "bg-red-500 text-white" : "text-gray-500"
                  }`} style={selected === null || (idx !== current.correct && idx !== selected) ? { background: category?.bgColor } : {}}>
                    {["A","B","C","D"][idx]}
                  </span>
                  {tq?.translatedOptions?.[idx] ?? opt}
                </span>
              </button>
            );
          })}
        </div>

        {selected !== null && current.explanation && (
          <div className="mt-4 bg-blue-50 border border-blue-200 rounded-2xl p-4 fade-in-up">
            <p className="text-sm font-bold text-[#1a3a6b] mb-1">💡</p>
            <p className="text-sm text-blue-700">{tq?.translatedExplanation ?? current.explanation}</p>
          </div>
        )}

        {selected !== null && (
          <button
            onClick={handleNext}
            className="mt-4 w-full py-4 rounded-2xl text-lg font-bold text-white fade-in-up"
            style={{ background: `linear-gradient(135deg, ${catColor}, #1a3a6b)` }}
          >
            {currentIdx + 1 >= questions.length ? "✅ Result देखें" : "अगला →"}
          </button>
        )}
      </div>
    </div>
  );
}
