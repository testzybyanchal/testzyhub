import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";

const CATEGORIES = [
  { id: "all", label: "🌐 सभी", color: "#6d28d9" },
  { id: "ssc", label: "🏛️ SSC", color: "#1a3a6b" },
  { id: "railway", label: "🚂 Railway", color: "#b91c1c" },
  { id: "police", label: "👮 Police", color: "#1d4ed8" },
  { id: "banking", label: "🏦 Banking", color: "#065f46" },
  { id: "general", label: "💡 General", color: "#92400e" },
];

type DoubtPost = {
  id: number;
  user_id: number;
  title: string;
  question_text: string;
  category: string;
  image_base64: string | null;
  is_resolved: boolean;
  created_at: string;
  user_name: string;
  user_is_admin: boolean;
  reply_count: string;
};

type Reply = {
  id: number;
  post_id: number;
  user_id: number;
  reply_text: string;
  image_base64: string | null;
  is_admin_reply: boolean;
  created_at: string;
  user_name: string;
  user_is_admin: boolean;
};

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "अभी";
  if (mins < 60) return `${mins} मिनट पहले`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} घंटे पहले`;
  const days = Math.floor(hrs / 24);
  return `${days} दिन पहले`;
}

function getCatColor(cat: string) {
  return CATEGORIES.find(c => c.id === cat)?.color || "#6d28d9";
}

function imageToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ─── New Doubt Modal ──────────────────────────────────────────────────────────
function NewDoubtModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [category, setCategory] = useState("general");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleImageChange(file: File) {
    if (file.size > 2 * 1024 * 1024) { setError("Image 2MB से छोटी होनी चाहिए"); return; }
    setImageFile(file);
    const b64 = await imageToBase64(file);
    setImagePreview(b64);
  }

  async function handleSubmit() {
    if (!title.trim() || !text.trim()) { setError("Title और Question दोनों भरें"); return; }
    setSubmitting(true);
    setError("");
    try {
      let image_base64 = null;
      if (imageFile) image_base64 = await imageToBase64(imageFile);

      const res = await fetch("/api/doubts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ title: title.trim(), question_text: text.trim(), category, image_base64 }),
      });
      const data = await res.json();
      if (data.success) { onSuccess(); onClose(); }
      else setError(data.error || "Error");
    } catch { setError("Network error"); }
    finally { setSubmitting(false); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" style={{ background: "rgba(0,0,0,0.5)" }} onClick={onClose}>
      <div
        className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white rounded-t-3xl px-5 pt-5 pb-3 border-b border-gray-100 flex items-center justify-between z-10">
          <div>
            <h2 className="font-black text-[#1a3a6b] text-xl">📝 Doubt पूछें</h2>
            <p className="text-gray-500 text-xs mt-0.5">कोई भी सवाल पूछें — students और admin जवाब देंगे</p>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-500 font-bold text-lg transition-all">✕</button>
        </div>

        <div className="p-5 space-y-4">
          {/* Title */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1.5">📌 Doubt का Title *</label>
            <input
              type="text"
              placeholder="जैसे: रेलवे GK में भारत के राज्यों वाला प्रश्न..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={150}
              className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-purple-400 transition-all"
            />
            <p className="text-xs text-gray-400 mt-1 text-right">{title.length}/150</p>
          </div>

          {/* Question Text */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1.5">❓ पूरा सवाल लिखें *</label>
            <textarea
              rows={4}
              placeholder="अपना doubt विस्तार से लिखें... जैसे options क्या हैं, कौन सा answer सही लग रहा है और क्यों confuse हैं..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={2000}
              className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-purple-400 resize-none transition-all"
            />
            <p className="text-xs text-gray-400 mt-1 text-right">{text.length}/2000</p>
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1.5">🏷️ Category</label>
            <div className="flex gap-2 flex-wrap">
              {CATEGORIES.filter(c => c.id !== "all").map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-full border-2 transition-all ${category === cat.id ? "text-white border-transparent" : "border-gray-200 text-gray-600 bg-white"}`}
                  style={category === cat.id ? { background: cat.color, borderColor: cat.color } : {}}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Image Upload */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1.5">📷 Photo Upload करें (optional)</label>
            {imagePreview ? (
              <div className="relative">
                <img src={imagePreview} alt="preview" className="w-full max-h-48 object-contain rounded-2xl border-2 border-green-300 bg-green-50" />
                <button onClick={() => { setImageFile(null); setImagePreview(null); }} className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-7 h-7 text-sm font-bold flex items-center justify-center">✕</button>
              </div>
            ) : (
              <div
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-gray-300 hover:border-purple-400 rounded-2xl p-5 text-center cursor-pointer transition-all"
              >
                <div className="text-3xl mb-1">📷</div>
                <p className="text-gray-500 text-sm font-medium">Question की photo upload करें</p>
                <p className="text-gray-400 text-xs">JPG, PNG • Max 2MB</p>
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleImageChange(f); }} />
          </div>

          {error && <p className="text-red-600 text-sm bg-red-50 rounded-xl px-4 py-2.5 font-semibold">⚠️ {error}</p>}

          <button
            onClick={handleSubmit}
            disabled={submitting || !title.trim() || !text.trim()}
            className="w-full py-4 rounded-2xl font-black text-white text-base disabled:opacity-60 transition-all"
            style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}
          >
            {submitting ? "⏳ Post हो रहा है..." : "🚀 Doubt Post करें"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Reply Item ───────────────────────────────────────────────────────────────
function ReplyItem({ reply, currentUserId, isAdmin, onDelete }: { reply: Reply; currentUserId?: number; isAdmin?: boolean; onDelete: (id: number) => void }) {
  const canDelete = isAdmin || currentUserId === reply.user_id;

  return (
    <div className={`rounded-2xl p-3.5 border ${reply.is_admin_reply ? "bg-purple-50 border-purple-200" : "bg-gray-50 border-gray-100"}`}>
      <div className="flex items-start gap-2.5">
        {/* Avatar */}
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black shrink-0 ${reply.is_admin_reply ? "bg-purple-600 text-white" : "bg-blue-100 text-blue-700"}`}>
          {reply.is_admin_reply ? "👑" : (reply.user_name?.[0] || "?").toUpperCase()}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className={`text-xs font-black ${reply.is_admin_reply ? "text-purple-700" : "text-gray-700"}`}>
              {reply.user_name || "User"}
              {reply.is_admin_reply && <span className="ml-1 bg-purple-600 text-white text-[10px] px-1.5 py-0.5 rounded-full">ADMIN</span>}
            </span>
            <span className="text-gray-400 text-[11px]">{timeAgo(reply.created_at)}</span>
            {canDelete && (
              <button onClick={() => onDelete(reply.id)} className="ml-auto text-red-400 hover:text-red-600 text-[11px] font-bold transition-colors">🗑️ Delete</button>
            )}
          </div>
          <p className="text-gray-800 text-sm leading-relaxed whitespace-pre-wrap">{reply.reply_text}</p>
          {reply.image_base64 && (
            <img src={reply.image_base64} alt="reply" className="mt-2 max-h-48 rounded-xl object-contain border border-gray-200 bg-white" />
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Reply Box ────────────────────────────────────────────────────────────────
function ReplyBox({ postId, onReplied }: { postId: number; onReplied: (reply: Reply) => void }) {
  const [text, setText] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleImageChange(file: File) {
    if (file.size > 2 * 1024 * 1024) { setError("Image 2MB से छोटी होनी चाहिए"); return; }
    setImageFile(file);
    setImagePreview(await imageToBase64(file));
  }

  async function submit() {
    if (!text.trim()) return;
    setSubmitting(true);
    setError("");
    try {
      let image_base64 = null;
      if (imageFile) image_base64 = await imageToBase64(imageFile);

      const res = await fetch(`/api/doubts/${postId}/reply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ reply_text: text.trim(), image_base64 }),
      });
      const data = await res.json();
      if (data.success) {
        onReplied(data.reply);
        setText("");
        setImageFile(null);
        setImagePreview(null);
      } else setError(data.error || "Error");
    } catch { setError("Network error"); }
    finally { setSubmitting(false); }
  }

  return (
    <div className="mt-3 bg-white border border-gray-200 rounded-2xl p-3">
      <textarea
        rows={2}
        placeholder="अपना जवाब लिखें..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        maxLength={1000}
        className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:border-purple-400"
      />
      {imagePreview && (
        <div className="relative mt-2">
          <img src={imagePreview} alt="preview" className="max-h-32 rounded-xl object-contain border border-gray-200" />
          <button onClick={() => { setImageFile(null); setImagePreview(null); }} className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 text-xs font-bold flex items-center justify-center">✕</button>
        </div>
      )}
      {error && <p className="text-red-600 text-xs mt-1">{error}</p>}
      <div className="flex items-center gap-2 mt-2">
        <button onClick={() => fileRef.current?.click()} className="text-gray-400 hover:text-purple-600 transition-colors text-lg" title="Photo attach करें">📷</button>
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleImageChange(f); }} />
        <div className="flex-1" />
        <button
          onClick={submit}
          disabled={submitting || !text.trim()}
          className="px-5 py-2 rounded-xl font-black text-white text-sm disabled:opacity-50 transition-all"
          style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}
        >
          {submitting ? "⏳" : "📤 Reply करें"}
        </button>
      </div>
    </div>
  );
}

// ─── Doubt Card ───────────────────────────────────────────────────────────────
function DoubtCard({ post, currentUserId, isCurrentUserAdmin, onDelete }: {
  post: DoubtPost;
  currentUserId?: number;
  isCurrentUserAdmin?: boolean;
  onDelete: (id: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [replies, setReplies] = useState<Reply[]>([]);
  const [loadingReplies, setLoadingReplies] = useState(false);
  const [resolved, setResolved] = useState(post.is_resolved);
  const catColor = getCatColor(post.category);
  const catLabel = CATEGORIES.find(c => c.id === post.category)?.label || post.category;
  const canDelete = isCurrentUserAdmin || currentUserId === post.user_id;
  const canResolve = currentUserId === post.user_id || isCurrentUserAdmin;

  async function loadReplies() {
    if (loadingReplies) return;
    setLoadingReplies(true);
    try {
      const res = await fetch(`/api/doubts/${post.id}`, { credentials: "include" });
      const data = await res.json();
      setReplies(data.replies || []);
    } catch {}
    finally { setLoadingReplies(false); }
  }

  function handleExpand() {
    const next = !expanded;
    setExpanded(next);
    if (next && replies.length === 0) loadReplies();
  }

  async function handleResolve() {
    const newVal = !resolved;
    setResolved(newVal);
    await fetch(`/api/doubts/${post.id}/resolve`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ resolved: newVal }),
    });
  }

  async function handleDeleteReply(replyId: number) {
    if (!confirm("Reply delete करें?")) return;
    const res = await fetch(`/api/doubts/${post.id}/replies/${replyId}`, { method: "DELETE", credentials: "include" });
    if ((await res.json()).success) setReplies(prev => prev.filter(r => r.id !== replyId));
  }

  return (
    <div className={`bg-white rounded-2xl shadow-sm border transition-all ${resolved ? "border-green-300" : "border-gray-100"} hover:shadow-md`}>
      {/* Card Header */}
      <div className="p-4">
        <div className="flex items-start gap-3">
          {/* User Avatar */}
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black shrink-0 text-white"
            style={{ background: post.user_is_admin ? "#6d28d9" : catColor }}
          >
            {post.user_is_admin ? "👑" : (post.user_name?.[0] || "?").toUpperCase()}
          </div>

          <div className="flex-1 min-w-0">
            {/* Meta */}
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="text-xs font-bold text-gray-600">{post.user_name || "User"}</span>
              {post.user_is_admin && <span className="text-[10px] bg-purple-100 text-purple-700 font-bold px-1.5 py-0.5 rounded-full">ADMIN</span>}
              <span className="text-gray-300 text-xs">•</span>
              <span className="text-gray-400 text-xs">{timeAgo(post.created_at)}</span>
              <span
                className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white ml-auto"
                style={{ background: catColor }}
              >
                {catLabel}
              </span>
              {resolved && <span className="text-[10px] font-bold bg-green-100 text-green-700 px-2 py-0.5 rounded-full">✅ Solved</span>}
            </div>

            {/* Title */}
            <h3 className="font-black text-gray-800 text-sm leading-tight mb-1.5">{post.title}</h3>

            {/* Question snippet */}
            <p className="text-gray-600 text-xs leading-relaxed line-clamp-2">{post.question_text}</p>
          </div>
        </div>

        {/* Thumbnail if image */}
        {post.image_base64 && !expanded && (
          <div className="mt-2.5 ml-12">
            <img
              src={post.image_base64}
              alt="doubt"
              className="max-h-32 rounded-xl object-contain border border-gray-200 bg-gray-50 cursor-pointer"
              onClick={handleExpand}
            />
          </div>
        )}

        {/* Footer row */}
        <div className="flex items-center gap-3 mt-3 ml-12">
          <button
            onClick={handleExpand}
            className="flex items-center gap-1.5 text-xs font-bold text-purple-600 hover:text-purple-800 transition-colors"
          >
            💬 {post.reply_count} जवाब
            <span className="text-gray-300">|</span>
            <span>{expanded ? "▲ बंद करें" : "▼ देखें"}</span>
          </button>

          {canResolve && (
            <button onClick={handleResolve} className={`text-xs font-bold transition-colors ${resolved ? "text-green-600 hover:text-gray-500" : "text-gray-400 hover:text-green-600"}`}>
              {resolved ? "✅ Solved" : "○ Mark Solved"}
            </button>
          )}

          {canDelete && (
            <button onClick={() => onDelete(post.id)} className="ml-auto text-xs text-red-400 hover:text-red-600 font-bold transition-colors">
              🗑️ Delete
            </button>
          )}
        </div>
      </div>

      {/* Expanded Detail */}
      {expanded && (
        <div className="border-t border-gray-100 px-4 pb-4 pt-3">
          {/* Full Question */}
          <div className="bg-gray-50 rounded-xl p-3 mb-3">
            <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-wrap">{post.question_text}</p>
            {post.image_base64 && (
              <img src={post.image_base64} alt="doubt" className="mt-2 max-h-64 rounded-xl object-contain border border-gray-200 bg-white w-full" />
            )}
          </div>

          {/* Replies */}
          {loadingReplies ? (
            <div className="text-center py-4 text-gray-400 text-sm">⏳ जवाब load हो रहे हैं...</div>
          ) : replies.length === 0 ? (
            <div className="text-center py-3 text-gray-400 text-xs">अभी कोई जवाब नहीं — पहले जवाब दें! 🎯</div>
          ) : (
            <div className="space-y-2 mb-3">
              {replies.map(r => (
                <ReplyItem key={r.id} reply={r} currentUserId={currentUserId} isAdmin={isCurrentUserAdmin} onDelete={handleDeleteReply} />
              ))}
            </div>
          )}

          {/* Reply Box */}
          {currentUserId ? (
            <ReplyBox postId={post.id} onReplied={(reply) => setReplies(prev => [...prev, reply])} />
          ) : (
            <p className="text-center text-gray-400 text-xs py-2">जवाब देने के लिए Login करें</p>
          )}
        </div>
      )}
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function DoubtsPage() {
  const { user, setShowAuthModal } = useAuth();
  const [doubts, setDoubts] = useState<DoubtPost[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [catFilter, setCatFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [page, setPage] = useState(1);
  const [showNewModal, setShowNewModal] = useState(false);

  async function loadDoubts(cat: string, q: string, pg: number) {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (cat !== "all") params.set("category", cat);
      if (q) params.set("search", q);
      params.set("page", String(pg));
      const res = await fetch(`/api/doubts?${params}`, { credentials: "include" });
      const data = await res.json();
      if (pg === 1) setDoubts(data.doubts || []);
      else setDoubts(prev => [...prev, ...(data.doubts || [])]);
      setTotal(data.total || 0);
    } catch {}
    finally { setLoading(false); }
  }

  useEffect(() => {
    setPage(1);
    loadDoubts(catFilter, search, 1);
  }, [catFilter, search]);

  function handleDeletePost(postId: number) {
    if (!confirm("यह post delete करें?")) return;
    fetch(`/api/doubts/${postId}`, { method: "DELETE", credentials: "include" })
      .then(r => r.json())
      .then(d => { if (d.success) setDoubts(prev => prev.filter(p => p.id !== postId)); });
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setSearch(searchInput);
  }

  function handleLoadMore() {
    const next = page + 1;
    setPage(next);
    loadDoubts(catFilter, search, next);
  }

  return (
    <div className="min-h-screen pb-24 lg:pb-8" style={{ background: "linear-gradient(180deg, #fdf4ff 0%, #fce7f3 40%, #eff6ff 100%)" }}>

      {/* ── Hero Banner ── */}
      <div className="text-white py-8 px-4" style={{ background: "linear-gradient(135deg, #6d28d9 0%, #4f46e5 50%, #1d4ed8 100%)" }}>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 bg-white/20 border border-white/30 rounded-full px-3 py-1 text-xs font-bold mb-3">
                🤝 Community Doubt Forum
              </div>
              <h1 className="text-3xl font-black mb-1">📚 Doubt पूछें</h1>
              <p className="text-purple-200 text-sm">कोई भी exam doubt — students और admin जवाब देंगे</p>
              <div className="flex gap-3 mt-3 text-xs flex-wrap">
                <span className="bg-white/20 px-3 py-1 rounded-full font-semibold">📷 Photo Upload</span>
                <span className="bg-white/20 px-3 py-1 rounded-full font-semibold">💬 Free Discussion</span>
                <span className="bg-white/20 px-3 py-1 rounded-full font-semibold">✅ Mark Solved</span>
              </div>
            </div>
            <button
              onClick={() => user ? setShowNewModal(true) : setShowAuthModal(true)}
              className="shrink-0 font-black text-sm px-5 py-3 rounded-2xl shadow-lg transition-all hover:scale-105"
              style={{ background: "#fbbf24", color: "#1a3a6b" }}
            >
              + Doubt पूछें
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-5">
        {/* Search */}
        <form onSubmit={handleSearch} className="mb-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="🔍 Doubt खोजें..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="flex-1 border-2 border-gray-200 rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-400 bg-white shadow-sm"
            />
            <button type="submit" className="px-5 py-2.5 rounded-2xl font-bold text-white text-sm shadow" style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}>
              खोजें
            </button>
            {search && (
              <button type="button" onClick={() => { setSearch(""); setSearchInput(""); }} className="px-4 py-2.5 rounded-2xl font-bold text-gray-600 bg-white border-2 border-gray-200 text-sm">
                ✕
              </button>
            )}
          </div>
        </form>

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-5 no-scrollbar">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setCatFilter(cat.id)}
              className={`shrink-0 text-xs font-bold px-4 py-2 rounded-full border-2 transition-all ${catFilter === cat.id ? "text-white border-transparent shadow" : "border-gray-200 text-gray-600 bg-white"}`}
              style={catFilter === cat.id ? { background: cat.color, borderColor: cat.color } : {}}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Stats row */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-gray-500 text-xs font-semibold">
            {loading ? "..." : `${total} doubts मिले`}
            {search && <span className="text-purple-600"> — "{search}"</span>}
          </p>
          <button
            onClick={() => user ? setShowNewModal(true) : setShowAuthModal(true)}
            className="text-xs font-black text-white px-4 py-2 rounded-xl shadow transition-all hover:scale-105"
            style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}
          >
            + नया Doubt
          </button>
        </div>

        {/* Doubts List */}
        {loading && doubts.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-5xl mb-3 animate-bounce">📚</div>
            <p className="text-gray-400 font-semibold">Doubts load हो रहे हैं...</p>
          </div>
        ) : doubts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl shadow-sm">
            <div className="text-6xl mb-4">🤔</div>
            <h3 className="font-black text-gray-700 text-xl mb-2">कोई Doubt नहीं मिला</h3>
            <p className="text-gray-400 text-sm mb-5">पहले doubt पूछने वाले बनें!</p>
            <button
              onClick={() => user ? setShowNewModal(true) : setShowAuthModal(true)}
              className="font-black text-white px-8 py-3 rounded-2xl shadow"
              style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}
            >
              📝 Doubt पूछें
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {doubts.map(post => (
              <DoubtCard
                key={post.id}
                post={post}
                currentUserId={user?.id}
                isCurrentUserAdmin={user?.isAdmin}
                onDelete={handleDeletePost}
              />
            ))}
          </div>
        )}

        {/* Load More */}
        {!loading && doubts.length < total && (
          <div className="text-center mt-5">
            <button
              onClick={handleLoadMore}
              className="font-bold text-sm px-8 py-3 rounded-2xl border-2 border-purple-300 text-purple-700 bg-white hover:bg-purple-50 transition-all"
            >
              और देखें ({total - doubts.length} बाकी)
            </button>
          </div>
        )}

        {loading && doubts.length > 0 && (
          <div className="text-center py-4 text-gray-400 text-sm">⏳ और load हो रहे हैं...</div>
        )}
      </div>

      {showNewModal && (
        <NewDoubtModal
          onClose={() => setShowNewModal(false)}
          onSuccess={() => { setPage(1); loadDoubts(catFilter, search, 1); }}
        />
      )}
    </div>
  );
}
