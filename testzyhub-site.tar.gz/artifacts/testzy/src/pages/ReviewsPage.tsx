import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

type Review = {
  id: number;
  rating: number;
  comment: string;
  user_name: string;
  level: string;
  created_at: string;
};

function StarRating({ value, onChange, readOnly = false }: { value: number; onChange?: (v: number) => void; readOnly?: boolean }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          disabled={readOnly}
          onClick={() => !readOnly && onChange?.(s)}
          onMouseEnter={() => !readOnly && setHovered(s)}
          onMouseLeave={() => !readOnly && setHovered(0)}
          className={`text-2xl transition-transform ${readOnly ? "cursor-default" : "cursor-pointer hover:scale-125"}`}
        >
          {s <= (hovered || value) ? "⭐" : "☆"}
        </button>
      ))}
    </div>
  );
}

function levelBadge(level: string) {
  const map: Record<string, string> = {
    Master: "bg-yellow-100 text-yellow-700",
    Pro: "bg-blue-100 text-blue-700",
    Intermediate: "bg-green-100 text-green-700",
    Beginner: "bg-gray-100 text-gray-600",
  };
  return map[level] || "bg-gray-100 text-gray-600";
}

export default function ReviewsPage() {
  const [, navigate] = useLocation();
  const { user, setShowAuthModal } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState<{ total: number; avg_rating: string }>({ total: 0, avg_rating: "0" });
  const [loading, setLoading] = useState(true);

  // Form state
  const [myRating, setMyRating] = useState(5);
  const [myComment, setMyComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formMsg, setFormMsg] = useState("");

  useEffect(() => {
    fetch("/api/reviews", { credentials: "include" })
      .then(r => r.json())
      .then(d => { setReviews(d.reviews || []); setStats(d.stats || { total: 0, avg_rating: "0" }); })
      .finally(() => setLoading(false));
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) { setShowAuthModal(true); return; }
    if (myComment.trim().length < 10) { setFormMsg("❌ कम से कम 10 अक्षर लिखें"); return; }
    setSubmitting(true);
    setFormMsg("");
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ rating: myRating, comment: myComment }),
      });
      const data = await res.json();
      if (data.success) { setSubmitted(true); setFormMsg(data.message); }
      else setFormMsg("❌ " + (data.error || "कुछ गलत हुआ"));
    } finally {
      setSubmitting(false);
    }
  }

  const avgRating = parseFloat(stats.avg_rating || "0");

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#1a3a6b] to-[#2563eb] text-white py-10 px-4 text-center mb-6">
        <div className="text-5xl mb-3">⭐</div>
        <h1 className="text-3xl font-black mb-2">User Reviews</h1>
        <p className="text-blue-200 text-sm mb-4">हमारे students का अनुभव</p>
        {stats.total > 0 && (
          <div className="flex items-center justify-center gap-4">
            <div className="bg-white/20 rounded-2xl px-5 py-3">
              <div className="text-4xl font-black">{avgRating.toFixed(1)}</div>
              <div className="flex justify-center mt-1">
                {[1,2,3,4,5].map(s => (
                  <span key={s} className="text-lg">{s <= Math.round(avgRating) ? "⭐" : "☆"}</span>
                ))}
              </div>
              <div className="text-blue-200 text-xs mt-1">{stats.total} reviews</div>
            </div>
          </div>
        )}
      </div>

      <div className="max-w-2xl mx-auto px-4">
        {/* Write Review Form */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-6 border border-gray-100">
          <h2 className="font-black text-[#1a3a6b] text-xl mb-4">✍️ अपना Review दें</h2>
          {submitted ? (
            <div className="text-center py-6">
              <div className="text-5xl mb-3">🙏</div>
              <p className="font-black text-green-700 text-lg">शुक्रिया!</p>
              <p className="text-gray-500 text-sm mt-1">{formMsg}</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Rating दें</label>
                <StarRating value={myRating} onChange={setMyRating} />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">अपना अनुभव लिखें</label>
                <textarea
                  value={myComment}
                  onChange={e => setMyComment(e.target.value)}
                  rows={4}
                  maxLength={500}
                  placeholder="TestzyHub के बारे में अपना अनुभव share करें... (कम से कम 10 अक्षर)"
                  className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3a6b] resize-none"
                />
                <p className="text-right text-xs text-gray-400 mt-1">{myComment.length}/500</p>
              </div>
              {formMsg && !submitted && <p className="text-red-600 text-sm font-semibold">{formMsg}</p>}
              <button
                type="submit"
                disabled={submitting}
                className="w-full btn-primary py-3 rounded-2xl font-black disabled:opacity-60"
              >
                {!user ? "Login करके Review दें" : submitting ? "⏳ Submit हो रहा है..." : "⭐ Review Submit करें"}
              </button>
            </form>
          )}
        </div>

        {/* Reviews List */}
        <h2 className="font-black text-[#1a3a6b] text-lg mb-4">📋 सभी Reviews ({stats.total})</h2>

        {loading ? (
          <div className="space-y-4">
            {[1,2,3].map(i => <div key={i} className="h-28 bg-white rounded-2xl animate-pulse border border-gray-100" />)}
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
            <div className="text-5xl mb-3">💬</div>
            <p className="text-gray-500 font-semibold">अभी कोई review नहीं है</p>
            <p className="text-gray-400 text-sm mt-1">पहले review देने वाले बनें!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {reviews.map(r => (
              <div key={r.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-black"
                        style={{ background: "linear-gradient(135deg, #1a3a6b, #2563eb)" }}>
                        {r.user_name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-black text-gray-800 text-sm">{r.user_name}</p>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${levelBadge(r.level)}`}>{r.level}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="flex gap-0.5">
                      {[1,2,3,4,5].map(s => <span key={s} className="text-sm">{s <= r.rating ? "⭐" : "☆"}</span>)}
                    </div>
                    <span className="text-xs text-gray-400 mt-0.5">{new Date(r.created_at).toLocaleDateString("hi-IN")}</span>
                  </div>
                </div>
                <p className="text-gray-700 text-sm leading-relaxed">"{r.comment}"</p>
              </div>
            ))}
          </div>
        )}

        <button onClick={() => navigate("/")} className="mt-8 text-[#1a3a6b]/60 hover:text-[#1a3a6b] text-sm text-center w-full">
          ← वापस Home
        </button>
      </div>
    </div>
  );
}
