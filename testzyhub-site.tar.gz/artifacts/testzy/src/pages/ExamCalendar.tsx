import { useState, useEffect } from "react";

const FILTERS = [
  { id: "all", label: "सभी Exams", icon: "📋" },
  { id: "ssc", label: "SSC", icon: "🏛️" },
  { id: "railway", label: "Railway", icon: "🚂" },
  { id: "police", label: "Police", icon: "👮" },
  { id: "banking", label: "Banking", icon: "🏦" },
];

const CAT_STYLE: Record<string, { bg: string; text: string; icon: string }> = {
  ssc: { bg: "#eff6ff", text: "#1d4ed8", icon: "🏛️" },
  railway: { bg: "#fef2f2", text: "#b91c1c", icon: "🚂" },
  police: { bg: "#f0fdf4", text: "#15803d", icon: "👮" },
  banking: { bg: "#fef9c3", text: "#a16207", icon: "🏦" },
  other: { bg: "#faf5ff", text: "#7c3aed", icon: "📌" },
};

type Exam = {
  id: number;
  name: string;
  category: string;
  exam_date: string;
  end_date?: string;
  type: string;
  description: string;
  seats: string;
  source_url: string;
};

function daysUntil(dateStr: string) {
  const d = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("hi-IN", { day: "numeric", month: "long", year: "numeric" });
}

export default function ExamCalendar() {
  const [filter, setFilter] = useState("all");
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("savedExams") || "[]"); } catch { return []; }
  });

  useEffect(() => {
    fetch("/api/exam-calendar/live")
      .then((r) => r.json())
      .then((d) => setExams(d.exams || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const filtered = filter === "all" ? exams : exams.filter((e) => e.category === filter);

  function toggleSave(name: string) {
    setSaved((prev) => {
      const next = prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name];
      localStorage.setItem("savedExams", JSON.stringify(next));
      return next;
    });
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="bg-gradient-to-r from-indigo-700 via-purple-700 to-pink-600 text-white px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-black">📅 Exam Calendar 2025</h1>
          <p className="text-white/80 text-sm mt-1">सरकारी websites से सीधी Exam Dates — हमेशा Updated</p>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="bg-white/15 border border-white/20 rounded-2xl p-3 text-center">
              <div className="text-2xl font-black">{exams.length}</div>
              <div className="text-xs text-white/70">Total Exams</div>
            </div>
            <div className="bg-white/15 border border-white/20 rounded-2xl p-3 text-center">
              <div className="text-2xl font-black">{saved.length}</div>
              <div className="text-xs text-white/70">Saved</div>
            </div>
            <div className="bg-white/15 border border-white/20 rounded-2xl p-3 text-center">
              <div className="text-2xl font-black">Live</div>
              <div className="text-xs text-white/70">🟢 Updated</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Official Source Banner */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 mb-5 flex items-start gap-3">
          <span className="text-2xl">🏛️</span>
          <div>
            <p className="font-bold text-emerald-800 text-sm">Official Sources से सीधी Dates</p>
            <p className="text-xs text-emerald-600 mt-0.5">
              SSC.nic.in • RRBs.in • IBPS.in • SBI Careers — सभी dates verified official websites से हैं।
              Exam की official website पर जाकर भी confirm करें।
            </p>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-bold transition-all ${
                filter === f.id ? "text-white shadow-md" : "bg-white text-gray-600 border border-gray-200 hover:border-purple-300"
              }`}
              style={filter === f.id ? { background: "linear-gradient(135deg, #6d28d9, #a855f7)" } : {}}
            >
              {f.icon} {f.label}
            </button>
          ))}
        </div>

        {saved.length > 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mb-6 flex items-center gap-3">
            <span className="text-2xl">⭐</span>
            <div>
              <p className="font-bold text-yellow-800 text-sm">{saved.length} Exam(s) Saved</p>
              <p className="text-xs text-yellow-600">आपने {saved.slice(0, 3).join(", ")}{saved.length > 3 ? ` +${saved.length - 3} more` : ""} save किया है</p>
            </div>
          </div>
        )}

        {loading ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-4xl mb-2 animate-spin">⏳</div>
            <p>Loading exam dates...</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filtered.map((exam) => {
              const days = daysUntil(exam.exam_date);
              const catStyle = CAT_STYLE[exam.category] || CAT_STYLE.other;
              const isSaved = saved.includes(exam.name);
              const urgency = days < 0 ? "⚫" : days <= 30 ? "🔴" : days <= 90 ? "🟡" : "🟢";
              return (
                <div key={exam.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-md transition-all">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-2">
                        <span className="text-xs font-bold px-2.5 py-1 rounded-full"
                          style={{ background: catStyle.bg, color: catStyle.text }}>
                          {catStyle.icon} {exam.category.toUpperCase()}
                        </span>
                        {exam.type && (
                          <span className="text-xs bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full font-semibold">
                            {exam.type}
                          </span>
                        )}
                        <span className="text-xs font-bold">{urgency}</span>
                        {exam.source_url && (
                          <a
                            href={exam.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 underline font-semibold"
                          >
                            🔗 Official Site
                          </a>
                        )}
                      </div>
                      <h3 className="font-black text-gray-800 text-lg">{exam.name}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">{exam.description}</p>
                      <div className="flex items-center gap-4 mt-3 flex-wrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-gray-400 text-xs">📅</span>
                          <span className="text-sm font-bold text-gray-700">
                            {formatDate(exam.exam_date)}
                            {exam.end_date && exam.end_date !== exam.exam_date && ` — ${formatDate(exam.end_date)}`}
                          </span>
                        </div>
                        {exam.seats && (
                          <div className="flex items-center gap-1.5">
                            <span className="text-gray-400 text-xs">💼</span>
                            <span className="text-sm font-semibold text-gray-600">{exam.seats} Seats</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className={`text-2xl font-black ${days < 0 ? "text-gray-400" : days <= 30 ? "text-red-600" : days <= 90 ? "text-yellow-600" : "text-green-600"}`}>
                        {days < 0 ? "Done" : days}
                      </div>
                      <div className="text-xs text-gray-400">{days < 0 ? "Completed" : "days left"}</div>
                      <button
                        onClick={() => toggleSave(exam.name)}
                        className={`mt-2 text-lg transition-all ${isSaved ? "text-yellow-500" : "text-gray-300 hover:text-yellow-400"}`}
                      >
                        {isSaved ? "⭐" : "☆"}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}

            {filtered.length === 0 && (
              <div className="text-center py-16 text-gray-400">
                <div className="text-4xl mb-2">📭</div>
                <p>कोई exam नहीं मिला</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
