import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

const FAQS = [
  {
    q: "TestzyHub क्या है?",
    a: "TestzyHub एक gamified government exam preparation platform है जहाँ आप SSC, Railway, Police, और Banking exams की free preparation कर सकते हैं। Daily Quiz, Mock Test, Battle Mode, और Weekly Mega Quiz जैसे features हैं।",
  },
  {
    q: "Account कैसे बनाएं?",
    a: "ऊपर 'साइनअप' button पर click करें, अपना नाम, email और password डालें। Free में account बन जाएगा और 50 coins welcome bonus मिलेगा!",
  },
  {
    q: "Weekly Mega Quiz में कैसे participate करें?",
    a: "हर शुक्रवार से रविवार 7:55 PM तक ₹10 entry fee देकर register करें। Sunday रात 8 बजे quiz शुरू होती है। Top 5 players को ₹300, ₹200, ₹100, ₹50, ₹25 cash prize मिलता है।",
  },
  {
    q: "XP और Coins क्या हैं?",
    a: "XP (Experience Points) आपका level बढ़ाते हैं — Beginner → Intermediate → Pro → Master। Coins एक virtual currency है। Quiz, Battle, Daily Quiz complete करने पर XP और Coins मिलते हैं।",
  },
  {
    q: "Mock Test में Sets कैसे unlock होते हैं?",
    a: "Mock Test sequential हैं — पहले Mock 1 complete करो, तभी Mock 2 unlock होगा। यह real exam practice के लिए designed है।",
  },
  {
    q: "1v1 Battle Mode कैसे खेलें?",
    a: "Battle section में जाएं, किसी opponent से match होगा, दोनों same questions solve करेंगे। जो जीता उसे ज़्यादा XP मिलेगा।",
  },
  {
    q: "Referral Code कैसे use करें?",
    a: "अपने Profile/Home पर 'Referral' section में जाएं। अपना unique code share करें। जब कोई आपके code से join करेगा, दोनों को +50 XP और +20 Coins मिलेंगे।",
  },
  {
    q: "Payment fail हो गई, क्या करें?",
    a: "अगर Mega Quiz registration के दौरान payment fail हुई और पैसे कट गए तो help query submit करें। हम 24 घंटों में solve करेंगे।",
  },
  {
    q: "Hindi के अलावा English में भी questions हैं?",
    a: "हाँ! Navbar में language switcher से Hindi/English toggle कर सकते हैं। Questions auto-translate होते हैं।",
  },
  {
    q: "App slow हो रहा है या crash हो रहा है, क्या करें?",
    a: "Browser refresh करें या cache clear करें। अगर problem बनी रहे तो नीचे query form में details भेजें।",
  },
];

export default function HelpCenter() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  // Form state
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitMsg, setSubmitMsg] = useState("");

  const filteredFaqs = FAQS.filter(f =>
    f.q.toLowerCase().includes(search.toLowerCase()) ||
    f.a.toLowerCase().includes(search.toLowerCase())
  );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !message.trim() || !subject.trim()) {
      setSubmitMsg("❌ सभी fields भरें");
      return;
    }
    setSubmitting(true);
    setSubmitMsg("");
    try {
      const res = await fetch("/api/help/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ name, email, subject, message }),
      });
      const data = await res.json();
      if (data.success) {
        setSubmitMsg(data.message);
        setSubject("");
        setMessage("");
      } else {
        setSubmitMsg("❌ " + (data.error || "कुछ गलत हुआ"));
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#1a3a6b] to-[#2563eb] text-white py-10 px-4 text-center mb-6">
        <div className="text-5xl mb-3">🛟</div>
        <h1 className="text-3xl font-black mb-2">Help Center</h1>
        <p className="text-blue-200 text-sm">कोई भी समस्या हो, हम यहाँ हैं!</p>
      </div>

      <div className="max-w-2xl mx-auto px-4">
        {/* Contact Cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {[
            { icon: "📧", label: "Email", val: "support@testzyhub.com", color: "bg-blue-50 border-blue-200" },
            { icon: "⏰", label: "Response Time", val: "24–48 घंटे", color: "bg-green-50 border-green-200" },
          ].map(c => (
            <div key={c.label} className={`${c.color} border-2 rounded-2xl p-4 text-center`}>
              <div className="text-3xl mb-1">{c.icon}</div>
              <div className="font-bold text-gray-700 text-sm">{c.label}</div>
              <div className="text-xs text-gray-500 mt-0.5 font-medium">{c.val}</div>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-6 border border-gray-100">
          <h2 className="font-black text-[#1a3a6b] text-xl mb-4">❓ अक्सर पूछे जाने वाले सवाल</h2>
          <div className="relative mb-4">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="सवाल खोजें..."
              className="w-full border-2 border-gray-200 rounded-2xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-[#1a3a6b]"
            />
          </div>

          <div className="space-y-2">
            {filteredFaqs.length === 0 ? (
              <p className="text-gray-400 text-sm text-center py-4">कोई सवाल नहीं मिला। नीचे query submit करें।</p>
            ) : filteredFaqs.map((faq, i) => (
              <div key={i} className="border border-gray-100 rounded-2xl overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-gray-50 transition-colors"
                >
                  <span className="font-semibold text-gray-800 text-sm pr-4">{faq.q}</span>
                  <span className="text-gray-400 flex-shrink-0 text-lg">{openFaq === i ? "▲" : "▼"}</span>
                </button>
                {openFaq === i && (
                  <div className="px-4 pb-4 text-sm text-gray-600 leading-relaxed border-t border-gray-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Query Form */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-6 border border-gray-100">
          <h2 className="font-black text-[#1a3a6b] text-xl mb-2">📩 Query भेजें</h2>
          <p className="text-gray-500 text-sm mb-4">ऊपर जवाब नहीं मिला? हमें directly message करें।</p>

          {submitMsg && submitMsg.startsWith("✅") ? (
            <div className="text-center py-8">
              <div className="text-5xl mb-3">📬</div>
              <p className="font-black text-green-700 text-lg">Query Submitted!</p>
              <p className="text-gray-500 text-sm mt-1">{submitMsg}</p>
              <button onClick={() => setSubmitMsg("")} className="mt-4 text-[#1a3a6b] text-sm font-semibold underline">
                एक और query भेजें
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1.5">आपका नाम *</label>
                  <input value={name} onChange={e => setName(e.target.value)} required
                    placeholder="नाम लिखें"
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a3a6b]" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1.5">Email</label>
                  <input value={email} onChange={e => setEmail(e.target.value)} type="email"
                    placeholder="email (optional)"
                    className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a3a6b]" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1.5">विषय *</label>
                <select value={subject} onChange={e => setSubject(e.target.value)} required
                  className="w-full border-2 border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a3a6b]">
                  <option value="">— विषय चुनें —</option>
                  <option>Payment / Refund Problem</option>
                  <option>Account Problem</option>
                  <option>Quiz / Test Problem</option>
                  <option>Mega Quiz Registration Issue</option>
                  <option>Technical Problem (Crash/Slow)</option>
                  <option>Suggestion / Feedback</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1.5">आपका message *</label>
                <textarea value={message} onChange={e => setMessage(e.target.value)} rows={5} required
                  placeholder="अपनी problem या query detail में लिखें..."
                  className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3a6b] resize-none"
                />
              </div>

              {submitMsg && !submitMsg.startsWith("✅") && (
                <p className="text-red-600 text-sm font-semibold">{submitMsg}</p>
              )}

              <button type="submit" disabled={submitting}
                className="w-full btn-primary py-3 rounded-2xl font-black disabled:opacity-60">
                {submitting ? "⏳ भेज रहे हैं..." : "📩 Query Submit करें"}
              </button>
            </form>
          )}
        </div>

        <button onClick={() => navigate("/")} className="text-[#1a3a6b]/60 hover:text-[#1a3a6b] text-sm text-center w-full">
          ← वापस Home
        </button>
      </div>
    </div>
  );
}
