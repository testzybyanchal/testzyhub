import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

type Stats = {
  total_quizzes: number;
  recent: { score: number; total_questions: number; category: string; subject: string; created_at: string }[];
  by_subject: { subject: string; attempts: string; accuracy: string }[];
  user: { xp: number; coins: number; level: string; streak_count: number; longest_streak: number };
  bookmarks_count: number;
};

type Achievement = { id: number; slug: string; title: string; description: string; icon: string; xp_reward: number };

const LEVEL_CONFIG: Record<string, { color: string; bg: string; icon: string; next: number; prev: number }> = {
  Beginner:     { color: "#6b7280", bg: "#f3f4f6", icon: "🌱", next: 200, prev: 0 },
  Intermediate: { color: "#0ea5e9", bg: "#e0f2fe", icon: "⚡", next: 500, prev: 200 },
  Pro:          { color: "#8b5cf6", bg: "#ede9fe", icon: "🔥", next: 1000, prev: 500 },
  Master:       { color: "#f59e0b", bg: "#fef3c7", icon: "👑", next: 9999, prev: 1000 },
};

export default function StatsPage() {
  const { user, setShowAuthModal } = useAuth();
  const [, navigate] = useLocation();
  const [stats, setStats] = useState<Stats | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [unlockedIds, setUnlockedIds] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"overview" | "achievements" | "history">("overview");

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    Promise.all([
      fetch("/api/my-stats", { credentials: "include" }).then(r => r.json()),
      fetch("/api/achievements", { credentials: "include" }).then(r => r.json()),
    ]).then(([s, a]) => {
      setStats(s);
      setAchievements(a.achievements || []);
      setUnlockedIds(a.unlocked || []);
    }).finally(() => setLoading(false));
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8">
          <div className="text-6xl mb-4">📊</div>
          <h2 className="text-xl font-black text-gray-800 mb-2">Login करें</h2>
          <p className="text-gray-500 text-sm mb-6">अपना performance देखने के लिए login करें</p>
          <button onClick={() => setShowAuthModal(true)} className="btn-primary px-8 py-3 rounded-2xl font-black">Login / Signup</button>
        </div>
      </div>
    );
  }

  const lvl = LEVEL_CONFIG[stats?.user?.level || "Beginner"] || LEVEL_CONFIG.Beginner;
  const xp = stats?.user?.xp || 0;
  const xpProgress = Math.min(100, ((xp - lvl.prev) / (lvl.next - lvl.prev)) * 100);
  const avgAccuracy = stats?.by_subject?.length
    ? Math.round(stats.by_subject.reduce((s, r) => s + parseFloat(r.accuracy || "0"), 0) / stats.by_subject.length)
    : 0;

  const weakSubjects = [...(stats?.by_subject || [])].sort((a, b) => parseFloat(a.accuracy) - parseFloat(b.accuracy)).slice(0, 3);
  const strongSubjects = [...(stats?.by_subject || [])].sort((a, b) => parseFloat(b.accuracy) - parseFloat(a.accuracy)).slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="text-white px-4 py-8" style={{ background: `linear-gradient(135deg, ${lvl.color}, ${lvl.color}88)` }}>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-black">📊 My Performance</h1>
              <p className="text-white/80 text-sm mt-0.5">{user.name} का Progress Dashboard</p>
            </div>
            <div className="text-5xl">{lvl.icon}</div>
          </div>
          {/* XP Bar */}
          <div className="bg-white/20 rounded-2xl p-4">
            <div className="flex justify-between text-sm font-bold mb-2">
              <span>{stats?.user?.level || "Beginner"}</span>
              <span>{xp} / {lvl.next} XP</span>
            </div>
            <div className="h-3 bg-white/30 rounded-full overflow-hidden">
              <div className="h-full rounded-full bg-white transition-all duration-700"
                style={{ width: `${xpProgress}%` }} />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {[
            { label: "Total Quizzes", val: stats?.total_quizzes || 0, icon: "📝", color: "#6d28d9" },
            { label: "Avg Accuracy", val: `${avgAccuracy}%`, icon: "🎯", color: "#059669" },
            { label: "🔥 Streak", val: `${stats?.user?.streak_count || 0} days`, icon: "🔥", color: "#f97316" },
            { label: "Bookmarks", val: stats?.bookmarks_count || 0, icon: "🔖", color: "#0ea5e9" },
          ].map((s) => (
            <div key={s.label} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 text-center hover:shadow-md transition-all">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="text-xl font-black" style={{ color: s.color }}>{s.val}</div>
              <div className="text-xs text-gray-400 font-semibold mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tab Nav */}
        <div className="flex gap-1 bg-gray-100 rounded-2xl p-1 mb-6">
          {(["overview", "achievements", "history"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all capitalize ${tab === t ? "bg-white shadow-md text-purple-700" : "text-gray-500 hover:text-gray-700"}`}>
              {t === "overview" ? "📈 Overview" : t === "achievements" ? "🏅 Badges" : "📋 History"}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12 text-gray-400"><div className="text-4xl mb-2">⏳</div><p>Loading...</p></div>
        ) : tab === "overview" ? (
          <div className="space-y-5">
            {/* Subject Accuracy */}
            {stats?.by_subject && stats.by_subject.length > 0 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                <h3 className="font-black text-gray-800 mb-4">📚 Subject-wise Accuracy</h3>
                <div className="space-y-3">
                  {stats.by_subject.map((s) => {
                    const acc = parseFloat(s.accuracy);
                    const color = acc >= 70 ? "#10b981" : acc >= 50 ? "#f59e0b" : "#ef4444";
                    return (
                      <div key={s.subject}>
                        <div className="flex justify-between text-sm font-semibold mb-1">
                          <span className="text-gray-700 capitalize">{s.subject}</span>
                          <span style={{ color }} className="font-black">{acc}%</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${acc}%`, background: color }} />
                        </div>
                        <p className="text-xs text-gray-400 mt-0.5">{s.attempts} attempts</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Weak vs Strong */}
            {weakSubjects.length > 0 && (
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
                  <h4 className="font-black text-red-700 mb-3">⚠️ कमज़ोर Subjects</h4>
                  {weakSubjects.map((s) => (
                    <div key={s.subject} className="flex justify-between items-center py-1.5 border-b border-red-100 last:border-0">
                      <span className="text-sm text-gray-700 capitalize">{s.subject}</span>
                      <span className="text-sm font-black text-red-600">{s.accuracy}%</span>
                    </div>
                  ))}
                  <button onClick={() => navigate("/practice")} className="mt-3 w-full py-2 rounded-xl bg-red-600 text-white text-xs font-black">
                    इन्हें Practice करें →
                  </button>
                </div>
                <div className="bg-green-50 border border-green-100 rounded-2xl p-4">
                  <h4 className="font-black text-green-700 mb-3">💪 मज़बूत Subjects</h4>
                  {strongSubjects.map((s) => (
                    <div key={s.subject} className="flex justify-between items-center py-1.5 border-b border-green-100 last:border-0">
                      <span className="text-sm text-gray-700 capitalize">{s.subject}</span>
                      <span className="text-sm font-black text-green-600">{s.accuracy}%</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Coins & Streak */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-yellow-50 border border-yellow-100 rounded-2xl p-4 text-center">
                <div className="text-3xl mb-1">🪙</div>
                <div className="text-2xl font-black text-yellow-700">{stats?.user?.coins || 0}</div>
                <div className="text-xs text-yellow-600 font-semibold">Total Coins</div>
              </div>
              <div className="bg-orange-50 border border-orange-100 rounded-2xl p-4 text-center">
                <div className="text-3xl mb-1">🏆</div>
                <div className="text-2xl font-black text-orange-700">{stats?.user?.longest_streak || 0}</div>
                <div className="text-xs text-orange-600 font-semibold">Best Streak</div>
              </div>
            </div>

            {(!stats?.by_subject || stats.by_subject.length === 0) && (
              <div className="text-center py-12 text-gray-400">
                <div className="text-4xl mb-2">📝</div>
                <p className="font-semibold text-gray-500">अभी कोई quiz नहीं किया</p>
                <button onClick={() => navigate("/practice")} className="mt-4 btn-primary px-6 py-2.5 rounded-2xl font-bold text-sm">
                  Practice शुरू करें →
                </button>
              </div>
            )}
          </div>
        ) : tab === "achievements" ? (
          <div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {achievements.map((ach) => {
                const isUnlocked = unlockedIds.includes(ach.id);
                return (
                  <div key={ach.id} className={`rounded-2xl border p-4 text-center transition-all ${isUnlocked ? "bg-white shadow-md border-yellow-200" : "bg-gray-50 border-gray-200 opacity-60"}`}>
                    <div className={`text-4xl mb-2 ${!isUnlocked ? "grayscale" : ""}`}>{ach.icon}</div>
                    <h4 className={`font-black text-sm ${isUnlocked ? "text-gray-800" : "text-gray-400"}`}>{ach.title}</h4>
                    <p className="text-xs text-gray-400 mt-1">{ach.description}</p>
                    {ach.xp_reward > 0 && (
                      <span className={`mt-2 inline-block text-xs font-bold px-2 py-0.5 rounded-full ${isUnlocked ? "bg-yellow-100 text-yellow-700" : "bg-gray-100 text-gray-400"}`}>
                        +{ach.xp_reward} XP
                      </span>
                    )}
                    {isUnlocked && <div className="mt-1 text-xs text-green-600 font-bold">✅ Unlocked!</div>}
                  </div>
                );
              })}
            </div>
            <p className="text-center text-sm text-gray-400 mt-4">{unlockedIds.length} / {achievements.length} badges unlocked</p>
          </div>
        ) : (
          <div>
            {(!stats?.recent || stats.recent.length === 0) ? (
              <div className="text-center py-12 text-gray-400">
                <div className="text-4xl mb-2">📋</div>
                <p>कोई history नहीं</p>
              </div>
            ) : (
              <div className="space-y-3">
                {stats.recent.map((r, i) => {
                  const acc = r.total_questions > 0 ? Math.round((r.score / r.total_questions) * 100) : 0;
                  const color = acc >= 70 ? "#10b981" : acc >= 50 ? "#f59e0b" : "#ef4444";
                  return (
                    <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black text-sm shrink-0"
                        style={{ background: color }}>
                        {acc}%
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-gray-800 text-sm capitalize">{r.subject || r.category || "Quiz"}</p>
                        <p className="text-xs text-gray-400">{r.score}/{r.total_questions} correct • {new Date(r.created_at).toLocaleDateString("hi-IN")}</p>
                      </div>
                      <div className="text-2xl">{acc >= 80 ? "🎯" : acc >= 60 ? "👍" : "📖"}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
