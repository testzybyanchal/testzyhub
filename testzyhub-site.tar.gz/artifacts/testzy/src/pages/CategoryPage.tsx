import { useLocation, useParams } from "wouter";
import { categories, getQuestionsByCategory } from "@/data/questions";
import { useAuth } from "@/contexts/AuthContext";

export default function CategoryPage() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user, setShowAuthModal } = useAuth();
  const category = categories.find((c) => c.id === params.id);
  const questions = getQuestionsByCategory(params.id);

  function requireAuth(path: string) {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    navigate(path);
  }

  if (!category) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-2xl font-bold text-gray-800 mb-4">Category नहीं मिली</p>
          <button onClick={() => navigate("/")} className="btn-primary px-6 py-2.5 rounded-xl">
            Home जाएं
          </button>
        </div>
      </div>
    );
  }

  const modes = [
    {
      icon: "📚",
      title: "Practice Test",
      subtitle: "अभ्यास मोड",
      desc: "एक-एक प्रश्न बिना दबाव के। सही/गलत तुरंत पता चलेगा। व्याख्या भी मिलेगी।",
      features: ["✅ तुरंत feedback", "💡 Explanation", "⭐ Point system", "⏱️ Timer के साथ"],
      path: `/practice?category=${category.id}`,
      gradient: "linear-gradient(135deg, #1a3a6b, #2c5aa0)",
      badge: `${questions.length} Questions`,
    },
    {
      icon: "⏱️",
      title: "Mock Test",
      subtitle: "Exam Simulation",
      desc: "असली exam जैसा माहौल। 45 मिनट में 120 questions। 95% सही करने पर prize!",
      features: ["🏆 Prize for 95%+", "45 min timer", "⭐ Point system", "📊 Detailed result"],
      path: `/mock-test?category=${category.id}`,
      gradient: "linear-gradient(135deg, #059669, #10b981)",
      badge: "45 Min",
    },
    {
      icon: "⚡",
      title: "Category Quiz",
      subtitle: "Quick Quiz",
      desc: "इस category से 10 mixed questions। Speed और accuracy दोनों को test करें।",
      features: ["10 questions", "⭐ Points मिलेंगे", "🎯 Category focused", "⚡ Quick round"],
      path: `/quiz?category=${category.id}`,
      gradient: "linear-gradient(135deg, #f97316, #ea580c)",
      badge: "10 Q",
    },
  ];

  return (
    <div className="min-h-screen" style={{ background: "var(--gray-50)" }}>
      {/* Header */}
      <div
        className="py-10 px-4 text-white relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, #0f2548, ${category.color})` }}
      >
        <div className="max-w-4xl mx-auto relative z-10">
          <button
            onClick={() => navigate("/")}
            className="text-white/70 hover:text-white text-sm mb-5 flex items-center gap-1"
          >
            ← Home
          </button>
          <div className="flex items-center gap-5">
            <div
              className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl shadow-xl"
              style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(10px)" }}
            >
              {category.icon}
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-black mb-1">{category.name}</h1>
              <p className="text-white/80 text-sm mb-2">{category.description}</p>
              <div className="flex gap-2">
                <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-semibold">
                  {questions.length} Questions
                </span>
                <span className="bg-orange-500/80 px-3 py-1 rounded-full text-xs font-semibold">
                  ⭐ Point System
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Mode Cards */}
      <div className="max-w-4xl mx-auto px-4 py-10">
        <h2 className="text-2xl font-black text-[#1a3a6b] mb-2 text-center">Practice Mode चुनें</h2>
        <p className="text-gray-500 text-center mb-8">तीनों modes में points मिलेंगे</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {modes.map((mode) => (
            <div
              key={mode.title}
              className="bg-white rounded-3xl shadow-md overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow cursor-pointer group"
              onClick={() => requireAuth(mode.path)}
            >
              {/* Top gradient bar */}
              <div className="h-2" style={{ background: mode.gradient }} />

              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-4xl">{mode.icon}</div>
                  <span
                    className="text-xs font-bold px-2.5 py-1 rounded-full text-white"
                    style={{ background: mode.gradient }}
                  >
                    {mode.badge}
                  </span>
                </div>

                <h3 className="font-black text-gray-800 text-xl mb-0.5">{mode.title}</h3>
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
                  {mode.subtitle}
                </p>
                <p className="text-gray-500 text-sm leading-relaxed mb-4">{mode.desc}</p>

                <div className="space-y-1.5 mb-5">
                  {mode.features.map((f) => (
                    <div key={f} className="text-xs text-gray-600 flex items-center gap-1.5">
                      <span>{f}</span>
                    </div>
                  ))}
                </div>

                <button
                  className="w-full py-3 rounded-xl font-bold text-sm text-white group-hover:opacity-90 transition-all"
                  style={{ background: mode.gradient }}
                >
                  Start Now →
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Point system explainer */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-2xl p-5">
          <h4 className="font-bold text-[#1a3a6b] mb-3">📊 Point System</h4>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="bg-green-100 rounded-xl p-3">
              <div className="text-2xl font-black text-green-700">+1</div>
              <div className="text-xs text-green-600 font-semibold">सही उत्तर</div>
            </div>
            <div className="bg-red-100 rounded-xl p-3">
              <div className="text-2xl font-black text-red-700">-0.5</div>
              <div className="text-xs text-red-600 font-semibold">गलत उत्तर</div>
            </div>
            <div className="bg-gray-100 rounded-xl p-3">
              <div className="text-2xl font-black text-gray-700">0</div>
              <div className="text-xs text-gray-600 font-semibold">छोड़ा गया</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
