import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { categories, getMockTestQuestions, type Question } from "@/data/questions";
import { fetchDBQuestions } from "@/hooks/useQuestions";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTranslatedQuestion } from "@/hooks/useTranslatedQuestion";
import { useAntiCheat } from "@/hooks/useAntiCheat";

const MOCK_TOTAL_TIME = 45 * 60;

type MockSet = { set_number: number; question_count: number };

export default function MockTest() {
  const [location, navigate] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const categoryId = searchParams.get("category") || "";
  const { user, setShowAuthModal, refreshUser } = useAuth();
  const { t } = useLanguage();

  const [selectedCat, setSelectedCat] = useState(categoryId || "ssc");
  const [selectedSet, setSelectedSet] = useState(1);
  const [mockSets, setMockSets] = useState<MockSet[]>([]);
  const [completedSets, setCompletedSets] = useState<number[]>([]);
  const [loadingSets, setLoadingSets] = useState(false);
  const [started, setStarted] = useState(false);
  const [starting, setStarting] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [timeLeft, setTimeLeft] = useState(MOCK_TOTAL_TIME);
  const [finished, setFinished] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [rewards, setRewards] = useState<{ xp: number; coins: number } | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tq = useTranslatedQuestion(questions[currentIdx] ?? null);

  // Load available mock sets for selected category
  useEffect(() => {
    setLoadingSets(true);
    fetch(`/api/quiz/mock-sets?category=${selectedCat}&type=mock`, { credentials: "include" })
      .then(r => r.json())
      .then(data => {
        setMockSets(data.sets || []);
        setCompletedSets(data.completedSets || []);
        const firstNotDone = (data.sets || []).find((s: MockSet) => !(data.completedSets || []).includes(s.set_number));
        if (firstNotDone) setSelectedSet(firstNotDone.set_number);
        else if (data.sets?.[0]) setSelectedSet(data.sets[0].set_number);
      })
      .catch(() => {})
      .finally(() => setLoadingSets(false));
  }, [selectedCat, user]);

  const handleViolation = useCallback(() => {
    clearInterval(timerRef.current!);
    setFinished(true);
  }, []);

  const { warning: antiCheatWarning } = useAntiCheat({
    isActive: started && !finished,
    onViolation: handleViolation,
  });

  const category = categories.find((c) => c.id === selectedCat);
  const isSetCompleted = (setNum: number) => completedSets.includes(setNum);
  const isSetLocked = (setNum: number, idx: number) => {
    // First set always unlocked; set N locked if set N-1 not completed
    if (idx === 0) return false;
    const prevSet = mockSets[idx - 1];
    return !completedSets.includes(prevSet.set_number);
  };

  async function startTest() {
    if (!user) { setShowAuthModal(true); return; }
    setStarting(true);
    const dbQs = await fetchDBQuestions(selectedCat, "mock", selectedSet);
    const staticQs = getMockTestQuestions(selectedCat);
    const qs = dbQs.length > 0 ? dbQs : staticQs;
    setQuestions(qs);
    setCurrentIdx(0);
    setAnswers(new Array(qs.length).fill(null));
    setTimeLeft(MOCK_TOTAL_TIME);
    setFinished(false);
    setSubmitted(false);
    setStarting(false);
    setStarted(true);
  }

  useEffect(() => {
    if (!started || finished) return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          setFinished(true);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [started, finished]);

  function handleSelect(idx: number) {
    if (answers[currentIdx] !== null) return;
    const newAnswers = [...answers];
    newAnswers[currentIdx] = idx;
    setAnswers(newAnswers);
  }

  function handleNext() {
    if (currentIdx + 1 >= questions.length) {
      clearInterval(timerRef.current!);
      setFinished(true);
    } else {
      setCurrentIdx((i) => i + 1);
    }
  }

  const correctCount = answers.filter((a, i) => a !== null && a === questions[i]?.correct).length;
  const wrongCount = answers.filter((a, i) => a !== null && a !== questions[i]?.correct).length;

  async function submitResult() {
    if (submitted || !user) return;
    setSubmitted(true);
    try {
      const res = await fetch("/api/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          quizType: "mock",
          category: selectedCat,
          correctCount,
          wrongCount,
          totalQuestions: questions.length,
          setNumber: selectedSet,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (data.xpEarned !== undefined) setRewards({ xp: data.xpEarned, coins: data.coinsEarned || 0 });
      // Mark set as completed locally
      setCompletedSets(prev => prev.includes(selectedSet) ? prev : [...prev, selectedSet]);
      await refreshUser();
    } catch {}
  }

  useEffect(() => {
    if (finished) submitResult();
  }, [finished]);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  if (!started) {
    const selectedSetLocked = mockSets.findIndex(s => s.set_number === selectedSet) > 0
      && isSetLocked(selectedSet, mockSets.findIndex(s => s.set_number === selectedSet));

    return (
      <div className="min-h-screen px-4 pb-20 lg:pb-4 pt-6" style={{ background: "var(--gray-50)" }}>
        <div className="max-w-lg mx-auto">
          <button onClick={() => navigate("/")} className="text-gray-500 text-sm mb-4 flex items-center gap-1">← वापस</button>

          <div className="bg-white rounded-3xl shadow-xl p-6 mb-4">
            <div className="text-center mb-5">
              <div className="text-4xl mb-2">⏱️</div>
              <h2 className="text-2xl font-black text-[#1a3a6b] mb-1">Mock Test</h2>
              <p className="text-gray-500 text-sm">एक complete करो, अगला unlock होगा</p>
            </div>

            {/* Category */}
            <div className="mb-4">
              <label className="block text-sm font-bold text-gray-700 mb-2">Category चुनें</label>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((c) => (
                  <button key={c.id} onClick={() => setSelectedCat(c.id)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold border-2 transition-all ${selectedCat === c.id ? "text-white border-transparent" : "border-gray-200 text-gray-600"}`}
                    style={selectedCat === c.id ? { background: c.color } : {}}>
                    {c.icon} {c.name.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Mock Sets Grid */}
            <div className="mb-4">
              <label className="block text-sm font-bold text-gray-700 mb-2">
                Mock Test चुनें
                {loadingSets && <span className="ml-2 text-xs text-gray-400 font-normal animate-pulse">loading...</span>}
              </label>
              {mockSets.length === 0 && !loadingSets ? (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-center text-sm text-blue-700">
                  <p className="font-bold mb-1">📭 अभी कोई Mock Test नहीं है</p>
                  <p className="text-xs text-blue-600">Admin जल्द ही Mock Tests upload करेंगे।</p>
                  <p className="text-xs text-gray-500 mt-2">तब तक Sample Test दे सकते हैं →</p>
                </div>
              ) : mockSets.length === 0 && loadingSets ? (
                <div className="grid grid-cols-3 gap-2">
                  {[1,2,3].map(i => <div key={i} className="h-20 bg-gray-100 rounded-xl animate-pulse" />)}
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {mockSets.map((s, idx) => {
                    const locked = isSetLocked(s.set_number, idx);
                    const done = isSetCompleted(s.set_number);
                    const active = selectedSet === s.set_number;
                    return (
                      <button
                        key={s.set_number}
                        onClick={() => !locked && setSelectedSet(s.set_number)}
                        disabled={locked}
                        className={`relative rounded-xl p-3 text-center border-2 transition-all ${
                          locked ? "border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed" :
                          active ? "border-blue-500 bg-blue-50" :
                          done ? "border-green-300 bg-green-50" :
                          "border-gray-200 hover:border-blue-300 bg-white"
                        }`}
                      >
                        <div className="text-xl mb-0.5">{locked ? "🔒" : done ? "✅" : "📝"}</div>
                        <div className={`text-xs font-black ${active ? "text-blue-700" : done ? "text-green-700" : locked ? "text-gray-400" : "text-gray-700"}`}>
                          Mock {s.set_number}
                        </div>
                        <div className="text-[10px] text-gray-400">{s.question_count}Q</div>
                        {active && !locked && (
                          <div className="absolute -top-1.5 -right-1.5 bg-blue-500 text-white text-[9px] font-black rounded-full px-1.5 py-0.5">SELECT</div>
                        )}
                      </button>
                    );
                  })}
                  {/* Sample Test fallback */}
                  {mockSets.length === 0 && (
                    <button onClick={() => setSelectedSet(1)} className="col-span-3 border-2 border-dashed border-blue-300 rounded-xl p-3 text-center text-sm text-blue-600 font-semibold">
                      📝 Sample Test (Static Questions)
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="bg-[#1a3a6b]/5 border border-[#1a3a6b]/20 rounded-xl p-3 mb-4 space-y-1 text-xs">
              <div className="flex items-center gap-2 text-[#1a3a6b] font-semibold">⏱️ 45 मिनट का टाइमर</div>
              <div className="flex items-center gap-2 text-green-700 font-semibold">⭐ +1 सही, -0.5 गलत</div>
              <div className="flex items-center gap-2 text-gray-600">🔓 एक complete करो → अगला unlock होगा</div>
            </div>

            <button
              onClick={!user ? () => setShowAuthModal(true) : startTest}
              disabled={starting || selectedSetLocked}
              className="w-full btn-primary py-4 rounded-2xl text-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {!user ? "Login करके शुरू करें" :
               starting ? "⏳ प्रश्न लोड हो रहे हैं..." :
               selectedSetLocked ? "🔒 पहले पिछला Mock Test complete करें" :
               `Mock ${selectedSet} शुरू करें 🚀`}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (finished) {
    const pct = Math.round((correctCount / questions.length) * 100);
    const points = Math.max(0, correctCount - wrongCount * 0.5);
    const won95 = pct >= 95;

    return (
      <div className="min-h-screen px-4 py-8 pb-20 lg:pb-8" style={{ background: "var(--gray-50)" }}>
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 mb-5 text-center fade-in-up">
            {won95 ? (
              <div className="bg-gradient-to-br from-yellow-400 to-orange-400 text-white rounded-2xl p-5 mb-4">
                <div className="text-4xl mb-2">🏆</div>
                <div className="text-2xl font-black">Congratulations!</div>
                <div className="text-sm opacity-90">आपने 95%+ हासिल किया! Prize जीत गए!</div>
              </div>
            ) : (
              <div className="text-5xl mb-3">{pct >= 80 ? "🎉" : pct >= 60 ? "👍" : "📚"}</div>
            )}

            <h2 className="text-2xl font-black text-[#1a3a6b] mb-4">Mock Test Result</h2>

            <div className="bg-gradient-to-br from-[#1a3a6b] to-[#2c5aa0] text-white rounded-2xl p-6 mb-5">
              <div className="text-5xl font-black mb-1">{pct}%</div>
              <div className="text-blue-200">{correctCount}/{questions.length} सही • +{points.toFixed(1)} Points</div>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-5 text-sm">
              <div className="bg-green-50 rounded-xl p-3">
                <div className="font-black text-green-700 text-xl">{correctCount}</div>
                <div className="text-green-600">सही</div>
              </div>
              <div className="bg-red-50 rounded-xl p-3">
                <div className="font-black text-red-700 text-xl">{wrongCount}</div>
                <div className="text-red-600">गलत</div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <div className="font-black text-gray-700 text-xl">{answers.filter(a => a === null).length}</div>
                <div className="text-gray-500">छोड़े</div>
              </div>
            </div>

            {!won95 && (
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 mb-4 text-sm text-orange-700">
                🎯 95% सही करने पर Prize मिलेगा! और मेहनत करें।
              </div>
            )}

            {rewards && (
              <div className="flex gap-3 mb-4">
                <div className="flex-1 bg-purple-50 border border-purple-200 rounded-2xl p-3 text-center">
                  <div className="font-black text-purple-700 text-2xl">+{rewards.xp}</div>
                  <div className="text-purple-500 text-xs font-semibold">XP मिले ⚡</div>
                </div>
                <div className="flex-1 bg-yellow-50 border border-yellow-200 rounded-2xl p-3 text-center">
                  <div className="font-black text-yellow-700 text-2xl">+{rewards.coins}</div>
                  <div className="text-yellow-500 text-xs font-semibold">Coins 🪙</div>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              {/* Show "Next Mock" if available */}
              {(() => {
                const nextSet = mockSets.find(s => s.set_number === selectedSet + 1);
                if (nextSet) {
                  return (
                    <button
                      onClick={() => { setSelectedSet(nextSet.set_number); setStarted(false); setFinished(false); setSubmitted(false); setRewards(null); }}
                      className="flex-1 py-3 rounded-xl font-bold text-white"
                      style={{ background: "linear-gradient(135deg, #059669, #10b981)" }}
                    >
                      ✅ Mock {nextSet.set_number} →
                    </button>
                  );
                }
                return <button onClick={() => { setStarted(false); setFinished(false); setSubmitted(false); setRewards(null); }} className="flex-1 btn-primary py-3 rounded-xl">🔄 फिर खेलें</button>;
              })()}
              <button onClick={() => navigate("/")} className="flex-1 bg-gray-100 text-gray-700 font-semibold py-3 rounded-xl">🏠 Home</button>
            </div>
          </div>

          {/* Answer Review */}
          <h3 className="font-black text-[#1a3a6b] text-lg mb-3">📋 उत्तर समीक्षा</h3>
          {questions.map((q, qi) => (
            <div key={qi} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-3">
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs text-gray-400 font-semibold">Q{qi + 1}</span>
                {answers[qi] === q.correct ? (
                  <span className="text-green-600 font-bold text-xs bg-green-50 px-2 py-0.5 rounded-full">✓ सही</span>
                ) : answers[qi] === null ? (
                  <span className="text-gray-400 font-bold text-xs bg-gray-50 px-2 py-0.5 rounded-full">— छोड़ा</span>
                ) : (
                  <span className="text-red-600 font-bold text-xs bg-red-50 px-2 py-0.5 rounded-full">✗ गलत</span>
                )}
              </div>
              <p className="text-gray-700 text-sm font-medium mb-2">{q.question}</p>
              <p className="text-xs text-green-700 font-semibold">✅ {q.options[q.correct]}</p>
              {answers[qi] !== null && answers[qi] !== q.correct && (
                <p className="text-xs text-red-600">❌ आपका: {q.options[answers[qi]!]}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  const current = questions[currentIdx];
  const timerUrgent = timeLeft <= 120;

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {antiCheatWarning && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center bg-red-900/90 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-8 max-w-sm mx-4 text-center shadow-2xl">
            <div className="text-5xl mb-3">⚠️</div>
            <h3 className="text-xl font-black text-red-600 mb-2">Tab Switch Detected!</h3>
            <p className="text-gray-700 text-sm mb-3">
              Quiz में cheating की कोशिश पकड़ी गई।<br />
              <strong>Quiz अपने आप Submit हो रहा है...</strong>
            </p>
            <div className="w-full bg-red-100 rounded-full h-2 mt-3">
              <div className="bg-red-500 h-2 rounded-full animate-pulse" style={{ width: "100%" }} />
            </div>
          </div>
        </div>
      )}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-[#1a3a6b] text-sm">{category?.icon} Mock Test</span>
            <div className={`font-mono font-bold text-lg px-4 py-1 rounded-lg ${timerUrgent ? "timer-urgent bg-red-50" : "text-[#1a3a6b] bg-blue-50"}`}>
              ⏱ {formatTime(timeLeft)}
            </div>
            <span className="text-sm text-gray-500 font-semibold">{currentIdx + 1}/{questions.length}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="progress-bar h-2 rounded-full" style={{ width: `${((currentIdx + 1) / questions.length) * 100}%`, background: "linear-gradient(90deg, #059669, #10b981)" }} />
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 fade-in-up" key={currentIdx}>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-4">
          <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest mb-3">
            {t("questionNo")} {currentIdx + 1}
            {tq?.isTranslating && <span className="ml-2 text-emerald-300 text-[10px] font-normal animate-pulse">{t("translating")}</span>}
          </div>
          <p className="text-gray-800 font-semibold text-lg leading-relaxed">{tq?.translatedQuestion ?? current.question}</p>
        </div>

        <div className="flex flex-col gap-3">
          {current.options.map((opt, idx) => {
            const answered = answers[currentIdx] !== null;
            let cls = "option-btn w-full text-left px-5 py-4 rounded-2xl font-medium text-gray-700 bg-white";
            if (answered) {
              if (idx === current.correct) cls += " correct";
              else if (idx === answers[currentIdx]) cls += " wrong";
              else cls += " border-gray-100 opacity-50";
            }
            return (
              <button key={idx} className={cls} onClick={() => handleSelect(idx)} disabled={answered}>
                <span className="inline-flex items-center gap-3">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0 ${
                    answered && idx === current.correct ? "bg-emerald-500 text-white" :
                    answered && idx === answers[currentIdx] ? "bg-red-500 text-white" :
                    "text-gray-500"
                  }`} style={!answered || (idx !== current.correct && idx !== answers[currentIdx]) ? { background: "rgba(5,150,105,0.1)" } : {}}>
                    {["A","B","C","D"][idx]}
                  </span>
                  {tq?.translatedOptions?.[idx] ?? opt}
                </span>
              </button>
            );
          })}
        </div>

        {answers[currentIdx] !== null && (
          <button onClick={handleNext} className="mt-4 w-full py-4 rounded-2xl text-lg font-bold text-white fade-in-up" style={{ background: "linear-gradient(135deg, #059669, #10b981)" }}>
            {currentIdx + 1 >= questions.length ? "✅ Result देखें" : "अगला →"}
          </button>
        )}
      </div>
    </div>
  );
}
