import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";

const SUBJECTS = [
  { id: "gk", label: "सामान्य ज्ञान", icon: "🌍", color: "#1d4ed8", bg: "#eff6ff",
    topics: [
      { title: "भारत के राज्य और राजधानियाँ", content: "भारत में 28 राज्य और 8 केंद्र शासित प्रदेश हैं।\n\n• उत्तर प्रदेश → लखनऊ\n• महाराष्ट्र → मुंबई\n• राजस्थान → जयपुर\n• मध्य प्रदेश → भोपाल\n• गुजरात → गांधीनगर\n• कर्नाटक → बेंगलुरु\n• तमिलनाडु → चेन्नई\n• पश्चिम बंगाल → कोलकाता\n• आंध्र प्रदेश → अमरावती\n• तेलंगाना → हैदराबाद" },
      { title: "भारत के प्रमुख संस्थान", content: "• सर्वोच्च न्यायालय → नई दिल्ली\n• संसद → नई दिल्ली\n• RBI → मुंबई\n• ISRO → बेंगलुरु\n• DRDO → नई दिल्ली\n• IIT (पहला) → खड़गपुर (1951)\n• IIM (पहला) → कलकत्ता (1961)\n• AIIMS → नई दिल्ली\n• NDA → खड़कवासला, पुणे" },
      { title: "प्रमुख नदियाँ और उद्गम", content: "• गंगा → गंगोत्री, उत्तराखंड\n• यमुना → यमुनोत्री, उत्तराखंड\n• ब्रह्मपुत्र → तिब्बत (माना सरोवर)\n• गोदावरी → नासिक, महाराष्ट्र\n• कृष्णा → पश्चिमी घाट, महाबलेश्वर\n• नर्मदा → अमरकंटक, MP\n• सिंधु → तिब्बत (मानसरोवर)\n• कावेरी → कोडागु, कर्नाटक" },
      { title: "भारतीय इतिहास — महत्वपूर्ण वर्ष", content: "• 1857 → प्रथम स्वतंत्रता संग्राम\n• 1885 → कांग्रेस की स्थापना\n• 1905 → बंगाल विभाजन\n• 1919 → जलियांवाला बाग हत्याकांड\n• 1920 → असहयोग आंदोलन\n• 1930 → सविनय अवज्ञा आंदोलन / दांडी मार्च\n• 1942 → भारत छोड़ो आंदोलन\n• 1947 → स्वतंत्रता (15 अगस्त)\n• 1950 → गणतंत्र (26 जनवरी)\n• 1952 → पहले आम चुनाव" },
    ],
  },
  { id: "math", label: "गणित", icon: "🔢", color: "#d97706", bg: "#fffbeb",
    topics: [
      { title: "महत्वपूर्ण सूत्र — क्षेत्रफल और परिमाप", content: "त्रिभुज:\n• क्षेत्रफल = ½ × आधार × ऊँचाई\n\nआयत:\n• क्षेत्रफल = लंबाई × चौड़ाई\n• परिमाप = 2(l + b)\n\nवर्ग:\n• क्षेत्रफल = भुजा²\n• परिमाप = 4 × भुजा\n\nवृत्त:\n• क्षेत्रफल = πr²\n• परिधि = 2πr" },
      { title: "प्रतिशत और लाभ-हानि", content: "• प्रतिशत = (भाग/पूर्ण) × 100\n• लाभ% = (लाभ/CP) × 100\n• हानि% = (हानि/CP) × 100\n• SP = CP × (100+लाभ%)/100\n• Discount% = (Discount/MP) × 100" },
      { title: "साधारण और चक्रवृद्धि ब्याज", content: "साधारण ब्याज:\n• SI = (P × R × T) / 100\n• Amount = P + SI\n\nचक्रवृद्धि ब्याज:\n• A = P(1 + R/100)^T\n• CI = A - P" },
      { title: "औसत, अनुपात और साझेदारी", content: "औसत:\n• औसत = योग / संख्या\n\nअनुपात:\n• a:b = a/b\n\nसाझेदारी:\n• लाभ का अनुपात = P1×T1 : P2×T2" },
    ],
  },
  { id: "reasoning", label: "तार्किक क्षमता", icon: "🧠", color: "#7c3aed", bg: "#faf5ff",
    topics: [
      { title: "Series और Pattern", content: "Number Series Tips:\n• अंतर देखो (+2, +4, +6...)\n• Square series: 1,4,9,16,25...\n• Cube series: 1,8,27,64,125...\n\nAlphabet Series:\n• A=1, B=2... Z=26\n• EJOTY: E=5, J=10, O=15, T=20, Y=25" },
      { title: "Coding-Decoding", content: "• Letter Coding: A→Z reversal\n• Number Coding: A=1, B=2...\n• Mirror: ABCDE = ZYXWV\n\nTrick: हर letter में same operation होती है" },
      { title: "Blood Relations", content: "Key Terms:\n• Mother का brother = Mama\n• Father का brother = Chacha\n• Grandfather का son = Father या Chacha\n\nTrick: Family tree बनाओ" },
      { title: "Direction और Distance", content: "8 दिशाएं: N, NE, E, SE, S, SW, W, NW\n\nSunrise = East | Sunset = West\n\nDistance = √(a²+b²) (Right angle)" },
    ],
  },
  { id: "english", label: "English", icon: "🇬🇧", color: "#059669", bg: "#f0fdf4",
    topics: [
      { title: "Tenses — Quick Reference", content: "Present Simple: V1/V1+s\nPresent Continuous: is/am/are + V-ing\nPresent Perfect: has/have + V3\n\nPast Simple: V2\nPast Continuous: was/were + V-ing\nPast Perfect: had + V3\n\nFuture Simple: will + V1" },
      { title: "Articles — A, An, The", content: "A → Consonant sound: a book\nAn → Vowel sound: an apple, an hour\nThe → Specific: the sun, the moon\n\nNo Article:\n• Proper nouns: India\n• Abstract: honesty\n• Sports: play cricket" },
      { title: "One Word Substitutions", content: "• Omnivore → जो सब खाए\n• Carnivore → मांसाहारी\n• Autobiography → खुद की जीवनी\n• Ambidextrous → दोनों हाथों से काम\n• Omniscient → सर्वज्ञ\n• Anonymous → बिना नाम का" },
      { title: "Important Antonyms", content: "Expand ↔ Contract\nBold ↔ Timid\nDiligent ↔ Lazy\nGenerous ↔ Miserly\nHumble ↔ Arrogant\nJovial ↔ Melancholy\nKeen ↔ Indifferent" },
    ],
  },
  { id: "science", label: "विज्ञान", icon: "🔬", color: "#0ea5e9", bg: "#f0f9ff",
    topics: [
      { title: "Physics — महत्वपूर्ण नियम", content: "Newton के नियम:\n1. जड़त्व का नियम (Inertia)\n2. F = ma\n3. क्रिया-प्रतिक्रिया\n\nओम का नियम: V = IR\nपावर: P = VI\n\ng = 9.8 m/s² (पृथ्वी)\nचंद्रमा: g = 1.63 m/s²" },
      { title: "Chemistry — महत्वपूर्ण तत्व", content: "पहले 20: H, He, Li, Be, B, C, N, O, F, Ne, Na, Mg, Al, Si, P, S, Cl, Ar, K, Ca\n\nसोना→Au | चाँदी→Ag | लोहा→Fe\nताँबा→Cu | पारा→Hg\n\nAcids:\nHCl → Hydrochloric\nH₂SO₄ → Sulphuric" },
      { title: "Biology — मानव शरीर", content: "Heart Beats: 72/min\nBlood Groups: A, B, AB, O\nUniversal Donor: O\nUniversal Recipient: AB\n\nविटामिन:\nA→दृष्टि | C→Immunity\nD→हड्डियाँ | K→रक्त जमाव\n\nDNA = Deoxyribonucleic Acid" },
    ],
  },
  { id: "computer", label: "Computer", icon: "💻", color: "#be185d", bg: "#fdf2f8",
    topics: [
      { title: "Computer Basics", content: "Generation:\n1st: Vacuum Tubes\n2nd: Transistors\n3rd: ICs\n4th: Microprocessors\n5th: AI\n\nMemory:\nRAM: Volatile\nROM: Non-volatile\n1 Byte = 8 bits\n1 KB = 1024 Bytes" },
      { title: "Internet और Networking", content: "WWW: Tim Berners-Lee (1991)\nHTTP → HyperText Transfer Protocol\nHTTPS → Secure HTTP\nDNS → Domain Name System\n\nNetwork:\nLAN → Local\nWAN → Wide\nMAN → Metropolitan" },
      { title: "MS Office Shortcuts", content: "Ctrl+B → Bold\nCtrl+I → Italic\nCtrl+U → Underline\nCtrl+S → Save\nCtrl+C → Copy | Ctrl+V → Paste\nCtrl+Z → Undo | Ctrl+Y → Redo\nCtrl+P → Print\nCtrl+F → Find\nCtrl+A → Select All" },
    ],
  },
];

type CommunityNote = {
  id: number;
  title: string;
  subject: string;
  description: string;
  file_url: string;
  file_type: string;
  file_size: number;
  uploader_name: string;
  created_at: string;
};

function formatBytes(b: number) {
  if (b < 1024) return b + " B";
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
  return (b / (1024 * 1024)).toFixed(1) + " MB";
}

function CommunityNotesTab() {
  const { user, setShowAuthModal } = useAuth();
  const [notes, setNotes] = useState<CommunityNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterSubject, setFilterSubject] = useState("all");
  const [showUpload, setShowUpload] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState("");
  const [form, setForm] = useState({ title: "", subject: "gk", description: "" });
  const fileRef = useRef<HTMLInputElement>(null);

  function loadNotes(sub: string) {
    setLoading(true);
    fetch(`/api/community-notes?subject=${sub}`)
      .then((r) => r.json())
      .then((d) => setNotes(d.notes || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }

  useEffect(() => { loadNotes(filterSubject); }, [filterSubject]);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!user) { setShowAuthModal(true); return; }
    const file = fileRef.current?.files?.[0];
    if (!file) { setUploadMsg("❌ File select करें"); return; }

    const allowed = ["application/pdf", "image/jpeg", "image/png", "image/jpg", "image/webp"];
    if (!allowed.includes(file.type)) {
      setUploadMsg("❌ सिर्फ PDF, JPG, PNG allowed है");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setUploadMsg("❌ File 20MB से बड़ी नहीं होनी चाहिए");
      return;
    }

    setUploading(true);
    setUploadMsg("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("title", form.title);
      fd.append("subject", form.subject);
      fd.append("description", form.description);
      const r = await fetch("/api/community-notes", {
        method: "POST",
        credentials: "include",
        body: fd,
      });
      const d = await r.json();
      if (d.success) {
        setUploadMsg("✅ Notes upload हो गए!");
        setForm({ title: "", subject: "gk", description: "" });
        if (fileRef.current) fileRef.current.value = "";
        setShowUpload(false);
        loadNotes(filterSubject);
      } else {
        setUploadMsg("❌ " + (d.error || "Upload failed"));
      }
    } catch {
      setUploadMsg("❌ Upload failed");
    } finally {
      setUploading(false);
      setTimeout(() => setUploadMsg(""), 5000);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete करें?")) return;
    await fetch(`/api/community-notes/${id}`, { method: "DELETE", credentials: "include" });
    loadNotes(filterSubject);
  }

  return (
    <div>
      {/* Upload Banner */}
      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl p-5 mb-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-black text-purple-800 text-lg">📤 अपने Notes Share करें!</h3>
            <p className="text-purple-600 text-sm mt-1">PDF या Photo (JPG/PNG) upload करो — सभी students देख सकते हैं</p>
            <p className="text-purple-500 text-xs mt-1">Max size: 20MB • Allowed: PDF, JPG, PNG</p>
          </div>
          <button
            onClick={() => { if (!user) { setShowAuthModal(true); return; } setShowUpload(!showUpload); }}
            className="shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm text-white transition-all"
            style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}
          >
            {showUpload ? "✕ Cancel" : "📤 Upload"}
          </button>
        </div>
        {uploadMsg && (
          <div className="mt-3 text-sm font-semibold text-purple-800 bg-purple-100 rounded-xl px-3 py-2">
            {uploadMsg}
          </div>
        )}

        {showUpload && (
          <form onSubmit={handleUpload} className="mt-4 border-t border-purple-200 pt-4 space-y-3">
            <input
              required
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              placeholder="Notes का Title (जैसे: Maths Formulas - Set 1)"
              className="w-full border border-purple-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-400"
            />
            <div className="flex gap-3">
              <select
                value={form.subject}
                onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                className="flex-1 border border-purple-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-purple-400"
              >
                {SUBJECTS.map((s) => (
                  <option key={s.id} value={s.id}>{s.icon} {s.label}</option>
                ))}
              </select>
            </div>
            <textarea
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              placeholder="Description (optional) — किस topic के notes हैं?"
              rows={2}
              className="w-full border border-purple-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-purple-400 resize-none"
            />
            <div className="border-2 border-dashed border-purple-300 rounded-xl p-4 text-center cursor-pointer hover:border-purple-500 transition-all"
              onClick={() => fileRef.current?.click()}>
              <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" className="hidden" />
              <div className="text-3xl mb-1">📁</div>
              <p className="text-sm text-purple-600 font-semibold">Click to select PDF or Image</p>
              <p className="text-xs text-purple-400">PDF, JPG, PNG — Max 20MB</p>
            </div>
            <button
              type="submit"
              disabled={uploading}
              className="w-full py-3 rounded-xl font-black text-white transition-all disabled:opacity-60"
              style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}
            >
              {uploading ? "⏳ Uploading..." : "✅ Upload करें"}
            </button>
          </form>
        )}
      </div>

      {/* Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-5">
        <button
          onClick={() => setFilterSubject("all")}
          className={`shrink-0 px-3 py-2 rounded-full text-xs font-bold transition-all ${filterSubject === "all" ? "text-white bg-gray-700" : "bg-white border border-gray-200 text-gray-600"}`}
        >
          📋 All
        </button>
        {SUBJECTS.map((s) => (
          <button
            key={s.id}
            onClick={() => setFilterSubject(s.id)}
            className={`shrink-0 px-3 py-2 rounded-full text-xs font-bold transition-all ${filterSubject === s.id ? "text-white" : "bg-white border border-gray-200 text-gray-600"}`}
            style={filterSubject === s.id ? { background: s.color } : {}}
          >
            {s.icon} {s.label}
          </button>
        ))}
      </div>

      {/* Notes List */}
      {loading ? (
        <div className="text-center py-16 text-gray-400">
          <div className="text-4xl mb-2 animate-spin">⏳</div>
          <p>Loading community notes...</p>
        </div>
      ) : notes.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <div className="text-5xl mb-3">📭</div>
          <p className="font-semibold text-gray-500">कोई community notes नहीं हैं अभी</p>
          <p className="text-sm mt-1">पहले notes upload करने वाले बनो!</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {notes.map((note) => {
            const subj = SUBJECTS.find((s) => s.id === note.subject);
            const isPdf = note.file_type?.includes("pdf");
            return (
              <div key={note.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-all">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0"
                    style={{ background: subj?.bg || "#f3f4f6" }}>
                    {isPdf ? "📄" : "🖼️"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-black text-gray-800 text-sm leading-tight truncate">{note.title}</h4>
                    {note.description && (
                      <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{note.description}</p>
                    )}
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <span className="text-xs font-bold px-2 py-0.5 rounded-full"
                        style={{ background: subj?.bg || "#f3f4f6", color: subj?.color || "#374151" }}>
                        {subj?.icon} {subj?.label}
                      </span>
                      <span className="text-xs text-gray-400">{formatBytes(note.file_size)}</span>
                      <span className="text-xs text-gray-400">by {note.uploader_name || "Anonymous"}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <a
                    href={note.file_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 text-center py-2 rounded-xl text-xs font-bold text-white transition-all"
                    style={{ background: subj?.color || "#374151" }}
                  >
                    {isPdf ? "📄 PDF देखें" : "🖼️ Image देखें"}
                  </a>
                  {(user?.isAdmin || user?.id === note.uploaded_by) && (
                    <button
                      onClick={() => handleDelete(note.id)}
                      className="px-3 py-2 rounded-xl text-xs font-bold text-red-400 border border-red-100 hover:bg-red-50 transition-all"
                    >
                      🗑️
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function StudyNotes() {
  const [activeSubject, setActiveSubject] = useState("gk");
  const [activeTopic, setActiveTopic] = useState(0);
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"notes" | "community">("notes");

  const subject = SUBJECTS.find((s) => s.id === activeSubject)!;
  const topics = subject.topics.filter((t) =>
    !search || t.title.toLowerCase().includes(search.toLowerCase()) || t.content.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="text-white px-4 py-8" style={{ background: `linear-gradient(135deg, ${subject.color}, ${subject.color}cc)` }}>
        <div className="max-w-5xl mx-auto">
          <h1 className="text-2xl font-black">📖 Study Notes</h1>
          <p className="text-white/80 text-sm mt-1">Quick revision notes — सभी Govt exams के लिए</p>

          {/* Tabs */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setActiveTab("notes")}
              className={`px-5 py-2 rounded-full text-sm font-black transition-all ${activeTab === "notes" ? "bg-white text-gray-800" : "bg-white/20 text-white hover:bg-white/30"}`}
            >
              📚 Official Notes
            </button>
            <button
              onClick={() => setActiveTab("community")}
              className={`px-5 py-2 rounded-full text-sm font-black transition-all ${activeTab === "community" ? "bg-white text-gray-800" : "bg-white/20 text-white hover:bg-white/30"}`}
            >
              👥 Community Notes
            </button>
          </div>

          {activeTab === "notes" && (
            <div className="mt-4 relative">
              <input
                value={search}
                onChange={e => { setSearch(e.target.value); setActiveTopic(0); }}
                placeholder="Notes search करें..."
                className="w-full bg-white/20 border border-white/30 text-white placeholder-white/60 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:bg-white/30"
              />
            </div>
          )}
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {activeTab === "community" ? (
          <CommunityNotesTab />
        ) : (
          <div className="flex gap-6">
            {/* Left: Subject List */}
            <div className="w-48 shrink-0 hidden md:block">
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden sticky top-20">
                {SUBJECTS.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => { setActiveSubject(s.id); setActiveTopic(0); setSearch(""); }}
                    className={`w-full flex items-center gap-2.5 px-4 py-3 text-sm font-bold transition-all border-b border-gray-50 last:border-0 ${
                      activeSubject === s.id ? "text-white" : "text-gray-600 hover:bg-gray-50"
                    }`}
                    style={activeSubject === s.id ? { background: s.color } : {}}
                  >
                    <span>{s.icon}</span>
                    <span>{s.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile subject tabs */}
            <div className="md:hidden w-full">
              <div className="flex gap-2 overflow-x-auto pb-3 mb-4">
                {SUBJECTS.map((s) => (
                  <button key={s.id} onClick={() => { setActiveSubject(s.id); setActiveTopic(0); setSearch(""); }}
                    className={`shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-bold transition-all ${activeSubject === s.id ? "text-white" : "bg-white text-gray-600 border border-gray-200"}`}
                    style={activeSubject === s.id ? { background: s.color } : {}}>
                    {s.icon} {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Right: Topics */}
            <div className="flex-1 min-w-0">
              {topics.length === 0 ? (
                <div className="text-center py-16 text-gray-400">
                  <div className="text-4xl mb-2">🔍</div>
                  <p>कोई notes नहीं मिले</p>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  {topics.map((topic, i) => (
                    <div key={i} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all">
                      <button
                        onClick={() => setActiveTopic(activeTopic === i ? -1 : i)}
                        className="w-full flex items-center justify-between px-5 py-4 text-left"
                      >
                        <span className="font-black text-gray-800 text-base">{topic.title}</span>
                        <span className="text-gray-300 ml-3 shrink-0">{activeTopic === i ? "▲" : "▼"}</span>
                      </button>
                      {activeTopic === i && (
                        <div className="px-5 pb-5 border-t border-gray-50">
                          <pre className="whitespace-pre-wrap text-sm text-gray-700 leading-relaxed font-sans mt-3">
                            {topic.content}
                          </pre>
                          <button
                            onClick={() => {
                              const el = document.createElement("textarea");
                              el.value = topic.title + "\n\n" + topic.content;
                              document.body.appendChild(el);
                              el.select(); document.execCommand("copy");
                              document.body.removeChild(el);
                            }}
                            className="mt-4 text-xs font-bold px-4 py-1.5 rounded-full border transition-all hover:text-white"
                            style={{ color: subject.color, borderColor: subject.color }}
                            onMouseEnter={e => (e.currentTarget.style.background = subject.color)}
                            onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                          >
                            📋 Copy Notes
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
