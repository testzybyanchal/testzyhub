import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";

const TICKER_ADS = [
  "🏆 Mega Quiz — Sunday 8 PM | ₹10 Entry | Win Big Prizes!",
  "⚔️ 1v1 Battle Mode LIVE! Challenge friends & earn Coins!",
  "📚 SSC CGL 2025 — Complete Mock Test Series Available!",
  "🔥 Daily Login करें और XP + Coins कमाएं!",
  "🎯 Railway NTPC Preparation — 1000+ Questions in Hindi!",
  "⚡ Daily Quiz रोज़ रात 8 बजे — XP Points & Coins कमाओ!",
];

export function AdTicker() {
  const [pos, setPos] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const id = setInterval(() => {
      setPos((p) => {
        if (!ref.current) return p;
        const w = ref.current.scrollWidth / 2;
        return p <= -w ? 0 : p - 1;
      });
    }, 20);
    return () => clearInterval(id);
  }, []);
  const doubled = [...TICKER_ADS, ...TICKER_ADS];
  return (
    <div className="overflow-hidden bg-gradient-to-r from-purple-700 via-pink-600 to-orange-500 py-2">
      <div
        ref={ref}
        className="flex gap-16 whitespace-nowrap"
        style={{ transform: `translateX(${pos}px)`, transition: "none" }}
      >
        {doubled.map((ad, i) => (
          <span key={i} className="text-white text-sm font-semibold shrink-0">
            📢 {ad}
          </span>
        ))}
      </div>
    </div>
  );
}

export const MEGA_PRIZES = [
  {
    rank: 1,
    icon: "🥇",
    title: "1st Prize",
    amount: "₹300",
    color: "#f59e0b",
    bg: "#fef3c7",
    border: "#fcd34d",
  },
  {
    rank: 2,
    icon: "🥈",
    title: "2nd Prize",
    amount: "₹200",
    color: "#6b7280",
    bg: "#f3f4f6",
    border: "#d1d5db",
  },
  {
    rank: 3,
    icon: "🥉",
    title: "3rd Prize",
    amount: "₹100",
    color: "#b45309",
    bg: "#fef9c3",
    border: "#fde68a",
  },
  {
    rank: 4,
    icon: "🏅",
    title: "4th Prize",
    amount: "₹50",
    color: "#6d28d9",
    bg: "#ede9fe",
    border: "#c4b5fd",
  },
  {
    rank: 5,
    icon: "🏅",
    title: "5th Prize",
    amount: "₹25",
    color: "#0ea5e9",
    bg: "#e0f2fe",
    border: "#bae6fd",
  },
];

export function useDailyQuizCountdown() {
  const [state, setState] = useState<
    "loading" | "countdown" | "live" | "ended"
  >("loading");
  const [timeStr, setTimeStr] = useState("");

  useEffect(() => {
    function update() {
      const now = new Date();
      const h = now.getHours();

      if (h >= 20 && h < 23) {
        setState("live");
        setTimeStr("");
      } else if (h >= 23) {
        setState("ended");
        setTimeStr("");
      } else {
        setState("countdown");
        const target = new Date(now);
        target.setHours(20, 0, 0, 0);
        if (now >= target) {
          target.setDate(target.getDate() + 1);
          target.setHours(20, 0, 0, 0);
        }
        const diff = Math.max(0, target.getTime() - now.getTime());
        const hours = Math.floor(diff / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setTimeStr(
          `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`,
        );
      }
    }
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  return { state, timeStr };
}

const POSTER_SLIDES = [
  {
    id: 1,
    color: "#1d4ed8",
    color2: "#3b82f6",
    overlay: "rgba(15,37,87,0.72)",
    badge: "🏛️ SSC EXAM 2025",
    title: "SSC CGL / CHSL की तैयारी",
    subtitle: "1000+ Hindi Questions • Subject-wise Practice",
    desc: "सामान्य ज्ञान, गणित, तार्किक क्षमता, अंग्रेजी — सभी subject अलग-अलग",
    cta: "SSC Practice शुरू करें →",
    ctaHref: "/practice?category=ssc",
    stats: [
      { val: "1000+", label: "Questions" },
      { val: "Free", label: "बिल्कुल मुफ्त" },
      { val: "Hindi", label: "Medium" },
    ],
  },
  {
    id: 2,
    color: "#dc2626",
    color2: "#f97316",
    overlay: "rgba(100,15,15,0.72)",
    badge: "🚂 RAILWAY 2025",
    title: "Railway NTPC / Group D",
    subtitle: "RRB NTPC, Group D — Hindi में तैयारी",
    desc: "विज्ञान, गणित, GK, Hindi — सभी subjects एक जगह",
    cta: "Railway Practice करें →",
    ctaHref: "/practice?category=railway",
    stats: [
      { val: "RRB", label: "NTPC" },
      { val: "Group", label: "D" },
      { val: "Hindi", label: "Questions" },
    ],
  },
  {
    id: 3,
    color: "#7c3aed",
    color2: "#a855f7",
    overlay: "rgba(60,20,110,0.72)",
    badge: "👮 POLICE EXAM",
    title: "UP Police / State Police",
    subtitle: "Constable, SI — Complete Preparation",
    desc: "हिंदी, GK, गणित, Computer — subject-wise practice",
    cta: "Police Practice करें →",
    ctaHref: "/practice?category=police",
    stats: [
      { val: "UP", label: "Police" },
      { val: "SI", label: "Constable" },
      { val: "GK+", label: "Computer" },
    ],
  },
  {
    id: 4,
    color: "#059669",
    color2: "#10b981",
    overlay: "rgba(5,60,40,0.72)",
    badge: "🏦 BANKING 2025",
    title: "SBI PO / IBPS / Clerk",
    subtitle: "Quant, Reasoning, GA, English — All in One",
    desc: "Banking exams के लिए complete preparation — English से Quant तक",
    cta: "Banking Practice करें →",
    ctaHref: "/practice?category=banking",
    stats: [
      { val: "SBI", label: "PO" },
      { val: "IBPS", label: "Clerk" },
      { val: "RBI", label: "Grade B" },
    ],
  },
  {
    id: 5,
    color: "#d97706",
    color2: "#f59e0b",
    overlay: "rgba(90,50,5,0.72)",
    badge: "🏆 MEGA QUIZ",
    title: "Weekly Mega Quiz",
    subtitle: "हर Sunday 8 PM • ₹10 Entry • Cash Prize",
    desc: "1st: ₹300 • 2nd: ₹200 • 3rd: ₹100 • 4th: ₹50 • 5th: ₹25",
    cta: "Mega Quiz Register करें →",
    ctaHref: "/mega-quiz",
    emoji: "🏆",
    stats: [
      { val: "₹10", label: "Entry Fee" },
      { val: "₹300", label: "1st Prize" },
      { val: "Top 5", label: "Winners" },
    ],
  },
  {
    id: 6,
    color: "#ec4899",
    color2: "#f43f5e",
    overlay: "rgba(100,15,60,0.72)",
    badge: "🎁 REFER & EARN",
    title: "दोस्तों को Invite करें!",
    subtitle: "दोनों को मिलेगा +50 XP और +20 Coins",
    desc: "अपना Referral Code share करें — जितने दोस्त join करें, उतना bonus!",
    cta: "Referral Code पाएं →",
    ctaHref: "/referral",
    emoji: "🎁",
    stats: [
      { val: "+50", label: "XP Bonus" },
      { val: "+20", label: "Coins" },
      { val: "Share", label: "WhatsApp" },
    ],
  },
];

const ALL_WORDS = [
  {
    word: "Ephemeral",
    meaning: "अल्पकालिक — lasting for only a short time",
    example: "The ephemeral beauty of cherry blossoms",
    tip: "Epi+hemar (day) → only a day lasting",
  },
  {
    word: "Diligent",
    meaning: "परिश्रमी — careful and hard-working",
    example: "A diligent student always succeeds",
    tip: "Dili+gent → gentle but hardworking!",
  },
  {
    word: "Benevolent",
    meaning: "परोपकारी — well-meaning and kind",
    example: "The benevolent king helped the poor",
    tip: "Bene (good) + volent (wish) → good wish",
  },
  {
    word: "Frugal",
    meaning: "मितव्ययी — economical, not wasteful",
    example: "A frugal person saves money wisely",
    tip: "Fruit kal nahi mila → saved/frugal!",
  },
  {
    word: "Eloquent",
    meaning: "वाकपटु — fluent and persuasive speaker",
    example: "An eloquent speech moved the crowd",
    tip: "Eloque+nt → elocution से connected",
  },
  {
    word: "Omniscient",
    meaning: "सर्वज्ञ — knowing everything",
    example: "God is considered omniscient",
    tip: "Omni (all) + scient (know) → all-knowing",
  },
  {
    word: "Tenacious",
    meaning: "दृढ़निश्चयी — holding firm, persistent",
    example: "A tenacious athlete never gives up",
    tip: "Ten+acious → टिके रहने वाला",
  },
  {
    word: "Ambiguous",
    meaning: "अस्पष्ट — having more than one meaning",
    example: "His ambiguous reply confused everyone",
    tip: "Ambi (both) → दोनों तरफ जा सकता है",
  },
  {
    word: "Gregarious",
    meaning: "मिलनसार — fond of company, sociable",
    example: "She is very gregarious at parties",
    tip: "Greg = flock → झुंड में रहने वाला",
  },
  {
    word: "Obsolete",
    meaning: "अप्रचलित — no longer in use",
    example: "The fax machine is now obsolete",
    tip: "Ob+solete → पुराना पड़ गया",
  },
  {
    word: "Meticulous",
    meaning: "सावधान — showing great attention to detail",
    example: "A meticulous worker makes no errors",
    tip: "Meti+culous → careful culus!",
  },
  {
    word: "Verbose",
    meaning: "वाचाल — using more words than needed",
    example: "His verbose essay bored the readers",
    tip: "Verb (word) + ose → शब्दों से भरा",
  },
  {
    word: "Insolent",
    meaning: "उद्दण्ड — rude and disrespectful",
    example: "The insolent student was punished",
    tip: "In (not) + solent (usual) → असामान्य रूप से बेशर्म",
  },
  {
    word: "Pragmatic",
    meaning: "व्यावहारिक — dealing with things sensibly",
    example: "A pragmatic leader finds real solutions",
    tip: "Pragma (action) → काम की बात करने वाला",
  },
  {
    word: "Lucid",
    meaning: "स्पष्ट — clear and easy to understand",
    example: "She gave a lucid explanation",
    tip: "Luc = light → प्रकाश की तरह साफ",
  },
  {
    word: "Volatile",
    meaning: "अस्थिर — liable to change rapidly",
    example: "Stock prices are volatile",
    tip: "Vola (fly) → उड़ता रहता है",
  },
  {
    word: "Resilient",
    meaning: "लचीला — able to recover quickly",
    example: "Resilient people bounce back from failure",
    tip: "Re+silient → वापस उठ जाने वाला",
  },
  {
    word: "Scrutinize",
    meaning: "जाँचना — examine closely and critically",
    example: "He scrutinized every document",
    tip: "Scrut+inize → छान-बीन करना",
  },
  {
    word: "Impartial",
    meaning: "निष्पक्ष — treating all equally, fair",
    example: "A judge must be impartial",
    tip: "Im (not) + partial → किसी की तरफ नहीं",
  },
  {
    word: "Covert",
    meaning: "गुप्त — secret, not openly shown",
    example: "The spy conducted covert operations",
    tip: "Co+vert → cover के नीचे छुपा",
  },
  {
    word: "Perseverance",
    meaning: "दृढ़ता — continued effort despite difficulty",
    example: "Perseverance leads to success",
    tip: "Per+severe → कड़ी मेहनत जारी रखना",
  },
  {
    word: "Redundant",
    meaning: "अनावश्यक — not needed, extra",
    example: "The redundant data was deleted",
    tip: "Re+dundant → बार बार दोहराना",
  },
  {
    word: "Ambivalent",
    meaning: "द्विधा में — having mixed feelings",
    example: "She was ambivalent about the offer",
    tip: "Ambi (both) → दोनों तरफ खिंचाव",
  },
  {
    word: "Callous",
    meaning: "निर्दय — showing no sympathy",
    example: "His callous attitude shocked everyone",
    tip: "Call+ous → कठोर चमड़ी वाला",
  },
  {
    word: "Clandestine",
    meaning: "गोपनीय — kept secret, hidden",
    example: "They had a clandestine meeting",
    tip: "Cland = hidden → छुप-छुपाकर",
  },
  {
    word: "Cynical",
    meaning: "संदेही — distrustful of others' motives",
    example: "He became cynical after betrayal",
    tip: "Cyn = dog → कुत्ते की तरह संशयी",
  },
  {
    word: "Dogmatic",
    meaning: "हठधर्मी — insisting on own views",
    example: "A dogmatic leader won't listen",
    tip: "Dog+matic → अपनी बात पर अड़ा",
  },
  {
    word: "Eminent",
    meaning: "प्रतिष्ठित — famous and respected",
    example: "An eminent scientist won the award",
    tip: "Emi+nent → ऊपर उठा हुआ",
  },
  {
    word: "Fervent",
    meaning: "उत्साही — having strong passion",
    example: "He is a fervent supporter of education",
    tip: "Ferv = boil → जोश से भरा",
  },
  {
    word: "Garrulous",
    meaning: "बातूनी — excessively talkative",
    example: "The garrulous neighbor never stops",
    tip: "Garr+ulous → गपशप करने वाला",
  },
  {
    word: "Harbinger",
    meaning: "अग्रदूत — a sign of things to come",
    example: "Dark clouds are harbingers of rain",
    tip: "Har+binger → आने वाले का संकेत",
  },
  {
    word: "Indolent",
    meaning: "आलसी — wanting to avoid activity",
    example: "An indolent student fails exams",
    tip: "In+dolent → दर्द नहीं = काम नहीं",
  },
  {
    word: "Jeopardize",
    meaning: "खतरे में डालना — put at risk",
    example: "Don't jeopardize your career",
    tip: "Jeu (game) → खेल जैसा जोखिम",
  },
  {
    word: "Kindle",
    meaning: "जगाना — arouse or inspire a feeling",
    example: "The story kindled his interest",
    tip: "Kind+le → अच्छाई जगाना",
  },
  {
    word: "Lethargic",
    meaning: "सुस्त — lacking energy or enthusiasm",
    example: "Hot weather makes one lethargic",
    tip: "Lethe (river of forgetfulness) → भूलने जैसी सुस्ती",
  },
];

export function WordOfDay() {
  const dayIndex = Math.floor(Date.now() / 86400000);
  const startIndex = (dayIndex * 5) % ALL_WORDS.length;
  const todayWords = Array.from(
    { length: 5 },
    (_, i) => ALL_WORDS[(startIndex + i) % ALL_WORDS.length],
  );
  const [active, setActive] = useState(0);
  const [copied, setCopied] = useState(false);
  const w = todayWords[active];

  useEffect(() => {
    const id = setInterval(() => setActive((a) => (a + 1) % 5), 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-5">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg">
              📘
            </div>
            <div>
              <p className="text-[10px] font-bold text-emerald-200 uppercase tracking-widest">
                Words of the Day
              </p>
              <p className="text-xs text-white/70">
                आज के 5 Important English Words
              </p>
            </div>
          </div>
          <div className="flex gap-1.5">
            {todayWords.map((_, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className="h-1.5 rounded-full transition-all duration-300"
                style={{
                  width: i === active ? 20 : 6,
                  background: i === active ? "white" : "rgba(255,255,255,0.35)",
                }}
              />
            ))}
          </div>
        </div>

        {/* Word Cards Row */}
        <div className="flex gap-2 overflow-x-auto pb-1 hide-scrollbar">
          {todayWords.map((word, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className="shrink-0 rounded-xl px-3 py-2 text-left transition-all"
              style={{
                background:
                  i === active
                    ? "rgba(255,255,255,0.25)"
                    : "rgba(255,255,255,0.1)",
                border:
                  i === active
                    ? "1.5px solid rgba(255,255,255,0.6)"
                    : "1.5px solid rgba(255,255,255,0.2)",
                minWidth: 100,
              }}
            >
              <div className="text-xs font-black text-white leading-none">
                {word.word}
              </div>
              <div className="text-[9px] text-emerald-200 mt-0.5 truncate">
                {word.meaning.split("—")[0].trim()}
              </div>
            </button>
          ))}
        </div>

        {/* Active Word Detail */}
        <div className="mt-4 flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg font-black">{w.word}</span>
              <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full text-emerald-100 font-semibold">
                Word {active + 1}/5
              </span>
            </div>
            <p className="text-sm font-semibold text-white/90">{w.meaning}</p>
            <p className="text-xs text-emerald-200 mt-0.5 italic">
              "{w.example}"
            </p>
            <p className="text-xs text-white/60 mt-0.5">💡 {w.tip}</p>
          </div>
          <button
            onClick={() => {
              const text = todayWords
                .map((wd, i) => `${i + 1}. ${wd.word}: ${wd.meaning}`)
                .join("\n");
              navigator.clipboard?.writeText(text);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
            className="shrink-0 bg-white/20 hover:bg-white/30 border border-white/30 px-3 py-2 rounded-xl text-xs font-bold transition-all"
          >
            {copied ? "✅ Copied!" : "📋 Copy All"}
          </button>
        </div>
      </div>
    </div>
  );
}

export type MegaQuizSettings = {
  quiz_date?: string;
  start_time?: string;
  end_time?: string;
  entry_fee?: number;
  title?: string;
  prizes?: { rank_position: number; amount: string }[];
};

export function PosterSlider({
  megaSettings,
}: {
  megaSettings: MegaQuizSettings | null;
}) {
  const [current, setCurrent] = useState(0);
  const [, navigate] = useLocation();

  const slides = POSTER_SLIDES.map((slide, i) => {
    if (i !== 4 || !megaSettings) return slide;
    const date = megaSettings.quiz_date
      ? new Date(megaSettings.quiz_date).toLocaleDateString("hi-IN", {
          day: "numeric",
          month: "long",
        })
      : "Sunday";
    const fee = megaSettings.entry_fee ?? 10;
    const firstPrize = megaSettings.prizes?.[0]?.amount || "₹300";
    return {
      ...slide,
      title: megaSettings.title || slide.title,
      subtitle: `${date} 8 PM • ₹${fee} Entry • Cash Prize`,
      desc:
        megaSettings.prizes
          ?.slice(0, 5)
          .map((p, idx) => `${idx + 1}st: ${p.amount}`)
          .join(" • ") || slide.desc,
      stats: [
        { val: `₹${fee}`, label: "Entry Fee" },
        { val: firstPrize, label: "1st Prize" },
        { val: "Top 5", label: "Winners" },
      ],
    };
  });

  const total = slides.length;

  useEffect(() => {
    const id = setInterval(() => setCurrent((c) => (c + 1) % total), 4500);
    return () => clearInterval(id);
  }, [total]);

  const slide = slides[current] as (typeof slides)[0];

  return (
    <div className="relative overflow-hidden" style={{ minHeight: 300 }}>
      {/* Full background image */}
      <img
        src="/images/slide-bg.png"
        alt=""
        className="absolute inset-0 w-full h-full object-cover transition-all duration-700"
        style={{ objectPosition: "center top" }}
      />

      {/* Colored overlay — changes per slide */}
      <div
        className="absolute inset-0 transition-all duration-700"
        style={{
          background: `linear-gradient(135deg, ${slide.overlay} 0%, ${slide.overlay} 50%, rgba(0,0,0,0.3) 100%)`,
        }}
      />

      {/* Bottom gradient for text readability */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 60%)",
        }}
      />

      {/* Content */}
      <div
        className="relative z-10 max-w-5xl mx-auto px-5 py-8 flex flex-col justify-between"
        style={{ minHeight: 300 }}
      >
        {/* Top: Badge + Title */}
        <div className="flex-1">
          <span
            className="inline-block text-xs font-black text-white px-4 py-1.5 rounded-full mb-4 shadow-lg backdrop-blur-sm"
            style={{
              background: `linear-gradient(135deg, ${slide.color}, ${slide.color2})`,
            }}
          >
            {slide.badge}
          </span>

          <h2 className="text-2xl md:text-4xl font-black text-white leading-tight mb-2 drop-shadow-xl">
            {(slide as any).emoji ? `${(slide as any).emoji} ` : ""}
            {slide.title}
          </h2>

          <p
            className="text-sm md:text-base font-bold mb-1 drop-shadow-lg"
            style={{ color: "#fde68a" }}
          >
            {slide.subtitle}
          </p>
          <p className="text-white/80 text-xs md:text-sm mb-5 leading-relaxed max-w-lg">
            {slide.desc}
          </p>

          {/* Stats */}
          <div className="flex gap-2 flex-wrap mb-5">
            {slide.stats?.map((s) => (
              <div
                key={s.label}
                className="rounded-xl px-3 py-2 text-center backdrop-blur-sm"
                style={{
                  background: "rgba(255,255,255,0.18)",
                  border: "1.5px solid rgba(255,255,255,0.3)",
                }}
              >
                <div className="font-black text-sm text-white leading-none">
                  {s.val}
                </div>
                <div className="text-[10px] text-white/70 mt-0.5 font-semibold">
                  {s.label}
                </div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <button
            onClick={() => navigate(slide.ctaHref)}
            className="font-black text-sm px-6 py-3 rounded-2xl text-white shadow-xl transition-all hover:scale-105 active:scale-95"
            style={{
              background: `linear-gradient(135deg, ${slide.color}, ${slide.color2})`,
            }}
          >
            {slide.cta}
          </button>
        </div>

        {/* Bottom: Dots + Nav */}
        <div className="flex items-center justify-between mt-6">
          <div className="flex gap-1.5">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className="h-1.5 rounded-full transition-all duration-300"
                style={{
                  width: i === current ? 28 : 8,
                  background: i === current ? "white" : "rgba(255,255,255,0.4)",
                }}
              />
            ))}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrent((c) => (c - 1 + total) % total)}
              className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-white transition-all text-lg"
              style={{
                background: "rgba(255,255,255,0.2)",
                border: "1.5px solid rgba(255,255,255,0.4)",
              }}
            >
              ‹
            </button>
            <button
              onClick={() => setCurrent((c) => (c + 1) % total)}
              className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-white transition-all text-lg"
              style={{
                background: "rgba(255,255,255,0.2)",
                border: "1.5px solid rgba(255,255,255,0.4)",
              }}
            >
              ›
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export const featureCards = [
  {
    icon: "📚",
    title: "1000+ Questions",
    desc: "हर category में सैकड़ों Hindi questions",
    cls: "feat-card-1",
    textColor: "#6d28d9",
  },
  {
    icon: "⏱️",
    title: "Real Exam Pattern",
    desc: "Mock Test में असली exam जैसा माहौल",
    cls: "feat-card-2",
    textColor: "#c2410c",
  },
  {
    icon: "🏆",
    title: "Win Prizes",
    desc: "Weekly Mega Quiz में Top 5 को Cash Prize!",
    cls: "feat-card-3",
    textColor: "#9d174d",
  },
  {
    icon: "📊",
    title: "Point System",
    desc: "+1 सही, -0.5 गलत — असली exam scoring",
    cls: "feat-card-4",
    textColor: "#065f46",
  },
];


