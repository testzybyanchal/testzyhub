import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";

const CATEGORIES = [
  { id: "all", label: "सभी", icon: "📰" },
  { id: "exam", label: "Exam", icon: "📋" },
  { id: "economy", label: "Economy", icon: "💰" },
  { id: "science", label: "Science", icon: "🔬" },
  { id: "government", label: "Government", icon: "🏛️" },
  { id: "sports", label: "Sports", icon: "🏅" },
  { id: "technology", label: "Technology", icon: "💻" },
  { id: "general", label: "General", icon: "📌" },
];

const CAT_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  exam: { bg: "#ede9fe", text: "#7c3aed", border: "#c4b5fd" },
  economy: { bg: "#fef3c7", text: "#b45309", border: "#fcd34d" },
  science: { bg: "#e0f2fe", text: "#0369a1", border: "#7dd3fc" },
  government: { bg: "#fee2e2", text: "#b91c1c", border: "#fca5a5" },
  sports: { bg: "#d1fae5", text: "#065f46", border: "#6ee7b7" },
  technology: { bg: "#f0fdf4", text: "#15803d", border: "#86efac" },
  general: { bg: "#f3f4f6", text: "#374151", border: "#d1d5db" },
};

type CAItem = { id: number; title: string; content: string; category: string; date: string };

export default function CurrentAffairs() {
  const { user } = useAuth();
  const [items, setItems] = useState<CAItem[]>([]);
  const [category, setCategory] = useState("all");
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ title: "", content: "", category: "general", date: new Date().toISOString().split("T")[0] });
  const [saving, setSaving] = useState(false);
  const [autoFetching, setAutoFetching] = useState(false);
  const [fetchMsg, setFetchMsg] = useState("");

  function load(cat: string, pg: number) {
    setLoading(true);
    fetch(`/api/current-affairs?category=${cat}&page=${pg}`)
      .then((r) => r.json())
      .then((d) => { setItems(d.items || []); setTotal(d.total || 0); })
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(category, page); }, [category, page]);

  function changeCategory(cat: string) { setCategory(cat); setPage(1); setExpanded(null); }

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    await fetch("/api/current-affairs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(form),
    });
    setSaving(false);
    setShowAdd(false);
    setForm({ title: "", content: "", category: "general", date: new Date().toISOString().split("T")[0] });
    load(category, page);
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this item?")) return;
    await fetch(`/api/current-affairs/${id}`, { method: "DELETE", credentials: "include" });
    load(category, page);
  }

  async function handleAutoFetch() {
    setAutoFetching(true);
    setFetchMsg("");
    try {
      const r = await fetch("/api/current-affairs/auto-fetch", { method: "POST", credentials: "include" });
      const d = await r.json();
      if (d.success) {
        setFetchMsg(`✅ ${d.inserted} नई news fetch हुई!`);
        load(category, 1);
      } else {
        setFetchMsg("❌ Fetch नहीं हो सकी");
      }
    } catch {
      setFetchMsg("❌ Error");
    } finally {
      setAutoFetching(false);
      setTimeout(() => setFetchMsg(""), 5000);
    }
  }

  const totalPages = Math.ceil(total / 10);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 text-white px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-black">📰 Current Affairs</h1>
              <p className="text-blue-200 text-sm mt-1">SSC, Railway, Banking, Police — Daily Updates</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <button
                onClick={handleAutoFetch}
                disabled={autoFetching}
                className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2 transition-all disabled:opacity-60"
              >
                {autoFetching ? "⏳ Fetching..." : "🌐 Auto Fetch"}
              </button>
              {user?.isAdmin && (
                <button
                  onClick={() => setShowAdd(!showAdd)}
                  className="bg-white/20 border border-white/30 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-white/30 transition-all"
                >
                  + Add News
                </button>
              )}
            </div>
          </div>
          {fetchMsg && (
            <div className="mt-3 bg-white/20 rounded-xl px-4 py-2 text-sm font-semibold text-white">
              {fetchMsg}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Admin Add Form */}
        {showAdd && user?.isAdmin && (
          <form onSubmit={handleAdd} className="bg-white rounded-2xl shadow-md p-5 mb-6 border border-purple-100">
            <h3 className="font-black text-gray-800 mb-4">नई Current Affairs जोड़ें</h3>
            <input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Title" className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm mb-3 focus:outline-none focus:border-purple-400" />
            <textarea required value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
              placeholder="Content (विस्तार से लिखें)" rows={4}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm mb-3 focus:outline-none focus:border-purple-400 resize-none" />
            <div className="flex gap-3 mb-4">
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                className="flex-1 border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-purple-400">
                {CATEGORIES.filter(c => c.id !== "all").map(c => (
                  <option key={c.id} value={c.id}>{c.icon} {c.label}</option>
                ))}
              </select>
              <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="flex-1 border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-purple-400" />
            </div>
            <div className="flex gap-2">
              <button type="submit" disabled={saving}
                className="flex-1 py-2.5 rounded-xl font-black text-sm text-white bg-purple-600 hover:bg-purple-700 transition-all">
                {saving ? "Saving..." : "✅ Save"}
              </button>
              <button type="button" onClick={() => setShowAdd(false)}
                className="px-5 py-2.5 rounded-xl font-bold text-sm bg-gray-100 text-gray-600 hover:bg-gray-200">
                Cancel
              </button>
            </div>
          </form>
        )}

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => changeCategory(c.id)}
              className={`shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-bold transition-all ${
                category === c.id ? "text-white shadow-md" : "bg-white text-gray-600 border border-gray-200 hover:border-purple-300"
              }`}
              style={category === c.id ? { background: "linear-gradient(135deg, #1d4ed8, #7c3aed)" } : {}}
            >
              {c.icon} {c.label}
            </button>
          ))}
        </div>

        {/* Items */}
        {loading ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-4xl mb-2">⏳</div>
            <p>Loading...</p>
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-4xl mb-2">📭</div>
            <p className="font-semibold">कोई news नहीं मिली</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {items.map((item) => {
              const catStyle = CAT_COLORS[item.category] || CAT_COLORS.general;
              const catInfo = CATEGORIES.find(c => c.id === item.category);
              const isOpen = expanded === item.id;
              return (
                <div key={item.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all">
                  <div className="p-4 cursor-pointer" onClick={() => setExpanded(isOpen ? null : item.id)}>
                    <div className="flex items-start gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <span className="text-xs font-bold px-2.5 py-1 rounded-full"
                            style={{ background: catStyle.bg, color: catStyle.text, border: `1px solid ${catStyle.border}` }}>
                            {catInfo?.icon} {catInfo?.label}
                          </span>
                          <span className="text-xs text-gray-400">
                            {new Date(item.date).toLocaleDateString("hi-IN", { day: "numeric", month: "long", year: "numeric" })}
                          </span>
                        </div>
                        <h3 className="font-black text-gray-800 text-base leading-snug">{item.title}</h3>
                        {isOpen && (
                          <p className="mt-3 text-sm text-gray-600 leading-relaxed border-t border-gray-100 pt-3">
                            {item.content}
                          </p>
                        )}
                      </div>
                      <div className="text-gray-300 text-xl shrink-0">{isOpen ? "▲" : "▼"}</div>
                    </div>
                    {user?.isAdmin && (
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }}
                        className="mt-2 text-xs text-red-400 hover:text-red-600 font-semibold"
                      >
                        🗑️ Delete
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 mt-8">
            <button disabled={page <= 1} onClick={() => setPage(p => p - 1)}
              className="px-4 py-2 rounded-xl bg-white border border-gray-200 font-bold text-sm text-gray-600 disabled:opacity-40 hover:border-purple-300 transition-all">
              ← Prev
            </button>
            <span className="text-sm text-gray-500 font-semibold">{page} / {totalPages}</span>
            <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}
              className="px-4 py-2 rounded-xl bg-white border border-gray-200 font-bold text-sm text-gray-600 disabled:opacity-40 hover:border-purple-300 transition-all">
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
