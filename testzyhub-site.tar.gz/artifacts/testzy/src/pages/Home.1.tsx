import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { categories } from "@/data/questions";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
    useDailyQuizCountdown,
    MegaQuizSettings,
    AdTicker,
    PosterSlider,
    WordOfDay,
    featureCards,
    MEGA_PRIZES,
} from "./Home";

export default function Home() {
    const [, navigate] = useLocation();
    const { user, setShowAuthModal } = useAuth();
    const { t } = useLanguage();
    const { state, timeStr } = useDailyQuizCountdown();
    const [questionCount, setQuestionCount] = useState<number | null>(null);
    const [megaSettings, setMegaSettings] = useState<MegaQuizSettings | null>(
        null,
    );

    useEffect(() => {
        fetch("/api/stats")
            .then((r) => r.json())
            .then((d) => {
                if (typeof d.total === "number") setQuestionCount(d.total);
            })
            .catch(() => {});
        fetch("/api/mega-quiz/settings")
            .then((r) => r.json())
            .then((d) => setMegaSettings(d))
            .catch(() => {});
    }, []);

    function handleCategoryClick(catId: string) {
        if (!user) {
            setShowAuthModal(true);
            return;
        }
        navigate(`/category/${catId}`);
    }

    function handleQuizClick() {
        if (!user) {
            setShowAuthModal(true);
            return;
        }
        navigate("/daily-quiz");
    }

    return (
        <div
            className="min-h-screen pb-20 lg:pb-0"
            style={{
                background:
                    "linear-gradient(180deg, #fdf4ff 0%, #fce7f3 40%, #eff6ff 100%)",
            }}
        >
            {/* ======= AD TICKER ======= */}
            <AdTicker />

            {/* ======= POSTER SLIDER ======= */}
            <PosterSlider megaSettings={megaSettings} />

            {/* ======= QUICK FEATURE LINKS ======= */}
            <div className="bg-white border-b border-gray-100 py-4 px-4">
                <div className="max-w-5xl mx-auto">
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                        {[
                            {
                                icon: "📰",
                                label: "Current Affairs",
                                path: "/current-affairs",
                                color: "#1d4ed8",
                                bg: "#eff6ff",
                            },
                            {
                                icon: "📖",
                                label: "Study Notes",
                                path: "/study-notes",
                                color: "#059669",
                                bg: "#f0fdf4",
                            },
                            {
                                icon: "📅",
                                label: "Exam Calendar",
                                path: "/exam-calendar",
                                color: "#7c3aed",
                                bg: "#faf5ff",
                            },
                            {
                                icon: "🔖",
                                label: "Bookmarks",
                                path: "/bookmarks",
                                color: "#f97316",
                                bg: "#fff7ed",
                            },
                            {
                                icon: "📊",
                                label: "My Stats",
                                path: "/my-stats",
                                color: "#be185d",
                                bg: "#fdf2f8",
                            },
                            {
                                icon: "🤔",
                                label: "Doubt Forum",
                                path: "/doubts",
                                color: "#0891b2",
                                bg: "#ecfeff",
                            },
                        ].map((f) => (
                            <button
                                key={f.path}
                                onClick={() => navigate(f.path)}
                                className="flex flex-col items-center gap-1.5 p-3 rounded-2xl text-center transition-all hover:scale-105 hover:shadow-md"
                                style={{ background: f.bg }}
                            >
                                <span className="text-2xl">{f.icon}</span>
                                <span
                                    className="text-xs font-bold leading-tight"
                                    style={{ color: f.color }}
                                >
                                    {f.label}
                                </span>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* ======= NEW FEATURES STRIP ======= */}
            <div
                className="px-4 py-5"
                style={{
                    background: "linear-gradient(white,skyblue)",
                }}
            >
                <div className="max-w-5xl mx-auto">
                    <div className="flex items-center gap-2 mb-4">
                        <span className="text-xs font-black text-indigo-300 uppercase tracking-widest">
                            ✨ New Features
                        </span>
                        <span className="text-xs bg-yellow-400/20 text-yellow-300 border border-yellow-400/30 px-2 py-0.5 rounded-full font-bold">
                            नया
                        </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                        {[
                            {
                                icon: "🤖",
                                label: "AI Doubt Solver",
                                desc: "Photo खींचो, AI explain करेगा",
                                path: "/ai-doubt",
                                color: "#a78bfa",
                                bg: "rgba(167,139,250,0.15)",
                                border: "rgba(167,139,250,0.3)",
                            },
                            {
                                icon: "🃏",
                                label: "GK Flashcards",
                                desc: "Swipe करके GK याद करो",
                                path: "/flashcards",
                                color: "#fbbf24",
                                bg: "rgba(251,191,36,0.15)",
                                border: "rgba(251,191,36,0.3)",
                            },
                            {
                                icon: "🏆",
                                label: "Tournament",
                                desc: "4-8 players real-time quiz",
                                path: "/tournament",
                                color: "#34d399",
                                bg: "rgba(52,211,153,0.15)",
                                border: "rgba(52,211,153,0.3)",
                            },
                            {
                                icon: "📋",
                                label: "PYQ Papers",
                                desc: "Real SSC/Railway questions",
                                path: "/pyq",
                                color: "#60a5fa",
                                bg: "rgba(96,165,250,0.15)",
                                border: "rgba(96,165,250,0.3)",
                            },
                            {
                                icon: "📐",
                                label: "Formula Cards",
                                desc: "Flip cards — Math tricks",
                                path: "/formulas",
                                color: "#f87171",
                                bg: "rgba(248,113,113,0.15)",
                                border: "rgba(248,113,113,0.3)",
                            },
                        ].map((f) => (
                            <button
                                key={f.path}
                                onClick={() => navigate(f.path)}
                                className="flex flex-col gap-2 p-4 rounded-2xl text-left transition-all hover:scale-105 hover:brightness-110 active:scale-95"
                                style={{
                                    background: f.bg,
                                    border: `1.5px solid ${f.border}`,
                                }}
                            >
                                <span className="text-3xl">{f.icon}</span>
                                <div>
                                    <p
                                        className="text-xs font-black leading-none mb-1"
                                        style={{ color: f.color }}
                                    >
                                        {f.label}
                                    </p>
                                    <p className="text-[10px] text-white/50 leading-tight">
                                        {f.desc}
                                    </p>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* ======= WORD OF THE DAY ======= */}
            <WordOfDay />

            {/* ======= HERO ======= */}
            <div className="hero-gradient text-white relative overflow-hidden">
                {/* Decorative blobs */}
                <div
                    className="absolute top-6 right-8 w-24 h-24 rounded-full opacity-20 float-anim"
                    style={{
                        background:
                            "radial-gradient(circle, skyblue ,transparent)",
                    }}
                />
                <div
                    className="absolute bottom-4 left-6 w-16 h-16 rounded-full opacity-20"
                    style={{
                        background:
                            "radial-gradient(circle, #60a5fa, transparent)",
                    }}
                />

                <div className="max-w-6xl mx-auto px-4 py-12 relative z-10">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                        {/* Left */}
                        <div className="fade-in-up">
                            <div className="inline-flex items-center gap-2 bg-white/20 border border-white/30 rounded-full px-4 py-1.5 text-sm font-semibold mb-5 backdrop-blur-sm">
                                <span className="w-2 h-2 rounded-full bg-yellow-300 animate-pulse" />
                                Daily Quiz — रोज़ शाम 8 बजे
                            </div>

                            <h1 className="text-5xl md:text-6xl font-black mb-3 leading-tight drop-shadow-lg">
                                🎯 Testzy
                            </h1>
                            <p className="text-lg text-pink-100 font-semibold mb-1">
                                {t("tagline")}
                            </p>
                            <p className="text-xl font-bold text-yellow-200 mb-8 drop-shadow">
                                {t("slogan")}
                            </p>

                            <div className="flex flex-wrap gap-3">
                                <button
                                    onClick={handleQuizClick}
                                    className="btn-saffron px-7 py-3.5 rounded-2xl font-bold text-base shadow-lg"
                                >
                                    {t("takeQuiz")}
                                </button>
                                {!user && (
                                    <button
                                        onClick={() => setShowAuthModal(true)}
                                        className="bg-white/20 border-2 border-white/40 hover:bg-white/30 text-white font-bold px-7 py-3.5 rounded-2xl transition-all backdrop-blur-sm shadow"
                                    >
                                        {t("freeSignup")}
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* Right: Timer Card */}
                        <div className="flex justify-center lg:justify-end">
                            <div className="glass-card rounded-3xl p-6 w-72 text-center shadow-2xl">
                                {state === "live" ? (
                                    <div>
                                        <div className="text-5xl mb-3 float-anim">
                                            🔴
                                        </div>
                                        <div className="pulse-live inline-block bg-red-500 text-white px-5 py-2 rounded-full font-bold text-lg mb-3">
                                            LIVE NOW!
                                        </div>
                                        <p className="text-gray-600 text-sm mb-4">
                                            {t("dailyQuizLive")}
                                        </p>
                                        <button
                                            onClick={handleQuizClick}
                                            className="btn-saffron w-full py-3 rounded-xl font-bold"
                                        >
                                            {t("takeQuiz")}
                                        </button>
                                    </div>
                                ) : state === "countdown" ? (
                                    <div>
                                        <div className="text-3xl mb-3 float-anim">
                                            ⏳
                                        </div>
                                        <p
                                            className="font-bold text-sm mb-2"
                                            style={{ color: "#6d28d9" }}
                                        >
                                            {t("quizStartsIn")}
                                        </p>
                                        <div
                                            className="countdown-tick font-mono font-black text-4xl mb-2"
                                            style={{ color: "#6d28d9" }}
                                        >
                                            {timeStr}
                                        </div>
                                        <p className="text-gray-500 text-xs mb-4">
                                            {t("todayAt8")}
                                        </p>
                                        <div
                                            className="rounded-xl p-3 text-xs font-semibold"
                                            style={{
                                                background:
                                                    "linear-gradient(135deg, #fdf4ff, #fce7f3)",
                                                color: "#6d28d9",
                                            }}
                                        >
                                            ⭐ XP Points & Coins मिलेंगे!
                                            <br />
                                            {t("correctPt")}
                                            <br />
                                            {t("wrongPt")}
                                            <br />
                                            {t("minutesQ")}
                                        </div>
                                    </div>
                                ) : (
                                    <div>
                                        <div className="text-4xl mb-3">😴</div>
                                        <p className="text-gray-600 font-semibold">
                                            आज का Quiz खत्म हो गया
                                        </p>
                                        <p className="text-sm text-gray-500 mt-1">
                                            कल शाम 8 बजे फिर आएगा
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* ======= STATS BAR ======= */}
            <div
                className="text-white py-5"
                style={{
                    background:
                        "linear-gradient(135deg, #4c1d95, #6d28d9, #db2777, #f97316)",
                }}
            >
                <div className="max-w-6xl mx-auto px-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                        {[
                            {
                                num:
                                    questionCount === null
                                        ? "..."
                                        : questionCount > 0
                                          ? `${questionCount}+`
                                          : "60+",
                                label: "प्रश्न",
                                icon: "📝",
                            },
                            { num: "6", label: "Categories", icon: "📂" },
                            { num: "3", label: "Practice Modes", icon: "🎯" },
                            { num: "Free", label: "बिल्कुल मुफ्त", icon: "🎁" },
                        ].map((s) => (
                            <div
                                key={s.label}
                                className="flex items-center justify-center gap-2"
                            >
                                <span className="text-2xl">{s.icon}</span>
                                <div className="text-left">
                                    <div className="font-black text-white text-xl drop-shadow">
                                        {s.num}
                                    </div>
                                    <div className="text-xs text-white/80">
                                        {s.label}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* ======= WHY TESTZY ======= */}
            <div className="max-w-6xl mx-auto px-4 py-12">
                <div className="text-center mb-8">
                    <h2
                        className="text-3xl font-black mb-2"
                        style={{
                            background:
                                "linear-gradient(135deg, #6d28d9, #ec4899)",
                            WebkitBackgroundClip: "text",
                            WebkitTextFillColor: "transparent",
                        }}
                    >
                        {t("whyTestzy")}
                    </h2>
                    <p className="text-gray-500">{t("whySubtitle")}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {featureCards.map((f, i) => (
                        <div
                            key={f.title}
                            className={`${f.cls} rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all fade-in-up`}
                            style={{ animationDelay: `${i * 80}ms` }}
                        >
                            <div className="text-4xl mb-3">{f.icon}</div>
                            <h3
                                className="font-bold mb-1"
                                style={{ color: f.textColor }}
                            >
                                {f.title}
                            </h3>
                            <p className="text-gray-600 text-sm">{f.desc}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* ======= BATTLE + MEGA QUIZ PROMO ======= */}
            <div className="max-w-6xl mx-auto px-4 pb-10">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Battle Mode Card */}
                    <div
                        onClick={() => navigate("/battle")}
                        className="cursor-pointer rounded-3xl p-6 text-white shadow-xl hover:scale-[1.02] transition-transform relative overflow-hidden"
                        style={{
                            background:
                                "linear-gradient(135deg, #7f1d1d, #dc2626, #b91c1c)",
                        }}
                    >
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10" />
                        <div className="relative z-10">
                            <div className="text-5xl mb-3">⚔️</div>
                            <h3 className="text-2xl font-black mb-1">
                                {t("battleTitle")}
                            </h3>
                            <p className="text-red-200 text-sm mb-4">
                                {t("battleSub")}
                            </p>
                            <div className="flex gap-3 flex-wrap">
                                <span className="bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full">
                                    {t("battleWin")}
                                </span>
                                <span className="bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full">
                                    {t("battleCoins")}
                                </span>
                            </div>
                            <div className="mt-4 bg-white/20 hover:bg-white/30 transition-colors rounded-xl py-2.5 px-4 text-center font-bold text-sm">
                                {t("battleStart")}
                            </div>
                        </div>
                    </div>

                    {/* Mega Quiz Card */}
                    <div
                        onClick={() => navigate("/mega-quiz")}
                        className="cursor-pointer rounded-3xl p-6 text-white shadow-xl hover:scale-[1.02] transition-transform relative overflow-hidden"
                        style={{
                            background:
                                "linear-gradient(135deg, #78350f, #d97706, #f59e0b)",
                        }}
                    >
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10" />
                        <div className="relative z-10">
                            <div className="text-5xl mb-3">🏆</div>
                            <h3 className="text-2xl font-black mb-1">
                                {t("megaTitle")}
                            </h3>
                            <p className="text-amber-100 text-sm mb-4">
                                {t("megaSub")}
                            </p>
                            <div className="flex gap-3 flex-wrap">
                                <span className="bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full">
                                    {t("megaEntry")}
                                </span>
                                <span className="bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full">
                                    {t("megaPrize")}
                                </span>
                            </div>
                            <div className="mt-4 bg-white/20 hover:bg-white/30 transition-colors rounded-xl py-2.5 px-4 text-center font-bold text-sm">
                                {t("megaRegister")}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* ======= CATEGORY CARDS ======= */}
            <div className="max-w-6xl mx-auto px-4 pb-10">
                <div className="text-center mb-8">
                    <h2
                        className="text-3xl font-black mb-2"
                        style={{
                            background:
                                "linear-gradient(135deg, #f97316, #ec4899)",
                            WebkitBackgroundClip: "text",
                            WebkitTextFillColor: "transparent",
                        }}
                    >
                        {t("chooseCategory")}
                    </h2>
                    <p className="text-gray-500">{t("chooseCatSub")}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    {categories.map((cat, idx) => (
                        <div
                            key={cat.id}
                            onClick={() => handleCategoryClick(cat.id)}
                            className="category-card rounded-2xl shadow-md cursor-pointer overflow-hidden fade-in-up"
                            style={{
                                animationDelay: `${idx * 60}ms`,
                                background: "white",
                            }}
                        >
                            {/* Bold colorful top bar */}
                            <div
                                className="h-2 w-full"
                                style={{
                                    background: `linear-gradient(90deg, ${cat.color}, ${cat.color}88)`,
                                }}
                            />
                            <div className="p-5">
                                <div className="flex items-start justify-between mb-3">
                                    <div
                                        className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow"
                                        style={{ backgroundColor: cat.bgColor }}
                                    >
                                        {cat.icon}
                                    </div>
                                    <span
                                        className="text-xs font-bold px-3 py-1 rounded-full"
                                        style={{
                                            backgroundColor: cat.bgColor,
                                            color: cat.color,
                                        }}
                                    >
                                        {t("practiceNow")}
                                    </span>
                                </div>
                                <h3 className="font-black text-gray-800 text-lg mb-1">
                                    {cat.name}
                                </h3>
                                <p className="text-gray-500 text-sm mb-4">
                                    {cat.description}
                                </p>
                                <div
                                    className="w-full text-center py-2.5 rounded-xl font-bold text-sm text-white shadow"
                                    style={{
                                        background: `linear-gradient(135deg, ${cat.color}, ${cat.color}bb)`,
                                    }}
                                >
                                    {t("startPractice")}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* ======= WEEKLY MEGA QUIZ PRIZES ======= */}
            <div
                className="relative overflow-hidden"
                style={{
                    background:
                        "linear-gradient(135deg, #78350f 0%, #d97706 40%, #f59e0b 80%, #fbbf24 100%)",
                }}
            >
                {/* Hero Image Banner */}
                <div
                    className="relative w-full overflow-hidden"
                    style={{ maxHeight: 340 }}
                >
                    {/* Gradient fade into section below */}
                    <div
                        className="absolute inset-0"
                        style={{
                            background:
                                "linear-gradient(to bottom, transparent 40%, rgba(120,53,15,0.85) 100%)",
                        }}
                    />
                    {/* Floating badge */}
                    <div className="absolute top-4 left-1/2 -translate-x-1/2">
                        <div className="inline-flex items-center gap-2 bg-black/40 border border-white/40 rounded-full px-5 py-2 text-sm font-bold text-white backdrop-blur-sm shadow-xl">
                            🏆 Weekly Mega Quiz —{" "}
                            {megaSettings?.quiz_date
                                ? new Date(
                                      megaSettings.quiz_date,
                                  ).toLocaleDateString("hi-IN", {
                                      weekday: "long",
                                      day: "numeric",
                                      month: "long",
                                  })
                                : "हर Sunday 8 PM"}
                        </div>
                    </div>
                </div>

                <div className="py-8 px-4">
                    <div className="max-w-4xl mx-auto text-center">
                        <h2 className="text-3xl font-black text-white mb-1 drop-shadow">
                            ₹{megaSettings?.entry_fee ?? 10} Entry — Prize Money
                            जीतो!
                        </h2>
                        <p className="text-amber-100 mb-8 font-semibold text-sm">
                            {megaSettings?.title || "Weekly Mega Quiz"} • ₹
                            {megaSettings?.entry_fee ?? 10} Entry Fee • Top 5 को
                            Cash Prize
                        </p>

                        {/* Top 3 Prizes */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                            {(
                                megaSettings?.prizes?.slice(0, 3) ||
                                MEGA_PRIZES.slice(0, 3)
                            ).map((p: any, i) => {
                                const icons = ["🥇", "🥈", "🥉"];
                                const styles = [
                                    {
                                        background:
                                            "linear-gradient(135deg, #fef3c7, #fde68a)",
                                        border: "2.5px solid #f59e0b",
                                        color: "#f59e0b",
                                    },
                                    {
                                        background:
                                            "linear-gradient(135deg, #f9fafb, #e5e7eb)",
                                        border: "2.5px solid #94a3b8",
                                        color: "#64748b",
                                    },
                                    {
                                        background:
                                            "linear-gradient(135deg, #fef9c3, #fde68a88)",
                                        border: "2.5px solid #f97316",
                                        color: "#b45309",
                                    },
                                ];
                                return (
                                    <div
                                        key={i}
                                        className="rounded-2xl p-6 text-center shadow-xl hover:scale-[1.03] transition-transform"
                                        style={styles[i]}
                                    >
                                        <div className="text-4xl mb-2">
                                            {icons[i]}
                                        </div>
                                        <div className="font-black text-gray-800 text-base mb-1">
                                            {i + 1}
                                            {i === 0
                                                ? "st"
                                                : i === 1
                                                  ? "nd"
                                                  : "rd"}{" "}
                                            Prize
                                        </div>
                                        <div
                                            className="font-black text-3xl mt-2"
                                            style={{ color: styles[i].color }}
                                        >
                                            {p.amount}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                        {/* 4th & 5th Prizes */}
                        <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto mb-6">
                            {(
                                megaSettings?.prizes?.slice(3, 5) ||
                                MEGA_PRIZES.slice(3)
                            ).map((p: any, i) => (
                                <div
                                    key={i}
                                    className="bg-white/20 border border-white/30 rounded-xl p-3 text-center backdrop-blur-sm"
                                >
                                    <div className="text-xl mb-1">
                                        {i === 0 ? "🏅" : "🏅"}
                                    </div>
                                    <div className="font-bold text-white text-sm">
                                        {i + 4}th Prize
                                    </div>
                                    <div className="text-yellow-200 font-black text-lg mt-0.5">
                                        {p.amount}
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Note: Daily Quiz only gives points */}
                        <div className="bg-white/15 border border-white/25 rounded-2xl px-6 py-4 max-w-xl mx-auto backdrop-blur-sm">
                            <p className="text-white font-semibold text-sm">
                                📝{" "}
                                <span className="font-black">Daily Quiz</span> —
                                सिर्फ XP Points मिलेंगे, prize नहीं
                            </p>
                            <p className="text-amber-100 text-xs mt-1">
                                Cash prizes सिर्फ Weekly Mega Quiz (₹10 entry)
                                में मिलते हैं
                            </p>
                        </div>

                        <button
                            onClick={() => navigate("/mega-quiz")}
                            className="mt-6 bg-white text-amber-700 font-black px-8 py-3 rounded-2xl shadow-xl hover:bg-amber-50 transition-all text-sm"
                        >
                            🏆 Mega Quiz में Register करें →
                        </button>
                    </div>
                </div>
            </div>

            {/* ── Refer & Earn + Reviews + Help + Doubts ── */}
            <div className="max-w-5xl mx-auto px-4 py-10">
                <h2 className="text-2xl font-black text-[#1a3a6b] text-center mb-2">
                    और भी Features
                </h2>
                <p className="text-gray-500 text-sm text-center mb-6">
                    Friends को invite करें, doubt पूछें, review दें, या help लें
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Refer & Earn */}
                    <div
                        onClick={() => navigate("/referral")}
                        className="cursor-pointer bg-gradient-to-br from-purple-50 to-violet-100 border-2 border-purple-200 rounded-3xl p-6 text-center hover:shadow-lg transition-all hover:-translate-y-1"
                    >
                        <div className="text-5xl mb-3">🎁</div>
                        <h3 className="font-black text-purple-800 text-lg mb-2">
                            Refer & Earn
                        </h3>
                        <p className="text-purple-600 text-sm mb-4">
                            दोस्तों को invite करें — दोनों को +50 XP और +20
                            Coins मिलेंगे!
                        </p>
                        <div className="bg-purple-600 text-white font-bold text-sm py-2.5 px-5 rounded-2xl inline-block">
                            Referral Code पाएं →
                        </div>
                    </div>

                    {/* Reviews */}
                    <div
                        onClick={() => navigate("/reviews")}
                        className="cursor-pointer bg-gradient-to-br from-amber-50 to-yellow-100 border-2 border-yellow-200 rounded-3xl p-6 text-center hover:shadow-lg transition-all hover:-translate-y-1"
                    >
                        <div className="text-5xl mb-3">⭐</div>
                        <h3 className="font-black text-amber-800 text-lg mb-2">
                            User Reviews
                        </h3>
                        <p className="text-amber-600 text-sm mb-4">
                            हमारे students का अनुभव पढ़ें या अपना review दें!
                        </p>
                        <div className="bg-amber-500 text-white font-bold text-sm py-2.5 px-5 rounded-2xl inline-block">
                            Reviews देखें →
                        </div>
                    </div>

                    {/* Help Center */}
                    <div
                        onClick={() => navigate("/help")}
                        className="cursor-pointer bg-gradient-to-br from-blue-50 to-cyan-100 border-2 border-blue-200 rounded-3xl p-6 text-center hover:shadow-lg transition-all hover:-translate-y-1"
                    >
                        <div className="text-5xl mb-3">🛟</div>
                        <h3 className="font-black text-blue-800 text-lg mb-2">
                            Help Center
                        </h3>
                        <p className="text-blue-600 text-sm mb-4">
                            कोई problem? FAQ पढ़ें या query submit करें — 24
                            घंटे में reply!
                        </p>
                        <div className="bg-blue-600 text-white font-bold text-sm py-2.5 px-5 rounded-2xl inline-block">
                            Help लें →
                        </div>
                    </div>

                    {/* Doubt Forum */}
                    <div
                        onClick={() => navigate("/doubts")}
                        className="cursor-pointer bg-gradient-to-br from-emerald-50 to-teal-100 border-2 border-emerald-200 rounded-3xl p-6 text-center hover:shadow-lg transition-all hover:-translate-y-1"
                    >
                        <div className="text-5xl mb-3">🤔</div>
                        <h3 className="font-black text-emerald-800 text-lg mb-2">
                            Doubt Forum
                        </h3>
                        <p className="text-emerald-600 text-sm mb-4">
                            कोई भी exam doubt पूछें — students और admin मिलकर
                            जवाब देंगे!
                        </p>
                        <div className="bg-emerald-600 text-white font-bold text-sm py-2.5 px-5 rounded-2xl inline-block">
                            Doubt पूछें →
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
