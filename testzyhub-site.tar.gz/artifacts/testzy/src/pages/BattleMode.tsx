import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { io, type Socket } from "socket.io-client";

type Phase = "lobby" | "queue" | "question" | "result" | "end";

type Question = {
  index: number; total: number;
  question: string; options: string[];
  timeLimit: number;
};

type BattleEnd = {
  scores: { p1: number; p2: number };
  winner: "p1" | "p2" | "draw";
  winnerName: string | null;
  rewards: { p1?: { xp: number; coins: number }; p2?: { xp: number; coins: number } };
};

const ADS = [
  "🎓 SSC CGL 2025 की तैयारी शुरू करें — Free Mock Test",
  "📖 Railway Group D Notes PDF — Download Now",
  "🏆 UPSC Prelims 2025 — Complete Study Material",
];

export default function BattleMode() {
  const [, navigate] = useLocation();
  const { user, setShowAuthModal, updateUser } = useAuth();
  const [phase, setPhase] = useState<Phase>("lobby");
  const [socket, setSocket] = useState<Socket | null>(null);
  const [currentQ, setCurrentQ] = useState<Question | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [correctAnswer, setCorrectAnswer] = useState<number | null>(null);
  const [p1Answer, setP1Answer] = useState<number | null>(null);
  const [p2Answer, setP2Answer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(30);
  const [scores, setScores] = useState({ p1: 0, p2: 0 });
  const [opponentAnswered, setOpponentAnswered] = useState(false);
  const [battleEnd, setBattleEnd] = useState<BattleEnd | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [opponent, setOpponent] = useState<string>("");
  const [myRole, setMyRole] = useState<"p1" | "p2">("p1");
  const [adIdx, setAdIdx] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    const interval = setInterval(() => setAdIdx((i) => (i + 1) % ADS.length), 4000);
    return () => clearInterval(interval);
  }, []);

  const connectSocket = useCallback(() => {
    if (!user) return;
    const s = io(window.location.origin, {
      path: "/api/socket.io",
      auth: { userId: user.id, name: user.name },
      transports: ["polling", "websocket"],
    });
    socketRef.current = s;
    setSocket(s);

    s.on("queue-joined", () => setPhase("queue"));
    s.on("queue-left", () => setPhase("lobby"));

    s.on("battle-start", ({ roomId: rid, opponent: opp }: { roomId: string; opponent: Record<string, string> }) => {
      setRoomId(rid);
      // Determine role
      const role = opp.p1 === user.name ? "p2" : "p1";
      setMyRole(role);
      setOpponent(opp[role === "p1" ? "p2" : "p1"] || "Opponent");
    });

    s.on("question", (q: Question) => {
      setCurrentQ(q);
      setSelectedAnswer(null);
      setCorrectAnswer(null);
      setP1Answer(null);
      setP2Answer(null);
      setOpponentAnswered(false);
      setTimeLeft(q.timeLimit);
      setPhase("question");
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setTimeLeft((t) => { if (t <= 1) { clearInterval(timerRef.current!); return 0; } return t - 1; });
      }, 1000);
    });

    s.on("opponent-answered", () => setOpponentAnswered(true));

    s.on("question-result", (data: { index: number; correct: number; p1Answer: number | null; p2Answer: number | null; scores: { p1: number; p2: number } }) => {
      if (timerRef.current) clearInterval(timerRef.current);
      setCorrectAnswer(data.correct);
      setP1Answer(data.p1Answer);
      setP2Answer(data.p2Answer);
      setScores(data.scores);
      setPhase("result");
    });

    s.on("battle-end", (data: BattleEnd) => {
      setBattleEnd(data);
      setPhase("end");
      if (timerRef.current) clearInterval(timerRef.current);
      // Update user coins and XP
      const myReward = myRole === "p1" ? data.rewards.p1 : data.rewards.p2;
      if (myReward && user) {
        updateUser({ xp: user.xp + myReward.xp, coins: user.coins + myReward.coins });
      }
    });

    s.on("opponent-disconnected", () => {
      alert("Opponent disconnect ho gaya! Aap winner hain 🏆");
      setPhase("lobby");
    });

    return s;
  }, [user, myRole, updateUser]);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      socketRef.current?.disconnect();
    };
  }, []);

  function joinQueue() {
    if (!user) { setShowAuthModal(true); return; }
    const s = connectSocket();
    s?.emit("join-queue");
  }

  function leaveQueue() {
    socketRef.current?.emit("leave-queue");
    setPhase("lobby");
    socketRef.current?.disconnect();
    socketRef.current = null;
    setSocket(null);
  }

  function submitAnswer(idx: number) {
    if (selectedAnswer !== null || !socket || !roomId) return;
    setSelectedAnswer(idx);
    socket.emit("submit-answer", { roomId, answer: idx, timeLeft });
  }

  function myAnswer() {
    return myRole === "p1" ? p1Answer : p2Answer;
  }

  // ── LOBBY ────────────────────────────────────────────────────────────────────
  if (phase === "lobby") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-950 via-gray-900 to-purple-950 pb-20 lg:pb-0">
        {/* Ad Banner */}
        <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-center py-2 text-sm font-semibold px-4">
          📢 {ADS[adIdx]}
        </div>
        <div className="max-w-2xl mx-auto px-4 py-12 text-center">
          <div className="text-8xl mb-6 animate-bounce">⚔️</div>
          <h1 className="text-4xl font-black text-white mb-3">1v1 Battle Mode</h1>
          <p className="text-gray-400 mb-8 text-lg">Real-time multiplayer quiz — अपने opponent को challenge करें!</p>

          <div className="grid grid-cols-3 gap-4 mb-10">
            {[
              { icon: "⚡", label: "30 sec/question", desc: "Fast paced" },
              { icon: "🏆", label: "Winner gets", desc: "+100 XP, 20 🪙" },
              { icon: "🎯", label: "10 Questions", desc: "Random mix" },
            ].map((s) => (
              <div key={s.label} className="bg-white/10 backdrop-blur rounded-2xl p-4 text-white">
                <div className="text-3xl mb-2">{s.icon}</div>
                <div className="font-bold text-sm">{s.label}</div>
                <div className="text-xs text-gray-400">{s.desc}</div>
              </div>
            ))}
          </div>

          {user ? (
            <div className="space-y-4">
              <div className="bg-white/10 rounded-2xl p-4 text-white text-left">
                <p className="font-semibold text-sm text-gray-300 mb-1">आपकी Stats:</p>
                <div className="flex gap-4">
                  <span>⚡ {user.xp} XP</span>
                  <span>🏅 {user.level}</span>
                  <span>🪙 {user.coins}</span>
                </div>
              </div>
              <button onClick={joinQueue}
                className="w-full py-4 rounded-2xl text-xl font-black text-white shadow-xl hover:scale-105 transition-transform"
                style={{ background: "linear-gradient(135deg, #dc2626, #b91c1c)" }}>
                ⚔️ Battle शुरू करें
              </button>
            </div>
          ) : (
            <button onClick={() => setShowAuthModal(true)}
              className="w-full py-4 rounded-2xl text-xl font-black text-white"
              style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}>
              Login करें — फिर Battle!
            </button>
          )}

          <button onClick={() => navigate("/")} className="mt-6 text-gray-500 hover:text-gray-300 text-sm transition-colors">
            ← वापस जाएं
          </button>
        </div>
      </div>
    );
  }

  // ── QUEUE ────────────────────────────────────────────────────────────────────
  if (phase === "queue") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-950 via-gray-900 to-purple-950 flex items-center justify-center pb-20 lg:pb-0">
        <div className="text-center text-white">
          <div className="text-7xl mb-6 animate-pulse">🔍</div>
          <h2 className="text-3xl font-black mb-2">Opponent ढूंढ रहे हैं...</h2>
          <p className="text-gray-400 mb-8">कोई भी online player मिलते ही battle शुरू होगी!</p>
          <div className="flex justify-center gap-2 mb-8">
            {[0, 1, 2].map((i) => (
              <div key={i} className="w-3 h-3 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
            ))}
          </div>
          <button onClick={leaveQueue}
            className="px-8 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold transition-all">
            ✕ Queue छोड़ें
          </button>
        </div>
      </div>
    );
  }

  // ── QUESTION ─────────────────────────────────────────────────────────────────
  if ((phase === "question" || phase === "result") && currentQ) {
    const isResult = phase === "result";
    const myAns = myAnswer();

    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 pb-20 lg:pb-0">
        {/* Header */}
        <div className="bg-black/40 px-4 py-3">
          <div className="max-w-2xl mx-auto flex items-center justify-between">
            <div className="text-white">
              <span className="text-xs text-gray-400">आप</span>
              <div className="font-black text-sm">{user?.name?.split(" ")[0]}</div>
              <div className="text-2xl font-black text-green-400">{scores[myRole]}</div>
            </div>
            <div className="text-center">
              <div className={`text-3xl font-black ${timeLeft <= 10 ? "text-red-400 animate-pulse" : "text-white"}`}>
                {timeLeft}s
              </div>
              <div className="text-xs text-gray-400">Q{currentQ.index + 1}/{currentQ.total}</div>
              <div className="w-24 h-1.5 bg-gray-700 rounded-full mt-1 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-green-500 to-red-500 rounded-full transition-all"
                  style={{ width: `${(timeLeft / currentQ.timeLimit) * 100}%` }} />
              </div>
            </div>
            <div className="text-white text-right">
              <span className="text-xs text-gray-400">{opponent}</span>
              <div className="font-black text-sm">{opponent.split(" ")[0]}</div>
              <div className="text-2xl font-black text-blue-400">{scores[myRole === "p1" ? "p2" : "p1"]}</div>
            </div>
          </div>
        </div>

        <div className="max-w-2xl mx-auto px-4 py-6">
          {/* Question */}
          <div className="bg-white/10 backdrop-blur rounded-2xl p-6 mb-6">
            <p className="text-white text-lg font-semibold leading-relaxed">{currentQ.question}</p>
            {opponentAnswered && !isResult && (
              <div className="mt-3 flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                <span className="text-blue-300 text-sm font-semibold">{opponent} ने जवाब दे दिया!</span>
              </div>
            )}
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 gap-3">
            {currentQ.options.map((opt, idx) => {
              let bg = "bg-white/10 border-white/20 text-white hover:bg-white/20";
              if (isResult) {
                if (idx === correctAnswer) bg = "bg-green-500/30 border-green-400 text-green-200";
                else if (idx === myAns && idx !== correctAnswer) bg = "bg-red-500/30 border-red-400 text-red-200";
                else bg = "bg-white/5 border-white/10 text-gray-400";
              } else if (selectedAnswer === idx) {
                bg = "bg-purple-500/40 border-purple-400 text-purple-100";
              }
              return (
                <button key={idx} onClick={() => submitAnswer(idx)} disabled={selectedAnswer !== null || isResult}
                  className={`border-2 rounded-xl p-4 text-left font-semibold transition-all ${bg}`}>
                  <span className="text-sm opacity-70 mr-2">{["A", "B", "C", "D"][idx]})</span>
                  {opt}
                  {isResult && idx === correctAnswer && <span className="float-right">✅</span>}
                  {isResult && idx === myAns && idx !== correctAnswer && <span className="float-right">❌</span>}
                </button>
              );
            })}
          </div>

          {isResult && (
            <div className="mt-4 bg-white/10 rounded-xl p-4 text-center">
              <p className="text-gray-300 text-sm">Scores: आप <span className="text-green-400 font-black">{scores[myRole]}</span> — {opponent} <span className="text-blue-400 font-black">{scores[myRole === "p1" ? "p2" : "p1"]}</span></p>
              <p className="text-gray-400 text-xs mt-1">अगला question आ रहा है...</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── BATTLE END ────────────────────────────────────────────────────────────────
  if (phase === "end" && battleEnd) {
    const iWon = battleEnd.winner === myRole;
    const isDraw = battleEnd.winner === "draw";
    const myReward = myRole === "p1" ? battleEnd.rewards.p1 : battleEnd.rewards.p2;

    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-950 flex items-center justify-center px-4 pb-20 lg:pb-0">
        <div className="text-center text-white max-w-md w-full">
          <div className="text-8xl mb-4">{isDraw ? "🤝" : iWon ? "🏆" : "😔"}</div>
          <h2 className="text-4xl font-black mb-2">{isDraw ? "Draw!" : iWon ? "जीत गए!" : "हार गए!"}</h2>
          <p className="text-gray-400 mb-6">{isDraw ? "दोनों बराबर रहे!" : iWon ? "शानदार performance!" : `${battleEnd.winnerName || "Opponent"} जीते!`}</p>

          <div className="bg-white/10 rounded-2xl p-6 mb-6">
            <div className="flex justify-center gap-8 mb-4">
              <div><div className="text-3xl font-black text-green-400">{battleEnd.scores[myRole]}</div><div className="text-sm text-gray-400">आपके</div></div>
              <div className="text-gray-500 text-2xl font-black">VS</div>
              <div><div className="text-3xl font-black text-red-400">{battleEnd.scores[myRole === "p1" ? "p2" : "p1"]}</div><div className="text-sm text-gray-400">{opponent}</div></div>
            </div>
            {myReward && (
              <div className="border-t border-white/10 pt-4">
                <p className="text-sm text-gray-300 mb-3">आपको मिला:</p>
                <div className="flex justify-center gap-6">
                  <div className="bg-purple-500/20 rounded-xl px-4 py-2"><div className="text-2xl font-black text-purple-300">+{myReward.xp}</div><div className="text-xs text-gray-400">XP</div></div>
                  <div className="bg-yellow-500/20 rounded-xl px-4 py-2"><div className="text-2xl font-black text-yellow-300">+{myReward.coins}</div><div className="text-xs text-gray-400">Coins 🪙</div></div>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <button onClick={() => { setPhase("lobby"); socketRef.current?.disconnect(); socketRef.current = null; }}
              className="flex-1 py-3 rounded-xl bg-white/10 hover:bg-white/20 font-bold transition-all">
              फिर खेलें ⚔️
            </button>
            <button onClick={() => navigate("/")}
              className="flex-1 py-3 rounded-xl font-bold text-white"
              style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899)" }}>
              Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
