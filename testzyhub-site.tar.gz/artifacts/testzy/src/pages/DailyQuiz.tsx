import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { getDailyQuizQuestions, categories, type Question } from "@/data/questions";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTranslatedQuestion } from "@/hooks/useTranslatedQuestion";
import { useAntiCheat, checkAlreadyAttempted } from "@/hooks/useAntiCheat";

const DAILY_TOTAL_TIME = 30 * 60; // 30 minutes

export default function DailyQuiz() {
  const [, navigate] = useLocation();
  const { user, setShowAuthModal, refreshUser } = useAuth();
  const { t } = useLanguage();

  const [phase, setPhase] = useState<"intro" | "quiz" | "done">("intro");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [timeLeft, setTimeLeft] = useState(DAILY_TOTAL_TIME);
  const [submitted, setSubmitted] = useState(false);
  const [rewards, setRewards] = useState<{ xp: number; coins: number } | null>(null);
  const [alreadyAttempted, setAlreadyAttempted] = useState(false);
  const [bookmarked, setBookmarked] = useState<Set<number>>(new Set());
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tq = useTranslatedQuestion(questions[currentIdx] ?? null);

  useEffect(() => {
    if (!user) return;
    checkAlreadyAttempted("daily").then((attempted) => setAlreadyAttempted(attempted));
  }, [user]);

  const handleViolation = useCallback(() => {
    clearInterval(timerRef.current!);
    setPhase("done");
  }, []);

  const { warning: antiCheatWarning } = useAntiCheat({
    isActive: phase === "quiz",
    onViolation: handleViolation,
  });

  const isLive = (() => {
    const h = new Date().getHours();
    return h >= 20 && h < 23;
  })();

  const [countdown, setCountdown] = useState("");
  useEffect(() => {
    function update() {
      const now = new Date();
      const h = now.getHours();
      if (h >= 20 && h < 23) { setCountdown(""); return; }
      const target = new Date(now);
      target.setHours(20, 0, 0, 0);
      if (now >= target) { target.setDate(target.getDate() + 1); target.setHours(20, 0, 0, 0); }
      const diff = Math.max(0, target.getTime() - now.getTime());
      const hrs = Math.floor(diff / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      const secs = Math.floor((diff % 60000) / 1000);
      setCountdown(`${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`);
    }
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  function startQuiz() {
    if (!user) { setShowAuthModal(true); return; }
    const qs = getDailyQuizQuestions();
    setQuestions(qs);
    setAnswers(new Array(qs.length).fill(null));
    setCurrentIdx(0);
    setTimeLeft(DAILY_TOTAL_TIME);
    setPhase("quiz");
    fetch("/api/streak/update", { method: "POST", credentials: "include" }).catch(() => {});
  }

  async function toggleBookmark(q: Question) {
    if (!user) return;
    const opts = q.options || [];
    await fetch("/api/bookmarks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        question_text: q.question,
        options: opts,
        correct_answer: opts[q.correct],
        explanation: q.explanation || "",
        subject: q.subject || q.category || "",
        category: q.category || "",
      }),
    });
    setBookmarked((prev) => {
      const next = new Set(prev);
      const key = questions.indexOf(q);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  }

  useEffect(() => {
    if (phase !== "quiz") return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) { clearInterval(timerRef.current!); setPhase("done"); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [phase]);

  function handleSelect(idx: number) {
    if (answers[currentIdx] !== null) return;
    const updated = [...answers];
    updated[currentIdx] = idx;
    setAnswers(updated);
  }

  function handleNext() {
    if (currentIdx + 1 >= questions.length) {
      clearInterval(timerRef.current!);
      setPhase("done");
    } else {
      setCurrentIdx((i) => i + 1);
    }
  }

  const correctCount = answers.filter((a, i) => a !== null && a === questions[i]?.correct).length;
  const wrongCount = answers.filter((a, i) => a !== null && a !== questions[i]?.correct).length;
  const points = Math.max(0, correctCount - wrongCount * 0.5);

  async function submitResult() {
    if (submitted || !user) return;
    setSubmitted(true);
    try {
      const res = await fetch("/api/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          quizType: "daily",
          category: null,
          correctCount,
          wrongCount,
          totalQuestions: questions.length,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (data.xpEarned !== undefined) setRewards({ xp: data.xpEarned, coins: data.coinsEarned || 0 });
      await refreshUser();
    } catch {}
  }

  useEffect(() => {
    if (phase === "done") submitResult();
  }, [phase]);

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  // ===== INTRO PHASE =====
  if (phase === "intro") {
    return (
      <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "linear-gradient(135deg, #0f2548 0%, #1a3a6b 60%, #2c5aa0 100%)" }}>
        <div className="max-w-xl mx-auto px-4 py-10">
          <button onClick={() => navigate("/")} className="text-white/70 hover:text-white text-sm mb-8 flex items-center gap-1">
            ← Home
          </button>

          <div className="text-center text-white mb-8">
            <div className="text-6xl mb-4">⚡</div>
            <h1 className="text-4xl font-black mb-2">Daily Quiz</h1>
            <p className="text-blue-200">रोज़ शाम 8 बजे • 90 Questions • 30 Minutes</p>
          </div>

          {/* Already Attempted */}
          {alreadyAttempted && (
            <div className="glass-card rounded-3xl p-6 mb-6 text-center border-2 border-orange-300">
              <div className="text-5xl mb-3">✅</div>
              <h3 className="font-black text-xl text-gray-800 mb-1">आज का Quiz दे दिया!</h3>
              <p className="text-gray-600 text-sm mb-4">
                आप आज का Daily Quiz पहले ही दे चुके हैं।<br />
                कल शाम 8 बजे फिर आएगा नया Quiz।
              </p>
              <button onClick={() => navigate("/")} className="btn-primary px-6 py-3 rounded-2xl font-bold text-sm">
                ← Home पर जाएं
              </button>
            </div>
          )}

          {/* Live Status */}
          {!alreadyAttempted && isLive ? (
            <div className="glass-card rounded-3xl p-6 mb-6 text-center">
              <div className="inline-flex items-center gap-2 bg-red-500 text-white px-4 py-1.5 rounded-full font-bold text-sm mb-4 pulse-live">
                🔴 LIVE NOW!
              </div>
              <p className="text-gray-700 font-semibold mb-5">Daily Quiz अभी Live है! जल्दी Start करें।</p>
              <button onClick={startQuiz} className="btn-saffron w-full py-4 rounded-2xl text-lg font-black">
                ⚡ Quiz Start करें!
              </button>
            </div>
          ) : !alreadyAttempted && (
            <div className="glass-card rounded-3xl p-6 mb-6 text-center">
              <p className="text-gray-600 font-semibold mb-2">Quiz शुरू होने में</p>
              <div className="countdown-tick font-mono font-black text-5xl text-[#1a3a6b] mb-2">{countdown}</div>
              <p className="text-gray-500 text-sm mb-5">आज शाम 8:00 PM बजे</p>
              <button
                onClick={startQuiz}
                className="btn-primary w-full py-4 rounded-2xl text-base font-bold"
              >
                Practice Mode में Try करें
              </button>
            </div>
          )}

          {/* Rules */}
          <div className="bg-white/10 border border-white/20 rounded-2xl p-5 text-white">
            <h3 className="font-bold text-lg mb-3">📋 Quiz Rules</h3>
            <div className="space-y-2 text-sm text-blue-100">
              <div className="flex items-center gap-2"><span>📝</span> 90 Questions (सभी Categories से)</div>
              <div className="flex items-center gap-2"><span>⏱️</span> 30 Minutes का समय</div>
              <div className="flex items-center gap-2"><span>✅</span> सही उत्तर = +1 Point</div>
              <div className="flex items-center gap-2"><span>❌</span> गलत उत्तर = -0.5 Point</div>
              <div className="flex items-center gap-2"><span>⭐</span> XP Points & Coins मिलेंगे (Prize नहीं)</div>
              <div className="flex items-center gap-2"><span>📅</span> रोज़ शाम 8 बजे नया Quiz</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ===== DONE PHASE =====
  if (phase === "done") {
    const pct = questions.length > 0 ? Math.round((correctCount / questions.length) * 100) : 0;
    return (
      <div className="min-h-screen flex items-center justify-center px-4 pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
        <div className="bg-white rounded-3xl shadow-xl p-8 max-w-md w-full text-center fade-in-up">
          <div className="text-5xl mb-3">{pct >= 80 ? "🎉" : pct >= 60 ? "⚡" : "📚"}</div>
          <h2 className="text-2xl font-black text-[#1a3a6b] mb-1">Daily Quiz Complete!</h2>
          <p className="text-gray-500 mb-5 text-sm">आपका result Leaderboard पर दर्ज हो गया।</p>

          <div className="hero-gradient text-white rounded-2xl p-6 mb-5">
            <div className="text-5xl font-black mb-1">+{points.toFixed(1)}</div>
            <div className="text-blue-200 text-sm">Points अर्जित किए • {correctCount}/{questions.length} सही • {pct}%</div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-5 text-sm">
            <div className="bg-green-50 rounded-xl p-3"><div className="font-black text-green-700 text-xl">{correctCount}</div><div className="text-green-600 text-xs">सही</div></div>
            <div className="bg-red-50 rounded-xl p-3"><div className="font-black text-red-700 text-xl">{wrongCount}</div><div className="text-red-600 text-xs">गलत</div></div>
            <div className="bg-blue-50 rounded-xl p-3"><div className="font-black text-[#1a3a6b] text-xl">{points.toFixed(1)}</div><div className="text-blue-600 text-xs">Points</div></div>
          </div>

          {rewards && (
            <div className="flex gap-3 mb-4">
              <div className="flex-1 bg-purple-50 border border-purple-200 rounded-2xl p-3 text-center">
                <div className="font-black text-purple-700 text-2xl">+{rewards.xp}</div>
                <div className="text-purple-500 text-xs font-semibold">XP मिले ⚡</div>
              </div>
              <div className="flex-1 bg-yellow-50 border border-yellow-200 rounded-2xl p-3 text-center">
                <div className="font-black text-yellow-700 text-2xl">+{rewards.coins}</div>
                <div className="text-yellow-500 text-xs font-semibold">Coins 🪙</div>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={() => navigate("/leaderboard")} className="flex-1 btn-primary py-3 rounded-xl text-sm">
              🏆 Leaderboard देखें
            </button>
            <button onClick={() => navigate("/")} className="flex-1 bg-gray-100 text-gray-700 font-semibold py-3 rounded-xl text-sm">
              🏠 Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ===== QUIZ PHASE =====
  if (questions.length === 0) return <div className="min-h-screen flex items-center justify-center"><p className="text-gray-500">Loading...</p></div>;

  const current = questions[currentIdx];
  const catInfo = categories.find((c) => c.id === current.category);
  const timerUrgent = timeLeft <= 120;

  return (
    <div className="min-h-screen pb-20 lg:pb-4" style={{ background: "var(--gray-50)" }}>
      {/* Anti-cheat warning overlay */}
      {antiCheatWarning && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center bg-red-900/90 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-8 max-w-sm mx-4 text-center shadow-2xl">
            <div className="text-5xl mb-3">⚠️</div>
            <h3 className="text-xl font-black text-red-600 mb-2">Tab Switch Detected!</h3>
            <p className="text-gray-700 text-sm mb-3">
              Quiz में cheating की कोशिश पकड़ी गई।<br />
              <strong>Quiz अपने आप Submit हो रहा है...</strong>
            </p>
            <div className="w-full bg-red-100 rounded-full h-2 mt-3">
              <div className="bg-red-500 h-2 rounded-full animate-pulse" style={{ width: "100%" }} />
            </div>
          </div>
        </div>
      )}

      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-[#1a3a6b] text-sm">⚡ Daily Quiz</span>
            <div className={`font-mono font-black text-lg px-4 py-1 rounded-lg ${timerUrgent ? "timer-urgent bg-red-50" : "text-orange-600 bg-orange-50"}`}>
              ⏱ {formatTime(timeLeft)}
            </div>
            <span className="text-sm text-gray-500 font-semibold">{currentIdx + 1}/{questions.length}</span>
          </div>
          <div className="flex gap-1.5 justify-center">
            {questions.map((_, i) => (
              <div key={i} className={`h-1.5 rounded-full flex-1 max-w-4 transition-all ${
                i < currentIdx ? "bg-orange-500" : i === currentIdx ? "bg-[#1a3a6b]" : "bg-gray-200"
              }`} />
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5 fade-in-up" key={currentIdx}>
        {catInfo && (
          <div className="inline-flex items-center gap-1.5 mb-4">
            <span className="text-xs font-bold px-3 py-1.5 rounded-full" style={{ background: catInfo.bgColor, color: catInfo.color }}>
              {catInfo.icon} {catInfo.name}
            </span>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-4">
          <div className="text-xs font-bold text-orange-500 uppercase tracking-widest mb-3">
            {t("questionNo")} {currentIdx + 1}
            {tq?.isTranslating && <span className="ml-2 text-orange-300 text-[10px] font-normal animate-pulse">{t("translating")}</span>}
          </div>
          <p className="text-gray-800 font-semibold text-lg leading-relaxed">{tq?.translatedQuestion ?? current.question}</p>
        </div>

        <div className="flex flex-col gap-3">
          {current.options.map((opt, idx) => {
            const answered = answers[currentIdx] !== null;
            let cls = "option-btn w-full text-left px-5 py-4 rounded-2xl font-medium text-gray-700 bg-white";
            if (answered) {
              if (idx === current.correct) cls += " correct";
              else if (idx === answers[currentIdx]) cls += " wrong";
              else cls += " border-gray-100 opacity-50";
            } else {
              cls += " hover:border-orange-400 hover:bg-orange-50 cursor-pointer";
            }
            return (
              <button key={idx} className={cls} onClick={() => handleSelect(idx)} disabled={answered}>
                <span className="inline-flex items-center gap-3">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0 ${
                    answered && idx === current.correct ? "bg-emerald-500 text-white" :
                    answered && idx === answers[currentIdx] ? "bg-red-500 text-white" :
                    "bg-orange-50 text-orange-600"
                  }`}>
                    {["A","B","C","D"][idx]}
                  </span>
                  {tq?.translatedOptions?.[idx] ?? opt}
                </span>
              </button>
            );
          })}
        </div>

        {answers[currentIdx] !== null && (
          <div className="mt-4 flex gap-3 fade-in-up">
            <button
              onClick={() => toggleBookmark(current)}
              className={`w-12 h-14 rounded-2xl flex items-center justify-center text-xl transition-all border-2 ${
                bookmarked.has(currentIdx) ? "bg-orange-100 border-orange-400 text-orange-600" : "bg-white border-gray-200 text-gray-400 hover:border-orange-300 hover:text-orange-500"
              }`}
              title={bookmarked.has(currentIdx) ? "Bookmarked!" : "Bookmark this question"}
            >
              {bookmarked.has(currentIdx) ? "🔖" : "☆"}
            </button>
            <button onClick={handleNext} className="flex-1 btn-saffron py-4 rounded-2xl text-lg font-bold">
              {currentIdx + 1 >= questions.length ? "✅ Submit Quiz" : "अगला →"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
