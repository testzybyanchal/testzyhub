import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type User = {
  id: number;
  name: string;
  email: string;
  mobile: string | null;
  isAdmin: boolean;
  totalPoints: number;
  xp: number;
  level: "Beginner" | "Intermediate" | "Pro" | "Master";
  coins: number;
  streakCount: number;
};

type AuthContextType = {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ user: User; dailyBonus: DailyBonus | null }>;
  signup: (name: string, email: string, password: string, mobile?: string) => Promise<User>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  updateUser: (partial: Partial<User>) => void;
  showAuthModal: boolean;
  setShowAuthModal: (v: boolean) => void;
  authRedirect: string | null;
  setAuthRedirect: (v: string | null) => void;
};

export type DailyBonus = { xp: number; coins: number; streak: number };

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authRedirect, setAuthRedirect] = useState<string | null>(null);

  async function refreshUser() {
    try {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    }
  }

  useEffect(() => {
    refreshUser().finally(() => setLoading(false));
  }, []);

  function updateUser(partial: Partial<User>) {
    setUser((prev) => prev ? { ...prev, ...partial } : prev);
  }

  async function login(email: string, password: string) {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Login failed");
    setUser(data.user);
    return { user: data.user as User, dailyBonus: data.dailyBonus as DailyBonus | null };
  }

  async function signup(name: string, email: string, password: string, mobile?: string): Promise<User> {
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ name, email, password, mobile }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Signup failed");
    setUser(data.user);
    return data.user;
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout, refreshUser, updateUser, showAuthModal, setShowAuthModal, authRedirect, setAuthRedirect }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
