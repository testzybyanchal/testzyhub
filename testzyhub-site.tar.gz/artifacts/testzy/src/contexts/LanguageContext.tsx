import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { type LangCode, getTranslation } from "@/data/translations";

type LanguageContextType = {
  lang: LangCode;
  setLang: (l: LangCode) => void;
  t: (key: string) => string;
  translateText: (text: string) => Promise<string>;
};

const LanguageContext = createContext<LanguageContextType>({
  lang: "hi",
  setLang: () => {},
  t: (k) => k,
  translateText: async (t) => t,
});

const CACHE_PREFIX = "testzy_trans_";

async function translateToLang(text: string, targetLang: LangCode): Promise<string> {
  if (targetLang === "hi") return text;
  if (!text.trim()) return text;

  const cacheKey = `${CACHE_PREFIX}${targetLang}_${btoa(encodeURIComponent(text.slice(0, 50)))}`;
  const cached = localStorage.getItem(cacheKey);
  if (cached) return cached;

  try {
    const langMap: Record<LangCode, string> = {
      hi: "hi", en: "en", bn: "bn", ta: "ta", te: "te",
      mr: "mr", gu: "gu", pa: "pa", ml: "ml", kn: "kn",
    };
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=hi&tl=${langMap[targetLang]}&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (!res.ok) return text;
    const data = await res.json();
    const translated = data?.[0]?.map((c: [string]) => c[0]).join("") || text;
    try { localStorage.setItem(cacheKey, translated); } catch {}
    return translated;
  } catch {
    return text;
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LangCode>(() => {
    const saved = localStorage.getItem("testzy_lang");
    return (saved as LangCode) || "hi";
  });

  function setLang(l: LangCode) {
    setLangState(l);
    localStorage.setItem("testzy_lang", l);
    document.documentElement.lang = l;
  }

  useEffect(() => {
    document.documentElement.lang = lang;
  }, []);

  function t(key: string): string {
    return getTranslation(lang, key);
  }

  async function translateText(text: string): Promise<string> {
    if (lang === "hi") return text;
    return translateToLang(text, lang);
  }

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, translateText }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
