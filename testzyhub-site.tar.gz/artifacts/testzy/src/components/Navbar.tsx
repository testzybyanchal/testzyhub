import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";
import { LANGUAGES } from "@/data/translations";

const LEVEL_CONFIG = {
  Beginner:     { color: "#6b7280", bg: "#f3f4f6", icon: "🌱", next: 200 },
  Intermediate: { color: "#0ea5e9", bg: "#e0f2fe", icon: "⚡", next: 500 },
  Pro:          { color: "#8b5cf6", bg: "#ede9fe", icon: "🔥", next: 1000 },
  Master:       { color: "#f59e0b", bg: "#fef3c7", icon: "👑", next: 9999 },
};

function XPBar({ xp, level }: { xp: number; level: string }) {
  const cfg = LEVEL_CONFIG[level as keyof typeof LEVEL_CONFIG] || LEVEL_CONFIG.Beginner;
  const prevXP = level === "Beginner" ? 0 : level === "Intermediate" ? 200 : level === "Pro" ? 500 : 1000;
  const progress = Math.min(100, ((xp - prevXP) / (cfg.next - prevXP)) * 100);
  return (
    <div className="hidden md:flex flex-col gap-0.5 min-w-[120px]">
      <div className="flex items-center justify-between text-[10px] font-semibold">
        <span style={{ color: cfg.color }}>{cfg.icon} {level}</span>
        <span className="text-gray-400">{xp} XP</span>
      </div>
      <div className="h-1.5 rounded-full bg-gray-200 overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${cfg.color}, ${cfg.color}88)` }} />
      </div>
    </div>
  );
}

function LanguageSwitcher() {
  const { lang, setLang, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const current = LANGUAGES.find((l) => l.code === lang) || LANGUAGES[0];

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gray-100 hover:bg-purple-50 text-gray-700 hover:text-purple-700 transition-all text-xs font-semibold border border-gray-200"
        title={t("selectLang")}
      >
        <span>🌐</span>
        <span className="hidden sm:block">{current.nativeName}</span>
        <span className="text-gray-400 text-[10px]">▼</span>
      </button>

      {open && (
        <div className="absolute right-0 top-11 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 w-52 z-50 slide-down max-h-80 overflow-y-auto">
          <p className="px-4 py-1 text-xs text-gray-400 font-semibold uppercase tracking-wide">{t("selectLang")}</p>
          {LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => { setLang(l.code); setOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-all ${lang === l.code ? "bg-purple-50 text-purple-700 font-bold" : "text-gray-700 hover:bg-gray-50"}`}
            >
              <span>{l.flag}</span>
              <div className="text-left">
                <div className="font-semibold text-sm">{l.nativeName}</div>
                <div className="text-xs text-gray-400">{l.name}</div>
              </div>
              {lang === l.code && <span className="ml-auto text-purple-600 text-xs">✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Navbar() {
  const [location, navigate] = useLocation();
  const { user, logout, setShowAuthModal } = useAuth();
  const { t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { path: "/",             label: t("home"),        icon: "🏠", activeColor: "#6d28d9" },
    { path: "/practice",    label: t("practice"),    icon: "📚", activeColor: "#0ea5e9" },
    { path: "/mock-test",   label: t("mockTest"),    icon: "⏱️", activeColor: "#f97316" },
    { path: "/daily-quiz",  label: t("dailyQuiz"),   icon: "⚡", activeColor: "#ec4899" },
    { path: "/battle",      label: t("battle"),      icon: "⚔️", activeColor: "#dc2626" },
    { path: "/mega-quiz",   label: t("megaQuiz"),    icon: "🏆", activeColor: "#d97706" },
    { path: "/doubts",      label: "Doubt Forum",    icon: "🤔", activeColor: "#059669" },
    { path: "/leaderboard", label: t("leaderboard"), icon: "📊", activeColor: "#f59e0b" },
  ];

  const isHome = location === "/";

  return (
    <>
      <nav className="navbar-glass sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-16">
          {/* Logo + Back Button */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Back Button — only on inner pages */}
            {!isHome && (
              <button
                onClick={() => window.history.back()}
                className="flex items-center justify-center w-9 h-9 rounded-xl transition-all hover:scale-105 active:scale-95"
                style={{ background: "linear-gradient(135deg, #6d28d9, #2563eb)", color: "white" }}
                title="वापस जाएं"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 12H5M12 5l-7 7 7 7"/>
                </svg>
              </button>
            )}
            <button onClick={() => navigate("/")} className="flex items-center gap-2 group">
              <img src="/logo.png" alt="Testzy Logo" className="w-10 h-10 rounded-xl object-cover shadow-sm" />
              <div className="hidden sm:flex flex-col leading-tight">
                <span className="font-black text-lg leading-none" style={{ background: "linear-gradient(135deg, #1a56db, #0ea5e9)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  TESTZY<span style={{ background: "linear-gradient(135deg, #0ea5e9, #6d28d9)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>HUB</span>
                </span>
                <span className="text-[9px] text-gray-400 font-semibold tracking-widest">PRACTICE • TEST • SUCCEED</span>
              </div>
            </button>
          </div>

          {/* Desktop Nav */}
          <div className="hidden xl:flex items-center gap-0.5">
            {navLinks.map((link) => {
              const active = location === link.path;
              const isBattle = link.path === "/battle";
              const isMega = link.path === "/mega-quiz";
              return (
                <button
                  key={link.path}
                  onClick={() => navigate(link.path)}
                  className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    active ? "text-white shadow-md" : "text-gray-600 hover:bg-purple-50 hover:text-purple-700"
                  } ${isBattle ? "relative" : ""}`}
                  style={active ? { background: `linear-gradient(135deg, ${link.activeColor}, ${link.activeColor}bb)` } : {}}
                >
                  {link.icon} {link.label}
                  {isBattle && !active && <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />}
                  {isMega && !active && <span className="absolute -top-1 -right-1 text-[8px] bg-yellow-500 text-white rounded-full px-1 font-black">₹</span>}
                </button>
              );
            })}
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            {/* Dark Mode Toggle */}
            <button
              onClick={toggleTheme}
              className="w-9 h-9 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-lg transition-all"
              title={theme === "dark" ? "Light Mode" : "Dark Mode"}
            >
              {theme === "dark" ? "☀️" : "🌙"}
            </button>
            {/* Language Switcher */}
            <LanguageSwitcher />

            {user ? (
              <div className="flex items-center gap-2">
                {/* XP Bar */}
                <XPBar xp={user.xp} level={user.level} />

                {/* Coins */}
                <div className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-sm cursor-pointer"
                  style={{ background: "linear-gradient(135deg, #fef3c7, #fed7aa)", color: "#92400e", border: "1.5px solid #fcd34d" }}
                  onClick={() => navigate("/leaderboard")}
                >
                  🪙 {user.coins}
                </div>

                {/* Points */}
                <div className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-xs"
                  style={{ background: "linear-gradient(135deg, #ede9fe, #fce7f3)", color: "#6d28d9", border: "1.5px solid #c4b5fd" }}>
                  ⭐ {user.totalPoints.toFixed(1)}
                </div>

                {user.isAdmin && (
                  <button onClick={() => navigate("/admin")}
                    className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold text-white shadow-sm"
                    style={{ background: "linear-gradient(135deg, #7c3aed, #a855f7)" }}>
                    🛡️ Admin
                  </button>
                )}

                <div className="relative">
                  <button onClick={() => setMenuOpen(!menuOpen)}
                    className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-xl transition-all">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold text-white"
                      style={{ background: "linear-gradient(135deg, #6d28d9, #ec4899, #f97316)" }}>
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="hidden sm:block text-sm font-semibold text-gray-700">{user.name.split(" ")[0]}</span>
                    <span className="text-gray-400 text-xs">▼</span>
                  </button>
                  {menuOpen && (
                    <div className="absolute right-0 top-12 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 w-56 z-50 slide-down">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <p className="font-bold text-gray-800 text-sm">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                        <div className="flex gap-2 mt-2">
                          <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-semibold">{user.level} {user.xp} XP</span>
                          <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-semibold">🪙 {user.coins}</span>
                        </div>
                        {user.streakCount > 0 && (
                          <p className="text-xs text-orange-600 font-semibold mt-1">🔥 {user.streakCount} {t("home") === "होम" ? "दिन की Streak!" : "Day Streak!"}</p>
                        )}
                      </div>
                      <button onClick={() => { navigate("/my-stats"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-purple-700 hover:bg-purple-50 font-semibold">
                        📊 My Performance
                      </button>
                      <button onClick={() => { navigate("/bookmarks"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-orange-700 hover:bg-orange-50 font-semibold">
                        🔖 Bookmarks
                      </button>
                      <div className="border-t border-gray-100 my-1" />
                      <button onClick={() => { navigate("/current-affairs"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-blue-700 hover:bg-blue-50 font-medium">
                        📰 Current Affairs
                      </button>
                      <button onClick={() => { navigate("/study-notes"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-green-700 hover:bg-green-50 font-medium">
                        📖 Study Notes
                      </button>
                      <button onClick={() => { navigate("/exam-calendar"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-indigo-700 hover:bg-indigo-50 font-medium">
                        📅 Exam Calendar
                      </button>
                      <div className="border-t border-gray-100 my-1" />
                      <button onClick={() => { navigate("/battle"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 font-semibold">
                        ⚔️ {t("battleTitle")}
                      </button>
                      <button onClick={() => { navigate("/mega-quiz"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-yellow-700 hover:bg-yellow-50 font-semibold">
                        🏆 {t("megaQuiz")} (₹10)
                      </button>
                      <button onClick={() => { navigate("/leaderboard"); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-blue-700 hover:bg-blue-50 font-medium">
                        📊 {t("leaderboard")}
                      </button>
                      {user.isAdmin && (
                        <button onClick={() => { navigate("/admin"); setMenuOpen(false); }}
                          className="w-full text-left px-4 py-2.5 text-sm text-purple-700 hover:bg-purple-50 font-medium">
                          🛡️ Admin Panel
                        </button>
                      )}
                      <button onClick={() => { logout(); setMenuOpen(false); }}
                        className="w-full text-left px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 font-medium border-t border-gray-100 mt-1">
                        🚪 {t("logout")}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => setShowAuthModal(true)}
                  className="text-sm font-semibold text-purple-700 hover:text-purple-900 px-3 py-2 rounded-xl hover:bg-purple-50 transition-all">
                  {t("login")}
                </button>
                <button onClick={() => setShowAuthModal(true)} className="btn-saffron text-sm px-4 py-2 rounded-xl">
                  {t("signup")}
                </button>
              </div>
            )}
            <button onClick={() => setMenuOpen(!menuOpen)} className="xl:hidden text-purple-700 hover:text-purple-900 p-2 text-xl">
              ☰
            </button>
          </div>
        </div>

        {/* Mobile/Tablet Menu */}
        {menuOpen && (
          <div className="xl:hidden bg-white border-t border-purple-100 py-2 slide-down">
            {navLinks.map((link) => {
              const active = location === link.path;
              return (
                <button key={link.path} onClick={() => { navigate(link.path); setMenuOpen(false); }}
                  className={`flex items-center gap-3 w-full px-5 py-3 text-sm font-semibold transition-all ${active ? "text-white" : "text-gray-600"}`}
                  style={active ? { background: `linear-gradient(135deg, ${link.activeColor}22, ${link.activeColor}11)`, color: link.activeColor } : {}}>
                  {link.icon} {link.label}
                  {link.path === "/mega-quiz" && <span className="ml-auto text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-bold">₹10</span>}
                </button>
              );
            })}
            {user && (
              <div className="px-5 py-3 border-t border-gray-100 mt-1">
                <div className="flex justify-between text-xs text-gray-500 mb-1">
                  <span>XP: {user.xp}</span>
                  <span>{user.level}</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
                    style={{ width: `${Math.min(100, (user.xp / (user.level === "Master" ? 9999 : user.level === "Pro" ? 1000 : user.level === "Intermediate" ? 500 : 200)) * 100)}%` }} />
                </div>
                <div className="flex gap-3 mt-2">
                  <span className="text-xs bg-yellow-50 text-yellow-700 px-2 py-1 rounded-lg font-semibold">🪙 {user.coins}</span>
                  {user.streakCount > 0 && <span className="text-xs bg-orange-50 text-orange-600 px-2 py-1 rounded-lg font-semibold">🔥 {user.streakCount}</span>}
                </div>
              </div>
            )}
            {!user && (
              <div className="px-5 py-3 border-t border-gray-100">
                <button onClick={() => { setShowAuthModal(true); setMenuOpen(false); }}
                  className="w-full btn-primary py-2.5 rounded-xl text-sm font-bold">
                  {t("login")} / {t("signup")}
                </button>
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Mobile Bottom Nav */}
      <div className="xl:hidden fixed bottom-0 left-0 right-0 bg-white border-t-2 border-purple-100 z-40 shadow-lg">
        <div className="grid grid-cols-6">
          {navLinks.slice(0, 6).map((link) => {
            const active = location === link.path;
            const isBattle = link.path === "/battle";
            return (
              <button key={link.path} onClick={() => navigate(link.path)}
                className={`flex flex-col items-center py-2 text-xs font-semibold transition-all relative ${active ? "" : "text-gray-400"}`}
                style={active ? { color: link.activeColor } : {}}>
                <span className="text-lg mb-0.5">{link.icon}</span>
                <span className="text-[9px]">{link.label.split(" ")[0]}</span>
                {isBattle && !active && <span className="absolute top-1 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse" />}
                {active && <div className="w-4 h-0.5 rounded-full mt-0.5" style={{ background: link.activeColor }} />}
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}
