import { useLocation } from "wouter";
export default function Footer() {
  const [, navigate] = useLocation();
  return (

    <footer className="bg-[#0f2548] text-white mt-auto pt-10 pb-24 lg:pb-10">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <img src="/logo.png" alt="TestzyHub" className="w-10 h-10 rounded-xl object-cover" />
              <div className="flex flex-col leading-tight">
                <span className="font-black text-lg text-white leading-none">TESTZY<span className="text-blue-400">HUB</span></span>
                <span className="text-[9px] text-blue-400 tracking-widest">PRACTICE • TEST • SUCCEED</span>
              </div>
            </div>
            <p className="text-blue-200 text-sm leading-relaxed">
              भारत का सबसे अच्छा Government Exam Preparation Platform. रोज़ Practice करो, Selection पक्का करो।
            </p>
            <div className="mt-3">
              <span className="text-orange-400 font-bold text-base">"Roz Practice karo, Selection pakka karo 💪"</span>
            </div>
          </div>
          <div>
            <h4 className="font-bold text-white mb-3">Quick Links</h4>
            <div className="space-y-2 text-sm text-blue-200">
              <button onClick={() => navigate("/")} className="block hover:text-white">🏠 Home</button>
              <button onClick={() => navigate("/practice")} className="block hover:text-white">📚 Practice Test</button>
              <button onClick={() => navigate("/mock-test")} className="block hover:text-white">⏱️ Mock Test</button>
              <button onClick={() => navigate("/daily-quiz")} className="block hover:text-white">⚡ Daily Quiz</button>
              <button onClick={() => navigate("/leaderboard")} className="block hover:text-white">🏆 Leaderboard</button>
              <button onClick={() => navigate("/referral")} className="block hover:text-white">🎁 Refer & Earn</button>
            </div>
          </div>
          <div>
            <h4 className="font-bold text-white mb-3">Support & More</h4>
            <div className="space-y-2 text-sm text-blue-200">
              <button onClick={() => navigate("/reviews")} className="block hover:text-white">⭐ User Reviews</button>
              <button onClick={() => navigate("/help")} className="block hover:text-white">🛟 Help Center</button>
              <button onClick={() => navigate("/referral")} className="block hover:text-white">🎁 Refer & Earn</button>
            </div>
            <div className="mt-4">
              <h4 className="font-bold text-white mb-2">Exam Categories</h4>
              <div className="grid grid-cols-2 gap-1 text-sm text-blue-200">
                {["📋 SSC","🚂 Railway","👮 Police","🏦 Banking"].map((e) => (
                  <span key={e} className="hover:text-white cursor-default">{e}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10 pt-6 text-center">
          <p className="text-blue-300 text-sm">
            © 2026 Testzy | Made with ❤️ for Students | All Rights Reserved
          </p>
          <p className="text-xs text-blue-400 mt-1">
            Free Government Exam Preparation • SSC • Railway • Police • Banking
          </p>
        </div>
      </div>
    </footer>
  );
}
