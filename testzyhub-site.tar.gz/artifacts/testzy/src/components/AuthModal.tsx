import { useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { useAuth, type DailyBonus } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";

export default function AuthModal() {
  const { login, signup, setShowAuthModal, authRedirect, setAuthRedirect } = useAuth();
  const { t } = useLanguage();
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [dailyBonus, setDailyBonus] = useState<DailyBonus | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      let loggedInUser;
      if (mode === "signup") {
        loggedInUser = await signup(name, email, password, mobile || undefined);
        setShowAuthModal(false);
        const dest = authRedirect || "/select-category";
        setAuthRedirect(null);
        navigate(dest);
      } else {
        const result = await login(email, password);
        loggedInUser = result.user;
        if (result.dailyBonus) {
          setDailyBonus(result.dailyBonus);
          await new Promise((r) => setTimeout(r, 2500));
        }
        setShowAuthModal(false);
        const dest = authRedirect || (loggedInUser?.isAdmin ? "/admin" : "/select-category");
        setAuthRedirect(null);
        navigate(dest);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "कुछ गलत हुआ");
    } finally {
      setLoading(false);
    }
  }

  if (dailyBonus) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center modal-overlay px-4">
        <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-8 text-center slide-down">
          <div className="text-6xl mb-4">🌟</div>
          <h2 className="text-2xl font-black text-gray-800 mb-2">Daily Login Bonus!</h2>
          <p className="text-gray-500 mb-6">🔥 {dailyBonus.streak} Day Streak!</p>
          <div className="flex gap-4 justify-center mb-6">
            <div className="bg-purple-50 rounded-2xl px-6 py-4 border-2 border-purple-200">
              <div className="text-3xl font-black text-purple-600">+{dailyBonus.xp}</div>
              <div className="text-sm font-semibold text-purple-500">XP</div>
            </div>
            <div className="bg-yellow-50 rounded-2xl px-6 py-4 border-2 border-yellow-200">
              <div className="text-3xl font-black text-yellow-600">+{dailyBonus.coins}</div>
              <div className="text-sm font-semibold text-yellow-500">{t("coinsEarned")}</div>
            </div>
          </div>
          <p className="text-sm text-gray-400">Redirecting...</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center modal-overlay px-4"
      onClick={() => setShowAuthModal(false)}
    >
      <div
        className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden slide-down"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="hero-gradient text-white p-6 text-center relative">
          <div className="text-4xl mb-2">🎯</div>
          <h2 className="text-2xl font-bold">Testzy</h2>
          <p className="text-blue-200 text-sm mt-1">{t("authSub")}</p>
          <button
            onClick={() => setShowAuthModal(false)}
            className="absolute top-4 right-4 text-white/70 hover:text-white text-xl font-bold"
          >
            ✕
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button
            className={`flex-1 py-3.5 font-semibold text-sm transition-all ${mode === "signup" ? "text-[#1a3a6b] border-b-2 border-[#1a3a6b]" : "text-gray-500 hover:text-gray-700"}`}
            onClick={() => setMode("signup")}
          >
            {t("signupBtn")}
          </button>
          <button
            className={`flex-1 py-3.5 font-semibold text-sm transition-all ${mode === "login" ? "text-[#1a3a6b] border-b-2 border-[#1a3a6b]" : "text-gray-500 hover:text-gray-700"}`}
            onClick={() => setMode("login")}
          >
            {t("loginBtn")}
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {mode === "signup" && (
            <>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t("nameLabel")} *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t("namePh")}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-[#1a3a6b] text-gray-800 transition-colors"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t("mobileLabel")} *</label>
                <div className="flex gap-2">
                  <span className="flex items-center px-3 border-2 border-gray-200 rounded-xl text-gray-600 font-semibold bg-gray-50">+91</span>
                  <input
                    type="tel"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    placeholder={t("mobilePh")}
                    className="flex-1 border-2 border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-[#1a3a6b] text-gray-800 transition-colors"
                    required
                  />
                </div>
              </div>
            </>
          )}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t("emailLabel")} *</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t("emailPh")}
              className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-[#1a3a6b] text-gray-800 transition-colors"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t("passLabel")} *</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t("passPh")}
              className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-[#1a3a6b] text-gray-800 transition-colors"
              required
            />
          </div>

          {mode === "signup" && (
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-3 border border-purple-100">
              <p className="text-xs text-purple-700 font-semibold">🎁 {t("authWelcome")}</p>
              <p className="text-xs text-purple-600 mt-1">🪙 50 Coins + 🔥 Daily Login Bonus + 🏆 XP System</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-red-700 text-sm font-medium">
              ⚠️ {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full btn-primary py-3.5 rounded-xl text-white font-bold text-base disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {loading ? "Please wait..." : mode === "signup" ? `${t("signupBtn")} 🚀` : `${t("loginBtn")} →`}
          </button>

          <p className="text-center text-xs text-gray-500">
            {mode === "signup" ? t("haveAccount") : t("noAccount")}{" "}
            <button
              type="button"
              onClick={() => setMode(mode === "signup" ? "login" : "signup")}
              className="text-[#f97316] font-semibold hover:underline"
            >
              {mode === "signup" ? t("loginLink") : t("signupLink")}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}
