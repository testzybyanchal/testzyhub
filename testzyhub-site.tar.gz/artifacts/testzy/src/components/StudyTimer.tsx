import { useState, useEffect, useRef } from "react";

const SESSIONS = [
  { label: "25 min", mins: 25 },
  { label: "45 min", mins: 45 },
  { label: "60 min", mins: 60 },
];

export default function StudyTimer() {
  const [open, setOpen] = useState(false);
  const [sessionMins, setSessionMins] = useState(25);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [phase, setPhase] = useState<"study" | "break">("study");
  const [sessions, setSessions] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((t) => {
          if (t <= 1) {
            clearInterval(intervalRef.current!);
            setRunning(false);
            if (phase === "study") {
              setSessions((s) => s + 1);
              setPhase("break");
              setTimeLeft(5 * 60);
            } else {
              setPhase("study");
              setTimeLeft(sessionMins * 60);
            }
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    } else {
      clearInterval(intervalRef.current!);
    }
    return () => clearInterval(intervalRef.current!);
  }, [running, phase, sessionMins]);

  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  const total = phase === "study" ? sessionMins * 60 : 5 * 60;
  const progress = ((total - timeLeft) / total) * 100;

  function reset() {
    setRunning(false);
    setPhase("study");
    setTimeLeft(sessionMins * 60);
  }

  function pickSession(m: number) {
    setSessionMins(m);
    setRunning(false);
    setPhase("study");
    setTimeLeft(m * 60);
  }

  return (
    <div className="fixed bottom-24 right-4 z-50 xl:bottom-6">
      {open && (
        <div className="mb-3 bg-white rounded-3xl shadow-2xl border border-purple-100 p-5 w-72 animate-fadeIn">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-black text-gray-800 text-base">⏱️ Study Timer</h3>
              <p className="text-xs text-gray-400">{sessions} sessions today</p>
            </div>
            <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${phase === "study" ? "bg-purple-100 text-purple-700" : "bg-green-100 text-green-700"}`}>
              {phase === "study" ? "📚 Study" : "☕ Break"}
            </span>
          </div>

          {/* Session Picker */}
          <div className="flex gap-2 mb-4">
            {SESSIONS.map((s) => (
              <button
                key={s.mins}
                onClick={() => pickSession(s.mins)}
                className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${sessionMins === s.mins ? "bg-purple-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-purple-50"}`}
              >
                {s.label}
              </button>
            ))}
          </div>

          {/* Circular Progress */}
          <div className="flex justify-center mb-4">
            <div className="relative w-32 h-32">
              <svg className="w-32 h-32 -rotate-90" viewBox="0 0 120 120">
                <circle cx="60" cy="60" r="50" fill="none" stroke="#f3f4f6" strokeWidth="8" />
                <circle
                  cx="60" cy="60" r="50" fill="none"
                  stroke={phase === "study" ? "#7c3aed" : "#10b981"}
                  strokeWidth="8"
                  strokeDasharray={`${2 * Math.PI * 50}`}
                  strokeDashoffset={`${2 * Math.PI * 50 * (1 - progress / 100)}`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-black text-gray-800">
                  {String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}
                </span>
                <span className="text-xs text-gray-400">{phase === "study" ? "Focus Time" : "Break Time"}</span>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-2">
            <button
              onClick={() => setRunning((r) => !r)}
              className="flex-1 py-2.5 rounded-2xl font-black text-sm text-white transition-all hover:scale-105"
              style={{ background: running ? "#ef4444" : "linear-gradient(135deg, #7c3aed, #a855f7)" }}
            >
              {running ? "⏸ Pause" : "▶ Start"}
            </button>
            <button
              onClick={reset}
              className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold text-sm transition-all"
            >
              ↺
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setOpen((o) => !o)}
        className="w-14 h-14 rounded-full shadow-xl flex items-center justify-center text-xl font-black text-white transition-all hover:scale-110 hover:shadow-2xl"
        style={{ background: running ? "linear-gradient(135deg, #10b981, #059669)" : "linear-gradient(135deg, #7c3aed, #a855f7)" }}
        title="Study Timer"
      >
        {running ? "⏱" : "⏳"}
      </button>
    </div>
  );
}
