import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AuthModal from "@/components/AuthModal";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import StudyTimer from "@/components/StudyTimer";
import Home from "./pages/Home.1";
import SelectCategory from "@/pages/SelectCategory";
import CategoryPage from "@/pages/CategoryPage";
import PracticeTest from "@/pages/PracticeTest";
import MockTest from "@/pages/MockTest";
import DailyQuiz from "@/pages/DailyQuiz";
import CategoryQuiz from "@/pages/CategoryQuiz";
import Leaderboard from "@/pages/Leaderboard";
import AdminPanel from "@/pages/AdminPanel";
import BattleMode from "@/pages/BattleMode";
import MegaQuiz from "@/pages/MegaQuiz";
import ReviewsPage from "@/pages/ReviewsPage";
import HelpCenter from "@/pages/HelpCenter";
import ReferralPage from "@/pages/ReferralPage";
import DoubtsPage from "@/pages/DoubtsPage";
import CurrentAffairs from "@/pages/CurrentAffairs";
import StudyNotes from "@/pages/StudyNotes";
import ExamCalendar from "@/pages/ExamCalendar";
import Bookmarks from "@/pages/Bookmarks";
import StatsPage from "@/pages/StatsPage";
import AiDoubt from "@/pages/AiDoubt";
import Flashcards from "@/pages/Flashcards";
import FormulaCards from "@/pages/FormulaCards";
import PYQ from "@/pages/PYQ";
import Tournament from "@/pages/Tournament";

const queryClient = new QueryClient();

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <p className="text-6xl mb-4">😕</p>
        <h1 className="text-2xl font-bold text-gray-800 mb-2">पेज नहीं मिला</h1>
        <p className="text-gray-500 mb-6">यह पेज मौजूद नहीं है।</p>
        <a href="/" className="btn-primary px-6 py-2.5 rounded-xl inline-block">Home जाएं</a>
      </div>
    </div>
  );
}

function AppContent() {
  const { showAuthModal, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center hero-gradient">
        <div className="text-white text-center">
          <div className="text-5xl mb-4">🎯</div>
          <p className="text-2xl font-black">Testzy</p>
          <p className="text-blue-200 mt-2 text-sm">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      {showAuthModal && <AuthModal />}
      <Navbar />
      <StudyTimer />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/select-category" component={SelectCategory} />
          <Route path="/category/:id" component={CategoryPage} />
          <Route path="/practice" component={PracticeTest} />
          <Route path="/mock-test" component={MockTest} />
          <Route path="/daily-quiz" component={DailyQuiz} />
          <Route path="/quiz" component={CategoryQuiz} />
          <Route path="/leaderboard" component={Leaderboard} />
          <Route path="/battle" component={BattleMode} />
          <Route path="/mega-quiz" component={MegaQuiz} />
          <Route path="/admin" component={AdminPanel} />
          <Route path="/reviews" component={ReviewsPage} />
          <Route path="/help" component={HelpCenter} />
          <Route path="/referral" component={ReferralPage} />
          <Route path="/doubts" component={DoubtsPage} />
          <Route path="/current-affairs" component={CurrentAffairs} />
          <Route path="/study-notes" component={StudyNotes} />
          <Route path="/exam-calendar" component={ExamCalendar} />
          <Route path="/bookmarks" component={Bookmarks} />
          <Route path="/my-stats" component={StatsPage} />
          <Route path="/ai-doubt" component={AiDoubt} />
          <Route path="/flashcards" component={Flashcards} />
          <Route path="/formulas" component={FormulaCards} />
          <Route path="/pyq" component={PYQ} />
          <Route path="/tournament" component={Tournament} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <ThemeProvider>
          <AuthProvider>
            <LanguageProvider>
              <AppContent />
            </LanguageProvider>
          </AuthProvider>
        </ThemeProvider>
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
